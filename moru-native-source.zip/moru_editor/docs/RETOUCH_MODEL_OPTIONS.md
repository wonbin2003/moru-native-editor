# 피부·팔자주름 품질 개선 후보

조사일: **2026-11-18**. 목표는 Android·iPhone의 **네이티브·오프라인** 피부 보정입니다.
공식 저장소, 저자 모델 카드, 라이선스, 실행 코드를 확인한 뒤, Alibaba의 53.6MB 피부
generator 하나만 별도의 로컬 환경에서 실제 NASA 인물 사진 2장으로 평가했습니다.
앱 코드·의존성에는 추가하지 않았습니다. 다른 가중치와 전체 Alibaba 파이프라인은
실행하지 않았고, Android·iPhone 성능은 미검증입니다.

CPU 8스레드의 512×512 입력 추론은 첫 장 7.20초, 두 번째 4.27초였습니다.
강도 1.0에서 원본 대비 채널 평균 절대 픽셀 차이는 각각 0.78/255·1.05/255였고,
직접 확인한 비교 이미지에서 피부 변화는 미세하며 깊은 팔자 골은 남았습니다.
차이 크기는 품질 점수가 아닙니다. **generator 단독의 뚜렷한 개선 이득을 확인하지 못해
현재 앱에 통합하지 않았습니다.** 현재 빌드는 기존 Dart 리터치 계산을 유지합니다.

현재 Moru는 얼굴 특징점으로 팔자 부위를 추정해 주변 밝기와 비교하고, 잔주름에는 가는
어두운 선 완화를 적용합니다. 얼굴 전체를 흐리는 방식보다 선택적이지만 주름의 실제
위치·깊이·피부 상태를 학습한 모델은 아닙니다. **이번 조사에서 코드·가중치 권한과
모바일 실행, 팔자주름 품질까지 모두 입증된 즉시 교체용 무료 모델은 찾지 못했습니다.**

## 진행 가능한 세 경로

| 경로 | 개선 목표 | 코드 / 사전학습 가중치 | Android·iOS 오프라인 실행 | 판단 |
|---|---|---|---|---|
| 1. 경계 보존·주파수 분리·선택적 복구 | 피부의 색 얼룩과 질감을 분리하고 실제 검출/수동 지정한 주름만 완화 | OpenCV 4.5 이상 Apache-2.0. 학습 가중치 불필요. 기존 MediaPipe의 허용된 모델을 마스크 보조에 재사용 | C++ OpenCV를 FFI/JNI/Objective-C++로 연결하거나 필요한 수식을 독자 구현. CPU 타일·얼굴 ROI로 처리 가능 | **가장 먼저 개선할 경로**. 팔자 위치를 고정 곡선으로만 가정하는 현재 방식의 약점을 줄일 수 있음. 실제 개선량은 비교 평가 필요. [필터][cvfilters], [복구][cvinpaint], [라이선스][cvlicense] |
| 2. GPUPixel의 필터 부분만 사용 | GPU의 다중 패스 피부 평활화·미세 대비 보존, 빠른 미리보기 | 현행 엔진 Apache-2.0. 피부 필터 자체는 신경망 가중치 불필요. **Mars-Face/VNN은 포함하지 않음** | 공식 Android·iOS 통합 경로가 있음. 자체 빌드에서 얼굴 검출 OFF, 기존 MediaPipe와 자체 피부 마스크만 사용 | **피부와 성능의 후보**. 팔자주름 전용 제거 모델은 아님. 엔진을 바꾸기만 하면 화질이 좋아진다고 단정할 수 없음. [코드][gpu], [통합][gpuintegration], [피부 계산][gpuskin] |
| 3. Alibaba ModelScope 피부 신경망의 이식 | 학습된 피부 균일화·국소 잡티 검출/복구 | ModelScope 코드 Apache-2.0. 공식 `iic/cv_unet_skin_retouching_torch` v1.0.4 모델 카드도 Apache License 2.0 명시. generator SHA를 검증해 기록 | 원본은 Python/PyTorch + ONNX Runtime 조합. 피부 신경망을 별도로 변환하고 모바일 연산자/메모리 검증이 필요. 기존 MediaPipe로 별도 얼굴 검출 의존성을 대체하는 것은 설계 변경 | **generator 단독 2장 평가 후 미채택**. 전체 모델·국소 inpainting은 미평가. 팔자주름·연령별 품질은 카드에서 보장하지 않음. [공식 카드][mscard], [카드 원문][msreadme], [코드 라이선스][mslicense], [실제 래퍼][mswrapper] |

1번과 2번은 학습된 피부 복원 모델이 없어도 구현할 수 있습니다. 3번의 generator 단독
평가는 완료했으며, 전체 경로는 변환·경계 합성·기기 검증이 필요합니다. 신경망이 피부의
점이나 개성을 지우거나 새 질감을 만들 수 있으므로 선택적 적용과 원본 비교가 필요합니다.

## 1. OpenCV 기반의 구체적인 개선안

OpenCV에는 guided filter·fast global smoother·bilateral 계열과 마스크 기반
Telea/Navier–Stokes 복구가 있습니다. 이들은 사진의 피부·주름을 이해하는 완성형 뷰티
모델이 아니라 아래 파이프라인의 재료입니다. [경계 보존 필터][cvfilters], [선택 복구][cvinpaint]

공식 Android·iOS 지원은 확인했습니다. 다만 guided filter 등 `ximgproc`은
`opencv_contrib` 모듈입니다. 기본 모바일 배포 팩에는 contrib가 들어 있지 않으므로
필요 모듈을 포함한 자체 빌드 또는 해당 수식의 독자 구현이 필요합니다.
[플랫폼][cvplatforms], [공식 설치 개요][cvinstall]

1. 기존 인물 분할의 얼굴 피부 확률과 얼굴 특징점을 합쳐 피부 마스크를 만들고 눈·
   입술·눈썹·콧구멍·머리카락을 제외합니다. 사용자가 수정할 수 있는 주름 마스크도 둡니다.
2. 선형 밝기 또는 명도 공간에서 큰 음영·색 얼룩과 고주파 피부결을 분리합니다.
   색 얼룩과 주름에 서로 다른 반경·강도를 사용하고 원래 미세 질감은 따로 보존합니다.
3. 팔자 후보는 특징점 곡선을 넓은 탐색 범위로만 사용하고, 그 안의 다중 크기 어두운
   선·국소 대비로 좁힙니다. 모든 사람에게 동일한 밝은 띠를 그리는 것을 줄입니다.
4. 좁은 잡티·잔주름은 실제 마스크의 주변 피부를 참고해 복구하고, 넓은 팔자 음영은
   제한적인 밝기·색 조정으로 완화합니다. 깊은 접힘에 무조건 평면 피부를 채우지 않습니다.
5. 원래 고주파·색·알파와 부드럽게 합성하고, 크롭 경계와 인접 얼굴에 영향이 없는지 검사합니다.

이는 **독자 구현 제안**이며, OpenCV 공식 기능이 위 요구를 자동으로 해결한다는 뜻은
아닙니다. 깊은 팔자는 얼굴 형상·조명으로 생길 수 있어 2D 선택 보정으로 완전히 없애면
자연스러운 음영과 정체성을 함께 손상할 수 있습니다.

참고로 [RapidRetouch 공식 설명][rapid]도 피부·주름 슬라이더에 주파수 분리·경계 보존·
선형광 명암 조정을 사용한다고 밝힙니다. 이 앱은 데스크톱 Python/Tauri 구성이고 소스는
**AGPL-3.0-only**입니다. 앱 코드를 그대로 MIT 소스에 복사하는 경로로 취급하지 않습니다.
고전 영상처리를 독자 구현하는 제안과 해당 코드를 가져오는 작업은 구분합니다.

## 2. GPUPixel의 얼굴 분석 의존성 확인

공식 현행 `CMakeLists.txt`는 `GPUPIXEL_ENABLE_FACE_DETECTOR`를 기본 **ON**으로
설정합니다. `third_party/CMakeLists.txt`는 Mars-Face의 iOS 정적 라이브러리와
Android `.so`를 가져옵니다. 해당 디렉터리의 공식 파일 목록은 include/libs/models이며,
조사한 목록에서 별도 LICENSE나 얼굴 분석 소스는 확인하지 못했습니다. 최상위 Apache
표시만 보고 이 바이너리와 모델의 재배포 권한까지 검증되었다고 할 수 없습니다.
[빌드 옵션][gpucmake], [네이티브 의존성][gputhird], [디렉터리][marsdir]

안전하게 검토할 범위는 `-DGPUPIXEL_ENABLE_FACE_DETECTOR=OFF`로 자체 빌드한 필터
엔진입니다. 얼굴/피부 영역은 기존 MediaPipe로 정하고, 필터 결과를 그 영역에만 합성합니다.
공식 피부 필터에는 box blur·high-pass와 국소 분산 기반 혼합이 있습니다. **팔자주름
인식·제거, 학습형 피부 복원은 그 필터의 확인된 기능이 아닙니다.** [필터 연결][gpufilter], [셰이더][gpuskin]

이전 v1.2.5 안내는 VNN을 연결하며 최상위 MIT를 표시했고, 현행 안내는
v1.3.0-beta부터 Mars-Face로 바뀌었다고 설명합니다. VNN 원본 저장소는 조사 시 404였으며
그 가중치/바이너리 라이선스를 검증하지 못했습니다. 예전 튜토리얼·미리 빌드한 AAR 전체를
그대로 포함하면 이 차이를 놓칠 수 있습니다. 사용할 버전·파일을 따로 고정해야 합니다.
[이전 안내][gpuold], [현행 안내][gpuintro]

추가로 Flutter 텍스처/네이티브 GPU 컨텍스트, RGBA 왕복 비용, 원본 해상도 타일 처리,
알파·색 공간을 맞춰야 합니다. 공식 모바일 데모가 있다는 사실은 Moru의 통합 완료나
특정 사진 해상도의 실시간 속도를 뜻하지 않습니다.

## 3. Alibaba 모델의 실제 구성과 크기

공식 모델 카드의 범위는 피부 균일화·국소 결함·밝기 보정이며 얼굴 크롭 입력은 512×512,
얼굴이 적어도 100×100인 사진을 안내합니다. 제한된 학습 데이터와 작은 얼굴에서의
불확실성도 명시합니다. 카드에는 FFHQ 등의 자료로 학습했다고 적혀 있지만 모델 라이선스
필드는 Apache License 2.0입니다. **학습 데이터 라이선스를 모델 코드 라이선스와 같다고
설명하지 않으며, 이 카드의 표시를 다른 프로젝트의 가중치에 확대하지 않습니다.** [카드 원문][msreadme]

공식 저장소 파일 목록 v1.0.4에서 확인한 크기입니다. 이후 `pytorch_model.pt` 하나만
다운로드하고 표의 SHA-256과 일치함을 확인했습니다. 나머지 바이너리는 받지 않았습니다.

| 파일 | 크기 / SHA-256 | 공식 래퍼에서의 용도 |
|---|---|---|
| `pytorch_model.pt` | 53,646,276 bytes / `760d0c0b95c4e0a692165677fe2b82dbdf8fbbd4a3780ca966599c627b082993` | 피부 균일화 UNet generator |
| `joint_20210926.pth` | 227,618,450 bytes / `c9e1388b19d9334c90db08308c86de208f535920ee381ae8a9cb63484a78351a` | 국소 결함 검출 + inpainting 네트워크 |
| `model.onnx` | 102,544,002 bytes / `d5b2a94201849f24ab4c38f2c56d52b1df6a2e6dd178f0f94e25f21997e5a16a` | **피부 분할**. 피부 보정 전체가 이미 ONNX라는 뜻이 아님 |
| `retinaface_resnet50_2020-07-20_old_torch.pth` | 109,477,455 bytes / `097c3045a4ef8d9a83499e28818604abe3f64f1c1e3f51284497faf75d430f81` | 별도 얼굴 검출. Moru에 중복 포함할 필요·권한을 별도로 검토 |

[공식 파일 메타데이터][msfiles], [공식 실행 래퍼][mswrapper]

중요하게, v1.0.4 래퍼의 기본 `retouch_local`은 **False**이며 피부 균일화와 미백은
활성화합니다. 따라서 데모 호출만으로 국소 잡티 복구까지 실행했다고 판정하면 안 됩니다.
국소 경로를 켜고 실제 차이를 검증해야 합니다. [래퍼][mswrapper]

모바일 이식은 UNet 및 국소 두 네트워크를 ONNX 등으로 내보내고 동일 전처리·
혼합 레이어·크롭 합성을 재현하는 작업입니다. ONNX Runtime은 Android·iOS를 지원하지만
이 모델의 모든 연산과 가속 경로를 보장하지 않습니다. CPU 기준 출력 일치부터 확인하고
선택적으로 CoreML/모바일 가속·FP16·양자화를 평가해야 합니다. 전체 모델을 동시에 읽는
메모리와 지연 시간은 파일 크기보다 커질 수 있으며 아직 측정하지 않았습니다.
[ORT 모바일][ortmobile], [iOS 빌드][ortios], [Android 빌드][ortandroid]
ORT 자체 코드는 MIT이며 모델의 이용 조건과 별개입니다. [ORT 라이선스][ortlicense]

## 바로 포함하지 않는 연구 후보

| 후보 | 코드 라이선스 | 가중치·제약 | 실행과 판정 |
|---|---|---|---|
| DiffRetouch (AAAI 2025) | **Pi-Lab License 1.0, 비상업 목적 한정** | 저자가 연결한 Hugging Face 저장소에서 별도 모델 카드·가중치 LICENSE를 확인하지 못함. 코드의 허용 범위를 가중치에 자동 적용하지 않음 | PyTorch/CUDA 연구 환경, 기본 확산 20단계. 전문가 색감/사진 리터치용이며 팔자 전용 모델로 검증되지 않음. 무제한 오픈소스 모바일 기본 기능으로 포함하지 않음. [라이선스][difflicense], [실행][diffreadme], [환경][diffenv], [가중치 목록][diffweights] |
| RetouchFormer (AAAI 2024) | 조사한 공식 전체 파일 트리에 **LICENSE 없음** | 저자는 `gen_best.pth`를 Baidu로 제공하지만 README에 가중치 사용·재배포 라이선스가 없음 | 얼굴 결함 검출과 국소 합성은 목적에 가깝지만 PyTorch 512 입력 연구 코드. 공개 열람·다운로드 가능을 재배포 허용으로 판단하지 않음. 권한 확인 전 미탑재. [공식 README][rf], [파일 트리][rftree], [추론 코드][rfinfer] |
| FFHQ-Wrinkle U-Net | 연결 코드 MIT | 모델 카드가 **CC BY-NC-SA 4.0**을 명시. 비상업·저작자 표시·동일조건 의무 | 512 얼굴 크롭 → 주름 확률 마스크. **주름 제거 모델은 아님**. 개인 비상업 연구 후보이나 사용 제한 없는 기본 오픈소스 모델로 부르지 않음. 모델 카드 검증 IoU 약 0.33, 모바일 속도 미검증. [가중치 카드][wrinkle], [원 데이터 공식 안내][wrinkledata] |

비상업 연구에 무료인 후보와 사용 범위가 제한되지 않은 오픈소스 후보는 다릅니다.
논문에 결과가 있어도 코드·가중치·재배포 조건·기기 결과가 확인되지 않은 후보를
이미 앱에 쓸 수 있는 무료 완성 모듈이라고 소개하지 않습니다.

## 품질 채택 기준

- 현재 방식과 후보를 동일 원본·동일 출력 해상도에서 비교합니다. 정면/측면, 여러 피부톤·
  연령, 웃음·가림·저조도, 깊고 얕은 팔자주름을 포함합니다.
- 팔자 골의 대비 감소와 함께 콧구멍·입술·눈·점·모공·머리 경계 보존을 확인합니다.
  사진 전체를 뽀얗게 만든 결과를 국소 주름 개선으로 세지 않습니다.
- 자동 마스크를 사용자가 수정할 수 있고, 강도 0은 원본이며, 과도한 밝은 띠·
  얼룩·반복 패턴이 없어야 합니다. 불확실한 영역은 약하게 적용합니다.
- Android와 실제 iPhone에서 피크 메모리·처리 시간·발열·오프라인 실행·알파 및 원본
  해상도 저장을 측정합니다. 변환된 신경망은 원본 추론과 수치·시각 결과를 비교합니다.
- 현재까지 어느 후보도 Moru에서 **메이투와 지각 품질 동등**하다고 검증하지 않았습니다.

[cvfilters]: https://docs.opencv.org/4.13.0/da/d17/group__ximgproc__filters.html
[cvinpaint]: https://docs.opencv.org/4.13.0/d7/d8b/group__photo__inpaint.html
[cvlicense]: https://opencv.org/license/
[cvplatforms]: https://opencv.org/platforms/
[cvinstall]: https://docs.opencv.org/4.13.0/d0/d3d/tutorial_general_install.html
[rapid]: https://github.com/crispin81/RapidRetouch/blob/master/README.md
[gpu]: https://github.com/pixpark/gpupixel
[gpuintegration]: https://gpupixel.pixpark.net/guide/integrated
[gpucmake]: https://github.com/pixpark/gpupixel/blob/main/CMakeLists.txt
[gputhird]: https://github.com/pixpark/gpupixel/blob/main/third_party/CMakeLists.txt
[marsdir]: https://github.com/pixpark/gpupixel/tree/main/third_party/mars-face-kit
[gpufilter]: https://github.com/pixpark/gpupixel/blob/main/src/filter/beauty_face_filter.cc
[gpuskin]: https://github.com/pixpark/gpupixel/blob/main/src/filter/beauty_face_unit_filter.cc
[gpuold]: https://github.com/pixpark/gpupixel/blob/v1.2.5/README.md
[gpuintro]: https://gpupixel.pixpark.net/guide/intro
[mscard]: https://www.modelscope.cn/models/iic/cv_unet_skin_retouching_torch/summary
[msreadme]: https://www.modelscope.cn/api/v1/models/iic/cv_unet_skin_retouching_torch/repo?Revision=v1.0.4&FilePath=README.md
[msfiles]: https://www.modelscope.cn/api/v1/models/iic/cv_unet_skin_retouching_torch/repo/files?Revision=v1.0.4&Recursive=true
[mswrapper]: https://www.modelscope.cn/api/v1/models/iic/cv_unet_skin_retouching_torch/repo?Revision=v1.0.4&FilePath=ms_wrapper.py
[mslicense]: https://github.com/modelscope/modelscope/blob/master/LICENSE
[ortmobile]: https://onnxruntime.ai/docs/get-started/with-mobile.html
[ortios]: https://onnxruntime.ai/docs/build/ios.html
[ortandroid]: https://onnxruntime.ai/docs/build/android.html
[ortlicense]: https://github.com/Microsoft/onnxruntime/blob/main/LICENSE
[difflicense]: https://github.com/Adam-duan/DiffRetouch/blob/main/LICENSE
[diffreadme]: https://github.com/Adam-duan/DiffRetouch/blob/main/README.md
[diffenv]: https://github.com/Adam-duan/DiffRetouch/blob/main/environment.yaml
[diffweights]: https://huggingface.co/acceptee/DiffRetouch/tree/main
[rf]: https://github.com/Davidcoach/RetouchFormer_AAAI_24
[rftree]: https://api.github.com/repos/Davidcoach/RetouchFormer_AAAI_24/git/trees/main?recursive=1
[rfinfer]: https://github.com/Davidcoach/RetouchFormer_AAAI_24/blob/main/img_retouching.py
[wrinkle]: https://huggingface.co/rmsandu/ffhq-wrinkle-unet
[wrinkledata]: https://github.com/labhai/ffhq-wrinkle-dataset
