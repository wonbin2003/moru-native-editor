# Moru's image library compatibility patch

This directory contains `lib/`, `pubspec.yaml`, and the unmodified MIT
`LICENSE` from the published **image 4.13.1** package.

- Upstream: https://pub.dev/packages/image/versions/4.13.1
- Source archive: https://pub.dev/api/archives/image-4.13.1.tar.gz
- Archive SHA-256 recorded by Pub:
  `bc13f61f0f5cb77936e78ae5dae3800f442718dac5d2bc4654f03c239230ed0c`
- Upstream repository: https://github.com/brendan-duncan/image

The sole upstream source change is in `lib/src/util/_inflate.dart`.
`inflateLazy` uses an ordinary `InputMemoryStream` on web. The upstream
`_SteppedInput` caps every `readBytes(count)` call at 8,192 bytes. This works
with the native zlib stream but truncates larger stored deflate blocks in
the web implementation. The resulting valid PNG decode silently returns
null. The bundled NASA astronaut PNG reproduced this failure at scanline 5
in a Dart2JS/Node test; its ordinary input stream decoded all 512 rows.

Native zlib keeps the upstream bounded `_SteppedInput`. Zlib checksum
verification remains enabled on every platform. Pixel dimension, encoded
size, animation, and decoder allocation limits also remain enabled.

`test/web_png_test.dart` checks the bundled PNG, orientation normalization,
and a pixel-exact PNG round trip. It can be run on the VM or in Chrome with
`flutter test --platform chrome test/web_png_test.dart`.
