"""Fetch the two pinned, public Apache-2.0 models for native builds.

Uses Python's standard library; never requires an account or an API key.
Use --check to verify a source checkout without downloading anything.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
MODELS = (
    (
        'FaceLandmarker',
        'https://storage.googleapis.com/mediapipe-models/face_landmarker/'
        'face_landmarker/float16/1/face_landmarker.task',
        '64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff',
        'assets/mediapipe/64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff',
    ),
    (
        'SelfieMulticlass',
        'https://storage.googleapis.com/mediapipe-models/image_segmenter/'
        'selfie_multiclass_256x256/float32/1/selfie_multiclass_256x256.tflite',
        'c6748b1253a99067ef71f7e26ca71096cd449baefa8f101900ea23016507e0e0',
        'assets/models/selfie_multiclass_256x256.tflite',
    ),
)


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    for name, url, expected, relative in MODELS:
        target = ROOT / relative
        if target.is_file() and digest(target) == expected:
            print(f'{name}: SHA-256 verified')
            continue
        if args.check:
            raise SystemExit(f'{name}: missing or checksum mismatch: {relative}')
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(target.name + '.download')
        print(f'{name}: downloading official public model')
        request = urllib.request.Request(url, headers={'User-Agent': 'Moru-model-fetch/1.0'})
        with urllib.request.urlopen(request, timeout=60) as response:
            with temporary.open('wb') as output:
                while block := response.read(1024 * 1024):
                    output.write(block)
        if digest(temporary) != expected:
            raise SystemExit(f'{name}: checksum mismatch; refusing to use the download')
        temporary.replace(target)
        print(f'{name}: SHA-256 verified')


if __name__ == '__main__':
    main()
