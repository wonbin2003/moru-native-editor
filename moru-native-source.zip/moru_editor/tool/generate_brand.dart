import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:image/image.dart' as img;

double distance(double x,double y,double ax,double ay,double bx,double by) {
  final dx=bx-ax,dy=by-ay;
  final t=((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy);
  final q=t.clamp(0.0,1.0);
  return math.sqrt(math.pow(x-ax-dx*q,2)+math.pow(y-ay-dy*q,2));
}
img.Image icon(int size) {
  final result=img.Image(width:size,height:size);
  for(final p in result) {
    final x=(p.x+.5)/size,y=(p.y+.5)/size;
    final glow=math.exp(-((x-.7)*(x-.7)+(y-.2)*(y-.2))*5);
    final lines=[distance(x,y,.24,.7,.24,.34),distance(x,y,.24,.34,.5,.60),distance(x,y,.5,.60,.76,.34),distance(x,y,.76,.34,.76,.7)];
    final d=lines.reduce(math.min);
    final sparkle=math.min(distance(x,y,.8,.15,.8,.25),distance(x,y,.75,.2,.85,.2));
    final mask=math.max(((.044-d)*size+.5).clamp(0.0,1.0),((.012-sparkle)*size+.5).clamp(0.0,1.0));
    final bg=[30+glow*18,27+glow*11,34+glow*15];
    final ink=[248.0,193.0+25*y,181.0+35*y];
    p.setRgb(bg[0]+(ink[0]-bg[0])*mask,bg[1]+(ink[1]-bg[1])*mask,bg[2]+(ink[2]-bg[2])*mask);
  }
  return result;
}
void save(String path,int size){File(path)..parent.createSync(recursive:true)..writeAsBytesSync(img.encodePng(icon(size)));}
void main(){
  const density={'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192};
  for(final e in density.entries){save('android/app/src/main/res/mipmap-${e.key}/ic_launcher.png',e.value);}
  final contents=jsonDecode(File('ios/Runner/Assets.xcassets/AppIcon.appiconset/Contents.json').readAsStringSync()) as Map<String,dynamic>;
  for(final entry in contents['images'] as List){
    final filename=entry['filename'] as String?;
    if(filename==null) continue;
    final size=double.parse((entry['size'] as String).split('x').first);
    final scale=double.parse((entry['scale'] as String).replaceAll('x',''));
    save('ios/Runner/Assets.xcassets/AppIcon.appiconset/$filename',(size*scale).round());
  }
  for(final size in [192,512]){save('web/icons/Icon-$size.png',size);save('web/icons/Icon-maskable-$size.png',size);}
  save('web/favicon.png',32);
  save('assets/moru-icon.png',512);
}
