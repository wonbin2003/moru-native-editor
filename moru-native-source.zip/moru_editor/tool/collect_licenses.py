"""Collect redistribution notices from the exact resolved package versions."""
import json
from pathlib import Path
from urllib.parse import urlparse, unquote
import re

root = Path(__file__).resolve().parents[1]
config = root / '.dart_tool/package_config.json'
sections = []
for package in json.loads(config.read_text(encoding='utf-8'))['packages']:
    if package['name'] == 'moru_editor':
        continue
    uri = package['rootUri']
    parsed = urlparse(uri)
    if parsed.scheme == 'file':
        location = unquote(parsed.path)
        if re.match(r'^/[A-Za-z]:/', location):
            location = location[1:]
        directory = Path(location)
    else:
        directory = (config.parent / uri).resolve()
    notices = [p for p in directory.iterdir() if p.is_file() and p.name.lower() in
               ('license', 'license.md', 'license.txt', 'notice', 'notice.md', 'notice.txt')]
    if not notices and package['name'] in ('flutter', 'flutter_test', 'flutter_web_plugins', 'sky_engine'):
        candidate = directory
        while candidate.parent != candidate:
            if (candidate / 'bin/flutter').exists() or (candidate / 'bin/flutter.bat').exists():
                if (candidate / 'LICENSE').exists():
                    notices = [candidate / 'LICENSE']
                break
            candidate = candidate.parent
    for notice in sorted(notices):
        sections.append(f"{'=' * 72}\n{package['name']} / {notice.name}\n{'=' * 72}\n"
                        + notice.read_text(encoding='utf-8', errors='replace'))
output = root / 'licenses/THIRD_PARTY_LICENSES.txt'
output.write_text('\n\n'.join(sections), encoding='utf-8')
print(f'Collected {len(sections)} license/notice texts.')
