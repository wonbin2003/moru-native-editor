package app.moru.moru_editor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
