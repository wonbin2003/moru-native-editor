import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/editor_engine.dart';
import 'package:moru_editor/face_service.dart';

typedef _Setting = EditSettings Function(double value);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'fine controls independently edit a real detected portrait in both directions',
    () async {
      final input = await normalizePhoto(
        await File('assets/samples/astronaut.png').readAsBytes(),
      );
      final faces = await detectFaces(input);
      expect(faces, hasLength(1));
      final neutral = img.decodePng(
        await renderImage(
          input,
          const EditSettings(),
          faces: faces,
          maxDimension: 0,
        ),
      )!;
      final baseline = neutral.getBytes(order: img.ChannelOrder.rgba);
      final cases = <String, _Setting>{
        'noseAlarWidth': (v) => EditSettings(noseAlarWidth: v),
        'noseBridgeWidth': (v) => EditSettings(noseBridgeWidth: v),
        'noseDorsumWidth': (v) => EditSettings(noseDorsumWidth: v),
        'noseTipSize': (v) => EditSettings(noseTipSize: v),
        'noseTipLift': (v) => EditSettings(noseTipLift: v),
        'noseLength': (v) => EditSettings(noseLength: v),
        'nosePosition': (v) => EditSettings(nosePosition: v),
        'eyeWidth': (v) => EditSettings(eyeWidth: v),
        'eyeHeight': (v) => EditSettings(eyeHeight: v),
        'eyeSpacing': (v) => EditSettings(eyeSpacing: v),
        'eyeTilt': (v) => EditSettings(eyeTilt: v),
        'eyePosition': (v) => EditSettings(eyePosition: v),
        'lipWidth': (v) => EditSettings(lipWidth: v),
        'upperLipFullness': (v) => EditSettings(upperLipFullness: v),
        'lowerLipFullness': (v) => EditSettings(lowerLipFullness: v),
        'mouthPosition': (v) => EditSettings(mouthPosition: v),
        'mouthSmile': (v) => EditSettings(mouthSmile: v),
        'cheekboneWidth': (v) => EditSettings(cheekboneWidth: v),
        'jawWidth': (v) => EditSettings(jawWidth: v),
        'chinWidth': (v) => EditSettings(chinWidth: v),
        'faceLength': (v) => EditSettings(faceLength: v),
        'browHeight': (v) => EditSettings(browHeight: v),
        'browSpacing': (v) => EditSettings(browSpacing: v),
        'browTilt': (v) => EditSettings(browTilt: v),
      };
      final fingerprints = <int>{};
      final qa = Directory('../qa/fine-controls')..createSync(recursive: true);
      await File('${qa.path}/original.png').writeAsBytes(input);
      for (final entry in cases.entries) {
        final fingerprintsForControl = <int>{};
        for (final value in [-.75, .75]) {
          final settings = entry.value(value);
          expect(settings.isNeutral, isFalse, reason: entry.key);
          final output = await renderImage(
            input,
            settings,
            faces: faces,
            maxDimension: 0,
          );
          final decoded = img.decodePng(output)!;
          expect(
            (decoded.width, decoded.height),
            (neutral.width, neutral.height),
            reason: entry.key,
          );
          final pixels = decoded.getBytes(order: img.ChannelOrder.rgba);
          var changed = 0;
          for (var offset = 0; offset < pixels.length; offset += 4) {
            if (pixels[offset] != baseline[offset] ||
                pixels[offset + 1] != baseline[offset + 1] ||
                pixels[offset + 2] != baseline[offset + 2]) {
              changed++;
            }
          }
          expect(
            changed,
            greaterThan(12),
            reason: '${entry.key} $value must visibly edit pixels',
          );
          expect(
            changed,
            lessThan(neutral.width * neutral.height ~/ 3),
            reason: '${entry.key} must remain local',
          );
          // Background corner is far from the astronaut's detected face.
          for (var y = 0; y < 20; y++) {
            for (var x = 0; x < 20; x++) {
              final offset = (y * neutral.width + x) * 4;
              expect(
                pixels.sublist(offset, offset + 4),
                baseline.sublist(offset, offset + 4),
                reason: entry.key,
              );
            }
          }
          final fingerprint = _fingerprint(pixels);
          expect(
            fingerprints.add(fingerprint),
            isTrue,
            reason: '${entry.key} $value should have a distinct result',
          );
          fingerprintsForControl.add(fingerprint);
          if (entry.key.startsWith('nose')) {
            await File(
              '${qa.path}/${entry.key}-${value < 0 ? 'minus' : 'plus'}.png',
            ).writeAsBytes(output);
          }
        }
        expect(
          fingerprintsForControl,
          hasLength(2),
          reason: '${entry.key} directions must differ',
        );
      }
      // Without detected landmarks, facial controls must not modify a random area.
      final noFace = img.decodePng(
        await renderImage(
          input,
          const EditSettings(noseAlarWidth: .75, browTilt: -.75),
          maxDimension: 0,
        ),
      )!;
      expect(
        noFace.getBytes(order: img.ChannelOrder.rgba),
        orderedEquals(baseline),
      );
    },
    timeout: const Timeout(Duration(minutes: 5)),
  );
}

int _fingerprint(Uint8List values) {
  var hash = 0x811c9dc5;
  for (final value in values) {
    hash = ((hash ^ value) * 0x01000193) & 0xffffffff;
  }
  return hash;
}
