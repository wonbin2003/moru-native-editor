import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/face_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'normalization preserves full PNG dimensions and transparent pixels',
    () async {
      final source = img.Image(width: 19, height: 11, numChannels: 4);
      source.setPixelRgba(3, 4, 120, 40, 230, 77);
      final result = img.decodePng(
        await normalizePhoto(img.encodePng(source)),
      )!;
      expect((result.width, result.height), (19, 11));
      final pixel = result.getPixel(3, 4);
      expect([pixel.r, pixel.g, pixel.b, pixel.a], [120, 40, 230, 77]);
    },
  );

  test('JPEG EXIF clockwise rotation is baked exactly once', () async {
    final source = _quadrants()..exif.imageIfd.orientation = 6;
    final result = img.decodePng(
      await normalizePhoto(img.encodeJpg(source, quality: 100)),
    )!;
    expect((result.width, result.height), (20, 40));
    // Source bottom-left blue rotates into upright top-left.
    final topLeft = result.getPixel(5, 5);
    expect(topLeft.b, greaterThan(200));
    expect(topLeft.r, lessThan(40));
    final bottomRight = result.getPixel(15, 35);
    expect(bottomRight.g, greaterThan(200));
    expect(bottomRight.r, lessThan(40));
    expect(result.exif.imageIfd.hasOrientation, isFalse);
  });

  test('JPEG EXIF reflection is respected', () async {
    final source = _quadrants()..exif.imageIfd.orientation = 2;
    final result = img.decodePng(
      await normalizePhoto(img.encodeJpg(source, quality: 100)),
    )!;
    expect((result.width, result.height), (40, 20));
    final topLeft = result.getPixel(5, 5);
    expect(topLeft.g, greaterThan(200));
    expect(topLeft.r, lessThan(40));
  });

  test('unsupported and truncated formats fail explicitly', () async {
    await expectLater(
      normalizePhoto(Uint8List.fromList([0, 0, 0, 12, 102, 116, 121, 112])),
      throwsA(
        isA<PhotoInputException>().having(
          (e) => e.code,
          'code',
          PhotoInputFailure.unsupportedFormat,
        ),
      ),
    );
    await expectLater(
      normalizePhoto(Uint8List.fromList([137, 80, 78, 71, 13, 10, 26, 10])),
      throwsA(isA<PhotoInputException>()),
    );
  });

  test(
    'large dimensions fail before pixel allocation instead of being resized',
    () async {
      final encoded = img.encodeJpg(img.Image(width: 4, height: 4));
      var patched = false;
      for (var i = 0; i < encoded.length - 8; i++) {
        if (encoded[i] == 0xff && encoded[i + 1] == 0xc0) {
          // SOF: marker, segment length, precision, height, width.
          encoded[i + 5] = 5000 >> 8;
          encoded[i + 6] = 5000 & 255;
          encoded[i + 7] = 6000 >> 8;
          encoded[i + 8] = 6000 & 255;
          patched = true;
          break;
        }
      }
      expect(patched, isTrue);
      await expectLater(
        normalizePhoto(encoded),
        throwsA(
          isA<PhotoInputException>().having(
            (e) => e.code,
            'code',
            PhotoInputFailure.tooLarge,
          ),
        ),
      );
    },
  );
}

img.Image _quadrants() {
  final image = img.Image(width: 40, height: 20);
  for (final pixel in image) {
    if (pixel.x < 20) {
      pixel.setRgb(pixel.y < 10 ? 255 : 0, 0, pixel.y < 10 ? 0 : 255);
    } else {
      pixel.setRgb(pixel.y < 10 ? 0 : 255, 255, 0);
    }
  }
  return image;
}
