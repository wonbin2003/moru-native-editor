import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/reference_style.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('same-photo reference preserves geometry, alpha and colour within rounding', () async {
    final photo = img.Image(width: 64, height: 48, numChannels: 4);
    for (final p in photo) { p.setRgba(50+p.x*2, 40+p.y*3, 90+p.x, p.x == 0 ? 0 : 255); }
    final bytes = img.encodePng(photo);
    final result = img.decodePng(await matchReferenceStyle(bytes, bytes))!;
    expect((result.width, result.height), (64, 48));
    for (final p in photo) {
      final q = result.getPixel(p.x,p.y);
      expect(q.a, p.a);
      expect((q.r-p.r).abs(), lessThanOrEqualTo(1));
      expect((q.g-p.g).abs(), lessThanOrEqualTo(1));
      expect((q.b-p.b).abs(), lessThanOrEqualTo(1));
    }
  });
}
