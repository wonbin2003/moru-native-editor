import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/face_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'real PNG stored-deflate blocks decode and round-trip on VM and web',
    () async {
      final asset = await rootBundle.load('assets/samples/astronaut.png');
      final bytes = asset.buffer.asUint8List(
        asset.offsetInBytes,
        asset.lengthInBytes,
      );
      final decoder = img.PngDecoder(maxPixels: maxPhotoPixels);
      final header = decoder.startDecode(bytes)!;
      expect((header.width, header.height), (512, 512));
      final source = decoder.decodeFrame(0);
      expect(
        source,
        isNotNull,
        reason: 'Valid stored deflate blocks must not be truncated.',
      );
      final normalized = img.decodePng(await normalizePhoto(bytes));
      expect(normalized, isNotNull);
      expect((normalized!.width, normalized.height), (512, 512));
      expect(
        normalized.getBytes(order: img.ChannelOrder.rgba),
        orderedEquals(source!.getBytes(order: img.ChannelOrder.rgba)),
      );
      // Level zero deliberately emits stored deflate blocks larger than 8KB.
      final roundTrip = img.decodePng(img.encodePng(normalized, level: 0));
      expect(roundTrip, isNotNull);
      expect(
        roundTrip!.getBytes(order: img.ChannelOrder.rgba),
        orderedEquals(normalized.getBytes(order: img.ChannelOrder.rgba)),
      );
    },
  );
}
