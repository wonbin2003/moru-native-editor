import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:moru_editor/face_service.dart';
import 'package:moru_editor/main.dart';

void main() {
  testWidgets(
    'mobile retouch exposes independent face parts, fold removal, and touch brushes',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.runAsync(() async {
        final data = await rootBundle.load('assets/samples/astronaut.png');
        final bytes = data.buffer.asUint8List(
          data.offsetInBytes,
          data.lengthInBytes,
        );
        try {
          await tester.pumpWidget(MoruApp(initialBytes: bytes));
          final wait = Stopwatch()..start();
          while (wait.elapsed < const Duration(seconds: 45)) {
            await Future<void>.delayed(const Duration(milliseconds: 40));
            await tester.pump(const Duration(milliseconds: 16));
            expect(tester.takeException(), isNull);
            if (find.textContaining('512 × 512').evaluate().isNotEmpty) break;
          }
          expect(find.textContaining('512 × 512'), findsOneWidget);

          Future<void> chooseRetouch(String section) async {
            final finder = find.byKey(ValueKey('retouch-section-$section'));
            await tester.ensureVisible(finder);
            await tester.tap(finder);
            await tester.pump(const Duration(milliseconds: 100));
            expect(tester.takeException(), isNull);
          }

          for (final section in ['자동', '얼굴보정', '피부', '볼륨·리프팅', '메이크업', '브러쉬']) {
            expect(
              find.byKey(ValueKey('retouch-section-$section')),
              findsOneWidget,
            );
          }
          await chooseRetouch('얼굴보정');
          const controls = <String, List<String>>{
            '윤곽': ['머리 크기', '광대 너비', '턱선 너비', '턱끝 너비', '얼굴 길이'],
            '눈': ['눈 가로 폭', '눈 세로 폭', '눈 사이 간격', '눈꼬리 각도', '눈 위치'],
            '코': ['콧망울 너비', '콧대 너비', '콧등 너비', '코끝 크기', '코끝 들기', '코 길이', '코 위치'],
            '입': ['입 너비', '윗입술 볼륨', '아랫입술 볼륨', '입 위치', '입꼬리'],
            '눈썹': ['눈썹 높이', '눈썹 간격', '눈썹 각도'],
          };
          for (final part in controls.entries) {
            final section = find.byKey(ValueKey('face-section-${part.key}'));
            await tester.ensureVisible(section);
            await tester.tap(section);
            await tester.pump(const Duration(milliseconds: 100));
            for (final label in part.value) {
              final chip = find.byKey(
                ValueKey('control-리터치-${part.key}-$label'),
              );
              await tester.ensureVisible(chip);
              await tester.tap(chip);
              await tester.pump(const Duration(milliseconds: 80));
              final slider = find.byKey(
                ValueKey('slider-리터치-${part.key}-$label'),
              );
              expect(slider, findsOneWidget);
              final widget = tester.widget<Slider>(slider);
              expect(
                (widget.min, widget.max, widget.value),
                (-1, 1, 0),
                reason: label,
              );
              expect(widget.divisions, 200);
              expect(tester.takeException(), isNull);
            }
          }

          await chooseRetouch('피부');
          // This is the first control, available immediately without scrolling
          // through a long horizontal strip of unrelated skin settings.
          final fold = find.byKey(const ValueKey('slider-리터치-눈썹-팔자주름 제거'));
          expect(fold, findsOneWidget);
          final foldSlider = tester.widget<Slider>(fold);
          expect((foldSlider.min, foldSlider.max, foldSlider.value), (0, 1, 0));
          expect(
            find.byKey(const ValueKey('control-리터치-눈썹-잔주름 완화')),
            findsOneWidget,
          );

          await chooseRetouch('브러쉬');
          final wrinkleBrush = find.byKey(const ValueKey('brush-wrinkle'));
          await tester.ensureVisible(wrinkleBrush);
          await tester.tap(wrinkleBrush);
          await tester.pump(const Duration(milliseconds: 100));
          expect(tester.widget<FilterChip>(wrinkleBrush).selected, isTrue);
          expect(find.byKey(const ValueKey('brush-radius')), findsOneWidget);
          expect(find.byKey(const ValueKey('brush-strength')), findsOneWidget);
          final canvasFinder = find.byKey(const ValueKey('photo-touch-canvas'));
          final canvas = tester.widget<GestureDetector>(canvasFinder);
          expect(canvas.onPanStart, isNotNull);
          expect(canvas.onPanUpdate, isNotNull);
          expect(canvas.onPanEnd, isNotNull);
          expect(canvas.onTapUp, isNotNull);
          final ignoredViewer = find.descendant(
            of: canvasFinder,
            matching: find.byWidgetPredicate(
              (widget) => widget is IgnorePointer && widget.ignoring,
            ),
          );
          expect(
            ignoredViewer,
            findsOneWidget,
            reason:
                'The zoom recognizer must yield pointer events to the retouch brush.',
          );
          expect(tester.takeException(), isNull);

          await chooseRetouch('자동');
          Future<void> choosePreset(String preset) async {
            final finder = find.byKey(ValueKey('retouch-preset-$preset'));
            await tester.ensureVisible(finder);
            await tester.tap(finder);
            await tester.pump(const Duration(milliseconds: 30));
          }

          Slider autoSlider() => tester.widget<Slider>(
            find.byKey(const ValueKey('automatic-intensity')),
          );
          bool selectedPreset(String preset) => tester
              .widget<ChoiceChip>(
                find.byKey(ValueKey('retouch-preset-$preset')),
              )
              .selected;
          Future<void> historyAction(String tooltip) async {
            await tester.tap(find.byTooltip(tooltip));
            await tester.pump(const Duration(milliseconds: 30));
          }

          expect(
            autoSlider().value,
            0,
            reason:
                'A neutral import must not claim that 50% auto retouch is already applied.',
          );
          await choosePreset('natural');
          expect(
            autoSlider().value,
            .5,
            reason:
                'Clicking even the selected preset from zero must apply a useful default strength.',
          );
          await historyAction('되돌리기');
          expect(autoSlider().value, 0);
          await choosePreset('fresh');
          expect(selectedPreset('fresh'), isTrue);
          expect(autoSlider().value, .5);
          final beforeDrag = autoSlider();
          beforeDrag.onChangeStart!(beforeDrag.value);
          beforeDrag.onChanged!(.82);
          beforeDrag.onChangeEnd!(.82);
          await tester.pump(const Duration(milliseconds: 30));
          await choosePreset('clear');
          expect(selectedPreset('clear'), isTrue);
          expect(autoSlider().value, .82);

          await historyAction('되돌리기');
          expect(
            selectedPreset('fresh'),
            isTrue,
            reason:
                'Undo must restore the recipe shown, alongside its pixel settings.',
          );
          expect(autoSlider().value, .82);
          await historyAction('되돌리기');
          expect(selectedPreset('fresh'), isTrue);
          expect(
            autoSlider().value,
            .5,
            reason:
                'Undoing the intensity drag must restore its previous visible value.',
          );
          await historyAction('되돌리기');
          expect(selectedPreset('natural'), isTrue);
          await historyAction('다시 적용');
          expect(selectedPreset('fresh'), isTrue);
          expect(autoSlider().value, .5);

          // A subsequent slider move must use the restored fresh recipe,
          // rather than the stale clear recipe selected before Undo.
          final restored = autoSlider();
          restored.onChangeStart!(restored.value);
          restored.onChanged!(.6);
          restored.onChangeEnd!(.6);
          await tester.pump(const Duration(milliseconds: 30));
          await chooseRetouch('메이크업');
          final lipSlider = tester.widget<Slider>(
            find.byKey(const ValueKey('slider-리터치-눈썹-립 컬러')),
          );
          expect(
            lipSlider.value,
            closeTo(.6 * .28, .00001),
            reason:
                'Fresh lipstick strength differs from Clear; history must restore the recipe used next.',
          );
          await chooseRetouch('자동');
          final off = autoSlider();
          off.onChangeStart!(off.value);
          off.onChanged!(0);
          off.onChangeEnd!(0);
          await tester.pump(const Duration(milliseconds: 30));
          expect(autoSlider().value, 0);
          await chooseRetouch('메이크업');
          expect(
            tester
                .widget<Slider>(
                  find.byKey(const ValueKey('slider-리터치-눈썹-립 컬러')),
                )
                .value,
            0,
            reason:
                'Zero auto strength must really switch the recipe effect off.',
          );

          await chooseRetouch('자동');
          await choosePreset('fresh');
          expect(autoSlider().value, .5);
          await tester.tap(find.text('도구'));
          await tester.pump(const Duration(milliseconds: 30));
          final flip = find.widgetWithText(TextButton, '좌우 반전');
          await tester.ensureVisible(flip);
          await tester.tap(flip);
          await tester.pump(const Duration(milliseconds: 30));
          final commitWait = Stopwatch()..start();
          while (commitWait.elapsed < const Duration(seconds: 25) &&
              find.text('사진 편집 중').evaluate().isNotEmpty) {
            await Future<void>.delayed(const Duration(milliseconds: 40));
            await tester.pump(const Duration(milliseconds: 16));
          }
          expect(find.text('사진 편집 중'), findsNothing);
          await tester.tap(find.text('리터치'));
          await tester.pump(const Duration(milliseconds: 30));
          await chooseRetouch('자동');
          expect(
            autoSlider().value,
            0,
            reason:
                'A new raster base must start with neutral adjustment metadata.',
          );
          expect(selectedPreset('natural'), isTrue);
          await historyAction('되돌리기');
          expect(selectedPreset('fresh'), isTrue);
          expect(
            autoSlider().value,
            .5,
            reason:
                'Undoing the raster edit must restore the prior automatic recipe metadata.',
          );
          expect(tester.takeException(), isNull);
        } finally {
          await tester.pumpWidget(const SizedBox.shrink());
          await disposeFaceDetector().timeout(const Duration(seconds: 5));
          await tester.pump();
        }
      });
    },
    timeout: const Timeout(Duration(seconds: 90)),
  );
}
