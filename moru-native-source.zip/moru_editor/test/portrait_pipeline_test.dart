import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/editor_engine.dart';
import 'package:moru_editor/face_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'real bundled model and portrait render preserve dimensions and eye structure',
    () async {
      final original = await File('assets/samples/astronaut.png').readAsBytes();
      final normalized = await normalizePhoto(original);
      final faces = await detectFaces(normalized).catchError((Object error) {
        if (error is FaceDetectionException) {
          // Keep the underlying native error visible in integration test logs.
          stderr.writeln('MediaPipe failure: ${error.cause}');
        }
        throw error;
      });
      expect(faces, hasLength(1));
      expect(faces.first.points, hasLength(478));
      final output = await renderImage(
        normalized,
        const EditSettings(
          skinSmooth: .42,
          skinBrighten: .12,
          faceSlim: .12,
          eyeEnlarge: .06,
          lipstick: .12,
          blush: .10,
        ),
        faces: faces,
        maxDimension: 0,
      );
      final source = img.decodeImage(normalized)!;
      final edited = img.decodeImage(output)!;
      expect((edited.width, edited.height), (source.width, source.height));
      expect(output, isNot(orderedEquals(normalized)));
      final qa = Directory('../qa')..createSync(recursive: true);
      File('${qa.path}/portrait-original.png').writeAsBytesSync(normalized);
      File('${qa.path}/portrait-edited.png').writeAsBytesSync(output);
      File('${qa.path}/landmarks.json').writeAsStringSync(
        '[${faces.first.points.map((p) => '[${p.x},${p.y}]').join(',')}]',
      );
    },
    timeout: const Timeout(Duration(minutes: 3)),
  );
}
