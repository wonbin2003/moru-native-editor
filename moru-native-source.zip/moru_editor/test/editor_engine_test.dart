import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as im;
import 'package:moru_editor/editor_engine.dart';

Uint8List fixture({int width = 80, int height = 100}) {
  final image = im.Image(width: width, height: height, numChannels: 4);
  for (var y = 0; y < height; y++) {
    for (var x = 0; x < width; x++) {
      image.setPixelRgba(
        x,
        y,
        (x * 3 + y) % 256,
        (y * 2 + x) % 256,
        (x + y * 3) % 256,
        255,
      );
    }
  }
  return Uint8List.fromList(im.encodePng(image));
}

FaceGeometry syntheticFace() {
  final p = List<FacePoint>.filled(478, const FacePoint(.5, .5));
  const oval = [
    10,
    338,
    297,
    332,
    284,
    251,
    389,
    356,
    454,
    323,
    361,
    288,
    397,
    365,
    379,
    378,
    400,
    377,
    152,
    148,
    176,
    149,
    150,
    136,
    172,
    58,
    132,
    93,
    234,
    127,
    162,
    21,
    54,
    103,
    67,
    109,
  ];
  const coords = [
    [.5, .12],
    [.58, .125],
    [.65, .15],
    [.71, .18],
    [.75, .22],
    [.78, .27],
    [.80, .32],
    [.81, .37],
    [.81, .42],
    [.80, .48],
    [.78, .55],
    [.75, .62],
    [.71, .69],
    [.67, .75],
    [.62, .79],
    [.58, .82],
    [.55, .84],
    [.52, .85],
    [.5, .86],
    [.48, .85],
    [.45, .84],
    [.42, .82],
    [.38, .79],
    [.33, .75],
    [.29, .69],
    [.25, .62],
    [.22, .55],
    [.20, .48],
    [.19, .42],
    [.19, .37],
    [.20, .32],
    [.22, .27],
    [.25, .22],
    [.29, .18],
    [.35, .15],
    [.42, .125],
  ];
  for (var i = 0; i < oval.length; i++) {
    p[oval[i]] = FacePoint(coords[i][0], coords[i][1]);
  }
  p[168] = const FacePoint(.5, .40);
  p[1] = const FacePoint(.5, .52);
  final left = [
    33,
    7,
    163,
    144,
    145,
    153,
    154,
    155,
    133,
    173,
    157,
    158,
    159,
    160,
    161,
    246,
  ];
  final right = [
    263,
    249,
    390,
    373,
    374,
    380,
    381,
    382,
    362,
    398,
    384,
    385,
    386,
    387,
    388,
    466,
  ];
  for (var i = 0; i < left.length; i++) {
    final t = i < 8 ? i / 7 : (15 - i) / 7;
    p[left[i]] = FacePoint(.29 + t * .15, i < 8 ? .41 : .36);
    p[right[i]] = FacePoint(.71 - t * .15, i < 8 ? .41 : .36);
  }
  p[50] = const FacePoint(.33, .55);
  p[280] = const FacePoint(.67, .55);
  return FaceGeometry(points: p);
}

void samePixels(im.Image a, im.Image b) {
  expect(b.width, a.width);
  expect(b.height, a.height);
  for (var y = 0; y < a.height; y++) {
    for (var x = 0; x < a.width; x++) {
      final p = a.getPixel(x, y), q = b.getPixel(x, y);
      expect([q.r, q.g, q.b, q.a], [p.r, p.g, p.b, p.a], reason: 'pixel $x,$y');
    }
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('neutral full-size rendering preserves pixels and dimensions', () async {
    final bytes = fixture();
    final rendered = await renderImage(
      bytes,
      const EditSettings(),
      maxDimension: 0,
    );
    samePixels(im.decodePng(bytes)!, im.decodePng(rendered)!);
  });
  test(
    'preview limit preserves aspect and full export keeps original pixels',
    () async {
      final bytes = fixture(width: 120, height: 80);
      final preview = im.decodePng(
        await renderImage(bytes, const EditSettings(), maxDimension: 60),
      )!;
      expect([preview.width, preview.height], [60, 40]);
      final full = im.decodePng(
        await renderImage(
          bytes,
          const EditSettings(exposure: .1),
          maxDimension: 0,
        ),
      )!;
      expect([full.width, full.height], [120, 80]);
    },
  );
  test(
    'beauty controls never change background when no face was detected',
    () async {
      final bytes = fixture();
      final result = await renderImage(
        bytes,
        const EditSettings(
          skinSmooth: 1,
          skinBrighten: 1,
          faceSlim: 1,
          eyeEnlarge: 1,
          noseSlim: 1,
          lipstick: 1,
          blush: 1,
          teethWhiten: 1,
          eyeBrighten: 1,
        ),
        maxDimension: 0,
      );
      samePixels(im.decodePng(bytes)!, im.decodePng(result)!);
    },
  );
  test(
    'face warp is local and keeps distant background completely unchanged',
    () async {
      final bytes = fixture(width: 160, height: 200),
          src = im.decodePng(bytes)!;
      final out = im.decodePng(
        await renderImage(
          bytes,
          const EditSettings(
            faceSlim: 1,
            eyeEnlarge: 1,
            noseSlim: 1,
            chinLength: 1,
          ),
          faces: [syntheticFace()],
          maxDimension: 0,
        ),
      )!;
      for (var y = 0; y < src.height; y++) {
        for (final x in [
          0,
          1,
          2,
          src.width - 3,
          src.width - 2,
          src.width - 1,
        ]) {
          final a = src.getPixel(x, y), b = out.getPixel(x, y);
          expect([b.r, b.g, b.b], [a.r, a.g, a.b]);
        }
      }
      var changed = 0;
      for (var y = 0; y < src.height; y++) {
        for (var x = 0; x < src.width; x++) {
          if (src.getPixel(x, y).r != out.getPixel(x, y).r) changed++;
        }
      }
      expect(changed, greaterThan(50));
    },
  );
  test('tonal extremes stay valid and grain is deterministic', () async {
    final bytes = fixture();
    const settings = EditSettings(
      exposure: 2,
      contrast: 2,
      saturation: -2,
      warmth: 2,
      shadows: 1,
      highlights: -1,
      grain: 1,
      vignette: 1,
      sharpness: 1,
      filter: 'film',
    );
    final a = await renderImage(bytes, settings, maxDimension: 0),
        b = await renderImage(bytes, settings, maxDimension: 0);
    expect(a, b);
    expect(im.decodePng(a)!.width, 80);
  });
  test('crop, rotation and mirror preserve expected geometry', () async {
    final bytes = fixture(width: 80, height: 100);
    final crop = im.decodePng(await cropImage(bytes, 1))!;
    expect([crop.width, crop.height], [80, 80]);
    final rotated = im.decodePng(await rotateImage(bytes))!;
    expect([rotated.width, rotated.height], [100, 80]);
    final mirrored = im.decodePng(await flipImage(bytes))!,
        src = im.decodePng(bytes)!;
    expect(mirrored.getPixel(0, 10).r, src.getPixel(79, 10).r);
    await expectLater(cropImage(bytes, 0), throwsArgumentError);
  });
  test(
    'healing removes a small blemish and leaves exterior pixels unchanged',
    () async {
      final src = im.Image(width: 100, height: 100, numChannels: 4);
      for (var y = 0; y < 100; y++) {
        for (var x = 0; x < 100; x++) {
          final dark = (x - 50) * (x - 50) + (y - 50) * (y - 50) < 9;
          src.setPixelRgba(
            x,
            y,
            dark ? 50 : 180,
            dark ? 30 : 130,
            dark ? 25 : 110,
            255,
          );
        }
      }
      final bytes = Uint8List.fromList(im.encodePng(src));
      final result = im.decodePng(
        await applyBrush(
          bytes,
          'heal',
          [const FacePoint(.5, .5)],
          radius: .08,
          strength: 1,
        ),
      )!;
      expect(result.getPixel(50, 50).r, greaterThan(150));
      expect(result.getPixel(10, 10).r, 180);
    },
  );
  test('brush strokes clip at bounds and zero strength is lossless', () async {
    final bytes = fixture();
    final unchanged = await applyBrush(bytes, 'blur', [
      const FacePoint(.2, .3),
    ], strength: 0);
    samePixels(im.decodePng(bytes)!, im.decodePng(unchanged)!);
    for (final tool in ['blur', 'smooth', 'mosaic', 'liquify']) {
      final out = await applyBrush(bytes, tool, [
        const FacePoint(-.1, .0),
        const FacePoint(.1, .1),
      ], radius: .2);
      expect(im.decodePng(out)!.width, 80);
    }
  });
  test(
    'skin smoothing preserves eye detail and background while treating cheek noise',
    () async {
      final src = im.Image(width: 400, height: 400, numChannels: 4);
      for (var y = 0; y < 400; y++) {
        for (var x = 0; x < 400; x++) {
          final n = (x + y).isEven ? 7 : -7;
          final inEye = x >= 120 && x <= 172 && y >= 146 && y <= 161;
          src.setPixelRgba(
            x,
            y,
            inEye ? 25 : 180 + n,
            inEye ? 18 : 130 + n,
            inEye ? 12 : 110 + n,
            255,
          );
        }
      }
      final result = im.decodePng(
        await renderImage(
          Uint8List.fromList(im.encodePng(src)),
          const EditSettings(skinSmooth: 1, skinBrighten: .5),
          faces: [syntheticFace()],
          maxDimension: 0,
        ),
      )!;
      for (var y = 150; y <= 157; y++) {
        for (var x = 130; x <= 160; x++) {
          expect(
            result.getPixel(x, y).r,
            src.getPixel(x, y).r,
            reason: 'eye detail at $x,$y',
          );
        }
      }
      expect(result.getPixel(5, 5).r, src.getPixel(5, 5).r);
      var altered = 0;
      for (var y = 200; y < 230; y++) {
        for (var x = 110; x < 140; x++) {
          if (result.getPixel(x, y).r != src.getPixel(x, y).r) altered++;
        }
      }
      expect(altered, greaterThan(100));
    },
  );
  test(
    'facial edits follow the head after a 90 degree photo rotation',
    () async {
      final bytes = fixture(width: 160, height: 200);
      final source = im.decodePng(bytes)!;
      final face = syntheticFace();
      const settings = EditSettings(
        faceSlim: .8,
        eyeEnlarge: .7,
        noseSlim: .6,
        chinLength: .7,
      );
      final originalEdit = im.decodePng(
        await renderImage(bytes, settings, faces: [face], maxDimension: 0),
      )!;
      final expected = im.copyRotate(originalEdit, angle: 90);
      final rotatedSource = im.copyRotate(source, angle: 90);
      // Map actual pixel coordinates through the same clockwise rotation.
      final rotatedFace = FaceGeometry(
        points: face.points
            .map(
              (point) => FacePoint(
                (source.height - 1 - point.y * source.height) /
                    rotatedSource.width,
                point.x * source.width / rotatedSource.height,
              ),
            )
            .toList(),
      );
      final actual = im.decodePng(
        await renderImage(
          Uint8List.fromList(im.encodePng(rotatedSource)),
          settings,
          faces: [rotatedFace],
          maxDimension: 0,
        ),
      )!;
      expect([actual.width, actual.height], [expected.width, expected.height]);
      var totalError = 0.0;
      var maxError = 0.0;
      for (var y = 0; y < actual.height; y++) {
        for (var x = 0; x < actual.width; x++) {
          final a = actual.getPixel(x, y), b = expected.getPixel(x, y);
          for (final error in [
            (a.r - b.r).abs(),
            (a.g - b.g).abs(),
            (a.b - b.b).abs(),
          ]) {
            totalError += error;
            if (error > maxError) maxError = error.toDouble();
          }
        }
      }
      expect(totalError / (actual.width * actual.height * 3), lessThan(.15));
      expect(maxError, lessThanOrEqualTo(2));
    },
  );
}
