import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:moru_editor/face_service.dart';
import 'package:moru_editor/main.dart';

/// Also runnable in Chrome:
/// flutter test --platform chrome test/ui_import_test.dart
/// No detector is mocked. A browser test host without the app's self-hosted
/// WASM files may use the editor's supported manual-edit fallback; importing,
/// decoded pixels, dimensions, and the enabled Save action must still work.
void main() {
  testWidgets(
    'real photo import reaches the editor with dimensions and Save',
    (tester) async {
      tester.view.physicalSize = const Size(1280, 900);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      final bytes = await tester.runAsync(() async {
        final asset = await rootBundle.load('assets/samples/astronaut.png');
        return asset.buffer.asUint8List(
          asset.offsetInBytes,
          asset.lengthInBytes,
        );
      });
      expect(bytes, isNotNull);

      await tester.runAsync(() async {
        try {
          await tester.pumpWidget(MoruApp(initialBytes: bytes));
          final deadline = Stopwatch()..start();
          var imported = false;
          while (deadline.elapsed < const Duration(seconds: 45)) {
            // Keep the import and its native callbacks in a real async zone.
            // Pump individual frames; never wait on
            // pumpAndSettle while the loading indicator is continuously animated.
            await Future<void>.delayed(const Duration(milliseconds: 50));
            await tester.pump(const Duration(milliseconds: 16));
            expect(tester.takeException(), isNull);
            final failedImport = find.textContaining('사진을 읽을 수 없어요.');
            expect(
              failedImport,
              findsNothing,
              reason: 'Photo import must not fall back to the welcome screen.',
            );
            final dimensions = find.textContaining('512 × 512');
            final save = find.widgetWithText(FilledButton, '저장');
            final decodedPreview = tester
                .widgetList<RawImage>(find.byType(RawImage))
                .any(
                  (widget) =>
                      widget.image?.width == 512 && widget.image?.height == 512,
                );
            if (dimensions.evaluate().isNotEmpty &&
                save.evaluate().isNotEmpty &&
                decodedPreview) {
              imported = true;
              break;
            }
          }

          expect(
            imported,
            isTrue,
            reason:
                'Photo import did not complete within 45 seconds. '
                'Dimensions: ${find.textContaining('512 × 512').evaluate().length}; '
                'Save: ${find.text('저장').evaluate().length}; '
                'Preview images: ${find.byType(RawImage).evaluate().length}.',
          );
          expect(find.text('샘플로 둘러보기'), findsNothing);
          expect(find.textContaining('512 × 512'), findsOneWidget);
          final save = tester.widget<FilledButton>(
            find.widgetWithText(FilledButton, '저장'),
          );
          expect(save.onPressed, isNotNull);
          // The VM test runs the actual bundled model, beyond the basic import
          // regression. Browser model availability depends on its test host.
          if (!kIsWeb) {
            expect(find.textContaining('얼굴 1명'), findsOneWidget);
          }
        } finally {
          await tester.pumpWidget(const SizedBox.shrink());
          await disposeFaceDetector().timeout(const Duration(seconds: 5));
          await tester.pump();
        }
      });
      expect(tester.takeException(), isNull);
    },
    timeout: const Timeout(Duration(seconds: 90)),
  );
}
