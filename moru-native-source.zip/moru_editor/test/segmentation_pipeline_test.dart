import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/segmentation_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'bundled official model creates full-resolution cutout, blur, background and hair edits',
    () async {
      final source = await File('assets/samples/astronaut.png').readAsBytes();
      final output = await segmentEdit(source, effect: 'cutout').catchError((
        Object error,
      ) {
        if (error is SegmentationException) {
          stderr.writeln('Segmentation failure: ${error.cause}');
        }
        throw error;
      });
      final image = img.decodePng(output)!;
      final original = img.decodePng(source)!;
      expect((image.width, image.height), (original.width, original.height));
      expect(image.any((p) => p.a < 10), isTrue);
      expect(image.any((p) => p.a > 245), isTrue);
      final qa = Directory('../qa')..createSync(recursive: true);
      await File('${qa.path}/portrait-cutout.png').writeAsBytes(output);
      for (final effect in ['blur', 'background', 'hair']) {
        final edited = await segmentEdit(
          source,
          effect: effect,
          color: 0xffcc553d,
        );
        final decoded = img.decodePng(edited)!;
        expect(
          (decoded.width, decoded.height),
          (original.width, original.height),
        );
        expect(decoded.getBytes(), isNot(orderedEquals(original.getBytes())));
        await File('${qa.path}/portrait-$effect.png').writeAsBytes(edited);
      }
      await disposeSegmenter();
    },
    timeout: const Timeout(Duration(minutes: 3)),
  );
}
