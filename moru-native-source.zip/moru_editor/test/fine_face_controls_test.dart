import 'dart:typed_data';
import 'dart:math' as math;
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as im;
import 'package:moru_editor/editor_engine.dart';

typedef ControlSetting = EditSettings Function(double value);

final signedControls = <String, ControlSetting>{
  'noseAlarWidth': (v) => EditSettings(noseAlarWidth: v),
  'noseBridgeWidth': (v) => EditSettings(noseBridgeWidth: v),
  'noseDorsumWidth': (v) => EditSettings(noseDorsumWidth: v),
  'noseTipSize': (v) => EditSettings(noseTipSize: v),
  'noseTipLift': (v) => EditSettings(noseTipLift: v),
  'noseLength': (v) => EditSettings(noseLength: v),
  'nosePosition': (v) => EditSettings(nosePosition: v),
  'eyeWidth': (v) => EditSettings(eyeWidth: v),
  'eyeHeight': (v) => EditSettings(eyeHeight: v),
  'eyeSpacing': (v) => EditSettings(eyeSpacing: v),
  'eyeTilt': (v) => EditSettings(eyeTilt: v),
  'eyePosition': (v) => EditSettings(eyePosition: v),
  'lipWidth': (v) => EditSettings(lipWidth: v),
  'upperLipFullness': (v) => EditSettings(upperLipFullness: v),
  'lowerLipFullness': (v) => EditSettings(lowerLipFullness: v),
  'mouthPosition': (v) => EditSettings(mouthPosition: v),
  'mouthSmile': (v) => EditSettings(mouthSmile: v),
  'cheekboneWidth': (v) => EditSettings(cheekboneWidth: v),
  'jawWidth': (v) => EditSettings(jawWidth: v),
  'chinWidth': (v) => EditSettings(chinWidth: v),
  'faceLength': (v) => EditSettings(faceLength: v),
  'browHeight': (v) => EditSettings(browHeight: v),
  'browSpacing': (v) => EditSettings(browSpacing: v),
  'browTilt': (v) => EditSettings(browTilt: v),
  'underEyeVolume': (v) => EditSettings(underEyeVolume: v),
  'cheekVolume': (v) => EditSettings(cheekVolume: v),
  'headSize': (v) => EditSettings(headSize: v),
};

FaceGeometry fineFace() {
  final p = List<FacePoint>.filled(478, const FacePoint(.5, .5));
  const oval = [
    10,
    338,
    297,
    332,
    284,
    251,
    389,
    356,
    454,
    323,
    361,
    288,
    397,
    365,
    379,
    378,
    400,
    377,
    152,
    148,
    176,
    149,
    150,
    136,
    172,
    58,
    132,
    93,
    234,
    127,
    162,
    21,
    54,
    103,
    67,
    109,
  ];
  for (var i = 0; i < oval.length; i++) {
    final angle = -math.pi / 2 + i * 2 * math.pi / oval.length;
    p[oval[i]] = FacePoint(
      .5 + .32 * math.cos(angle),
      .5 + .40 * math.sin(angle),
    );
  }
  const outer = [
    61,
    185,
    40,
    39,
    37,
    0,
    267,
    269,
    270,
    409,
    291,
    375,
    321,
    405,
    314,
    17,
    84,
    181,
    91,
    146,
  ];
  const inner = [
    78,
    191,
    80,
    81,
    82,
    13,
    312,
    311,
    310,
    415,
    308,
    324,
    318,
    402,
    317,
    14,
    87,
    178,
    88,
    95,
  ];
  for (var i = 0; i < 20; i++) {
    final angle = math.pi + i * 2 * math.pi / 20, sine = math.sin(angle);
    p[outer[i]] = FacePoint(
      .5 + .135 * math.cos(angle),
      .70 + (sine < 0 ? .025 : .040) * sine,
    );
    p[inner[i]] = FacePoint(
      .5 + .110 * math.cos(angle),
      .70 + (sine < 0 ? .005 : .015) * sine,
    );
  }
  const leftEye = [
    33,
    7,
    163,
    144,
    145,
    153,
    154,
    155,
    133,
    173,
    157,
    158,
    159,
    160,
    161,
    246,
  ];
  const rightEye = [
    263,
    249,
    390,
    373,
    374,
    380,
    381,
    382,
    362,
    398,
    384,
    385,
    386,
    387,
    388,
    466,
  ];
  for (var i = 0; i < 16; i++) {
    final angle = math.pi - i * 2 * math.pi / 16;
    p[leftEye[i]] = FacePoint(
      .355 + .075 * math.cos(angle),
      .37 + .025 * math.sin(angle),
    );
    p[rightEye[i]] = FacePoint(
      .645 - .075 * math.cos(angle),
      .37 + .025 * math.sin(angle),
    );
  }
  const locations = <int, (double, double)>{
    10: (.5, .10),
    152: (.5, .90),
    168: (.5, .36),
    6: (.5, .405),
    197: (.5, .445),
    195: (.5, .48),
    5: (.5, .505),
    4: (.5, .53),
    1: (.5, .555),
    19: (.5, .575),
    94: (.5, .59),
    2: (.5, .61),
    98: (.425, .595),
    327: (.575, .595),
    33: (.28, .37),
    133: (.43, .37),
    159: (.355, .345),
    145: (.355, .395),
    263: (.72, .37),
    362: (.57, .37),
    386: (.645, .345),
    374: (.645, .395),
    61: (.365, .70),
    291: (.635, .70),
    0: (.5, .675),
    13: (.5, .695),
    17: (.5, .740),
    14: (.5, .715),
    234: (.18, .42),
    454: (.82, .42),
    172: (.25, .72),
    397: (.75, .72),
    148: (.44, .87),
    377: (.56, .87),
    127: (.20, .31),
    356: (.80, .31),
    50: (.32, .51),
    280: (.68, .51),
    70: (.26, .29),
    63: (.30, .265),
    105: (.35, .26),
    66: (.40, .265),
    107: (.44, .28),
    46: (.26, .308),
    53: (.30, .283),
    52: (.35, .278),
    65: (.40, .283),
    55: (.44, .298),
    300: (.74, .29),
    293: (.70, .265),
    334: (.65, .26),
    296: (.60, .265),
    336: (.56, .28),
    276: (.74, .308),
    283: (.70, .283),
    282: (.65, .278),
    295: (.60, .283),
    285: (.56, .298),
  };
  for (final entry in locations.entries) {
    p[entry.key] = FacePoint(entry.value.$1, entry.value.$2);
  }
  return FaceGeometry(points: p);
}

Uint8List coordinateImage({int width = 220, int height = 240}) {
  final image = im.Image(width: width, height: height, numChannels: 4);
  for (var y = 0; y < height; y++) {
    for (var x = 0; x < width; x++) {
      image.setPixelRgba(x, y, x, y, (x * 7 + y * 11) % 256, 255);
    }
  }
  return Uint8List.fromList(im.encodePng(image));
}

int changedPixels(im.Image a, im.Image b) {
  var changed = 0;
  for (var y = 0; y < a.height; y++) {
    for (var x = 0; x < a.width; x++) {
      final p = a.getPixel(x, y), q = b.getPixel(x, y);
      if (p.r != q.r || p.g != q.g || p.b != q.b || p.a != q.a) changed++;
    }
  }
  return changed;
}

void expectFarBackgroundUnchanged(im.Image original, im.Image edited) {
  for (var y = 0; y < original.height; y++) {
    for (final x in [0, 1, original.width - 2, original.width - 1]) {
      final a = original.getPixel(x, y), b = edited.getPixel(x, y);
      expect([b.r, b.g, b.b, b.a], [a.r, a.g, a.b, a.a]);
    }
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final bytes = coordinateImage(), face = fineFace();
  final original = im.decodePng(bytes)!;

  for (final entry in signedControls.entries) {
    test(
      '${entry.key}: positive and negative are real, distinct and local',
      () async {
        expect(entry.value(0).isNeutral, isTrue);
        expect(entry.value(.8).hasFaceWarp, isTrue);
        final positive = im.decodePng(
          await renderImage(
            bytes,
            entry.value(.8),
            faces: [face],
            maxDimension: 0,
          ),
        )!;
        final negative = im.decodePng(
          await renderImage(
            bytes,
            entry.value(-.8),
            faces: [face],
            maxDimension: 0,
          ),
        )!;
        expect(changedPixels(original, positive), greaterThan(3));
        expect(changedPixels(original, negative), greaterThan(3));
        expect(changedPixels(positive, negative), greaterThan(3));
        expectFarBackgroundUnchanged(original, positive);
        expectFarBackgroundUnchanged(original, negative);
      },
    );
  }

  test(
    'alar, bridge and dorsum widths produce different spatial effects',
    () async {
      final results = <im.Image>[];
      for (final setting in [
        const EditSettings(noseAlarWidth: 1),
        const EditSettings(noseBridgeWidth: 1),
        const EditSettings(noseDorsumWidth: 1),
      ]) {
        results.add(
          im.decodePng(
            await renderImage(bytes, setting, faces: [face], maxDimension: 0),
          )!,
        );
      }
      for (var i = 0; i < results.length; i++) {
        for (var j = i + 1; j < results.length; j++) {
          expect(changedPixels(results[i], results[j]), greaterThan(20));
        }
      }
      // These nose controls must not disturb the eyes or lips.
      for (final result in results) {
        for (final index in [33, 133, 263, 362, 61, 291]) {
          final x = (face.points[index].x * original.width).round();
          final y = (face.points[index].y * original.height).round();
          final a = original.getPixel(x, y), b = result.getPixel(x, y);
          expect([b.r, b.g, b.b], [a.r, a.g, a.b]);
        }
      }
    },
  );

  test(
    'alar width sign expands and contracts separately marked nose wings',
    () async {
      final source = im.Image(width: 220, height: 240, numChannels: 4);
      for (final p in source) {
        p.setRgba(110, 110, 110, 255);
      }
      for (final id in [98, 327]) {
        final c = face.points[id];
        for (var y = 0; y < source.height; y++) {
          for (var x = 0; x < source.width; x++) {
            final dx = x - c.x * source.width, dy = y - c.y * source.height;
            if (dx * dx + dy * dy < 12) {
              source.setPixelRgba(x, y, 250, 20, 20, 255);
            }
          }
        }
      }
      double separation(im.Image image) {
        var left = 0.0, right = 0.0, nl = 0, nr = 0;
        for (final p in image) {
          if (p.r > 180 && p.g < 70) {
            if (p.x < image.width / 2) {
              left += p.x;
              nl++;
            } else {
              right += p.x;
              nr++;
            }
          }
        }
        expect(nl, greaterThan(0));
        expect(nr, greaterThan(0));
        return right / nr - left / nl;
      }

      final sourceBytes = Uint8List.fromList(im.encodePng(source));
      final expanded = im.decodePng(
        await renderImage(
          sourceBytes,
          const EditSettings(noseAlarWidth: 1),
          faces: [face],
          maxDimension: 0,
        ),
      )!;
      final contracted = im.decodePng(
        await renderImage(
          sourceBytes,
          const EditSettings(noseAlarWidth: -1),
          faces: [face],
          maxDimension: 0,
        ),
      )!;
      expect(separation(expanded), greaterThan(separation(source) + 1));
      expect(separation(contracted), lessThan(separation(source) - 1));
    },
  );

  test('all lifting controls move pixels and stay local', () async {
    for (final setting in [
      const EditSettings(cheekLift: .9),
      const EditSettings(templeLift: .9),
      const EditSettings(nasolabialLift: .9),
    ]) {
      final output = im.decodePng(
        await renderImage(bytes, setting, faces: [face], maxDimension: 0),
      )!;
      expect(changedPixels(original, output), greaterThan(5));
      expectFarBackgroundUnchanged(original, output);
    }
  });

  test(
    'copyWith retains fine controls, pixel controls and chosen palettes',
    () {
      const source = EditSettings(
        noseAlarWidth: .2,
        noseBridgeWidth: -.3,
        noseDorsumWidth: .4,
        noseTipSize: .1,
        noseTipLift: .2,
        noseLength: -.2,
        nosePosition: .3,
        eyeWidth: .2,
        eyeHeight: -.2,
        eyeSpacing: .3,
        eyeTilt: .4,
        eyePosition: .1,
        lipWidth: -.2,
        upperLipFullness: .2,
        lowerLipFullness: .3,
        mouthPosition: .1,
        mouthSmile: .2,
        cheekboneWidth: .2,
        jawWidth: -.2,
        chinWidth: .2,
        faceLength: .3,
        browHeight: .1,
        browSpacing: .2,
        browTilt: -.2,
        headSize: .4,
        cheekLift: .2,
        templeLift: .3,
        nasolabialLift: .4,
        underEyeVolume: -.2,
        cheekVolume: .3,
        blemishRemoval: .1,
        wrinkleRemove: .2,
        nasolabialFoldRemove: .3,
        skinTexture: .4,
        darkCircleReduce: .5,
        rednessReduce: .6,
        eyeshadow: .7,
        eyeliner: .8,
        browFill: .9,
        lipGloss: 1,
        lipstickColor: 0xffcc3377,
        blushColor: 0xffda6677,
        eyeshadowColor: 0xff775533,
      );
      final copy = source.copyWith(exposure: .2);
      expect(copy.noseAlarWidth, source.noseAlarWidth);
      expect(copy.noseBridgeWidth, source.noseBridgeWidth);
      expect(copy.noseDorsumWidth, source.noseDorsumWidth);
      expect(copy.noseTipSize, source.noseTipSize);
      expect(copy.noseTipLift, source.noseTipLift);
      expect(copy.noseLength, source.noseLength);
      expect(copy.nosePosition, source.nosePosition);
      expect(copy.eyeWidth, source.eyeWidth);
      expect(copy.eyeHeight, source.eyeHeight);
      expect(copy.eyeSpacing, source.eyeSpacing);
      expect(copy.eyeTilt, source.eyeTilt);
      expect(copy.eyePosition, source.eyePosition);
      expect(copy.lipWidth, source.lipWidth);
      expect(copy.upperLipFullness, source.upperLipFullness);
      expect(copy.lowerLipFullness, source.lowerLipFullness);
      expect(copy.mouthPosition, source.mouthPosition);
      expect(copy.mouthSmile, source.mouthSmile);
      expect(copy.cheekboneWidth, source.cheekboneWidth);
      expect(copy.jawWidth, source.jawWidth);
      expect(copy.chinWidth, source.chinWidth);
      expect(copy.faceLength, source.faceLength);
      expect(copy.browHeight, source.browHeight);
      expect(copy.browSpacing, source.browSpacing);
      expect(copy.browTilt, source.browTilt);
      expect(copy.headSize, source.headSize);
      expect(copy.cheekLift, source.cheekLift);
      expect(copy.templeLift, source.templeLift);
      expect(copy.nasolabialLift, source.nasolabialLift);
      expect(copy.underEyeVolume, source.underEyeVolume);
      expect(copy.cheekVolume, source.cheekVolume);
      expect(copy.blemishRemoval, source.blemishRemoval);
      expect(copy.wrinkleRemove, source.wrinkleRemove);
      expect(copy.nasolabialFoldRemove, source.nasolabialFoldRemove);
      expect(copy.skinTexture, source.skinTexture);
      expect(copy.darkCircleReduce, source.darkCircleReduce);
      expect(copy.rednessReduce, source.rednessReduce);
      expect(copy.eyeshadow, source.eyeshadow);
      expect(copy.eyeliner, source.eyeliner);
      expect(copy.browFill, source.browFill);
      expect(copy.lipGloss, source.lipGloss);
      expect(copy.lipstickColor, source.lipstickColor);
      expect(copy.blushColor, source.blushColor);
      expect(copy.eyeshadowColor, source.eyeshadowColor);
      expect(copy.hasFaceWarp, isTrue);
      expect(copy.hasRetouchPixels, isTrue);
      expect(copy.isNeutral, isFalse);
      expect(
        const EditSettings(
          lipstickColor: 0xff112233,
          blushColor: 0xff445566,
          eyeshadowColor: 0xff667788,
        ).isNeutral,
        isTrue,
      );
    },
  );

  test(
    'fine facial geometry and retouch are no-ops when no actual face exists',
    () async {
      const setting = EditSettings(
        noseAlarWidth: .8,
        noseBridgeWidth: .5,
        eyeWidth: .5,
        mouthSmile: .5,
        jawWidth: .5,
        cheekVolume: .5,
        browHeight: .5,
        cheekLift: .5,
        wrinkleRemove: .5,
        nasolabialFoldRemove: .5,
        eyeliner: .5,
      );
      final result = im.decodePng(
        await renderImage(bytes, setting, maxDimension: 0),
      )!;
      expect(changedPixels(original, result), 0);
    },
  );

  test('fine geometry follows a rolled head instead of screen axes', () async {
    const setting = EditSettings(
      noseAlarWidth: .5,
      noseBridgeWidth: -.5,
      noseTipLift: .4,
      eyeWidth: .4,
      eyeHeight: -.4,
      eyeTilt: .5,
      eyePosition: .3,
      mouthSmile: .4,
      lipWidth: .4,
      jawWidth: -.3,
      browHeight: .4,
      browTilt: .3,
      cheekVolume: .3,
    );
    final normal = im.decodePng(
      await renderImage(bytes, setting, faces: [face], maxDimension: 0),
    )!;
    final expected = im.copyRotate(normal, angle: 90);
    final rotated = im.copyRotate(original, angle: 90);
    final rotatedFace = FaceGeometry(
      points: face.points
          .map(
            (p) => FacePoint(
              (original.height - 1 - p.y * original.height) / rotated.width,
              p.x * original.width / rotated.height,
            ),
          )
          .toList(),
    );
    final actual = im.decodePng(
      await renderImage(
        Uint8List.fromList(im.encodePng(rotated)),
        setting,
        faces: [rotatedFace],
        maxDimension: 0,
      ),
    )!;
    var error = 0.0, maxError = 0.0;
    for (var y = 0; y < actual.height; y++) {
      for (var x = 0; x < actual.width; x++) {
        final a = actual.getPixel(x, y), b = expected.getPixel(x, y);
        for (final d in [
          (a.r - b.r).abs(),
          (a.g - b.g).abs(),
          (a.b - b.b).abs(),
        ]) {
          error += d;
          if (d > maxError) maxError = d.toDouble();
        }
      }
    }
    expect(error / (actual.width * actual.height * 3), lessThan(.2));
    expect(maxError, lessThanOrEqualTo(2));
  });

  test(
    'wrinkle brush repairs a dark crease only inside the feathered stroke',
    () async {
      final source = im.Image(width: 160, height: 160, numChannels: 4);
      for (final p in source) {
        final line = (p.x - 80).abs() <= 1 && p.y >= 45 && p.y <= 115;
        final micro = (p.x + p.y) % 3 - 1;
        p.setRgba(
          line ? 95 : 185 + micro,
          line ? 72 : 145 + micro,
          line ? 62 : 125 + micro,
          210,
        );
      }
      final input = Uint8List.fromList(im.encodePng(source));
      final result = im.decodePng(
        await applyBrush(
          input,
          'wrinkle',
          [const FacePoint(.5, .25), const FacePoint(.5, .75)],
          radius: .07,
          strength: 1,
        ),
      )!;
      expect(
        result.getPixel(80, 80).r,
        greaterThan(source.getPixel(80, 80).r + 12),
      );
      for (final xy in [(10, 80), (40, 80), (130, 80), (80, 5), (80, 150)]) {
        final a = source.getPixel(xy.$1, xy.$2),
            b = result.getPixel(xy.$1, xy.$2);
        expect([b.r, b.g, b.b, b.a], [a.r, a.g, a.b, a.a]);
      }
      for (final p in result) {
        expect(p.a, 210);
      }
      final zero = im.decodePng(
        await applyBrush(
          input,
          'wrinkle',
          [const FacePoint(.5, .5)],
          radius: .1,
          strength: 0,
        ),
      )!;
      expect(changedPixels(source, zero), 0);
    },
  );
  test(
    'head size affects the estimated upper head and fades before the neck',
    () async {
      final head = im.decodePng(
        await renderImage(
          bytes,
          const EditSettings(headSize: .8),
          faces: [face],
          maxDimension: 0,
        ),
      )!;
      final nose = im.decodePng(
        await renderImage(
          bytes,
          const EditSettings(noseAlarWidth: .8),
          faces: [face],
          maxDimension: 0,
        ),
      )!;
      var headChanges = 0, noseChanges = 0;
      for (var y = 15; y < 55; y++) {
        for (var x = 70; x < 150; x++) {
          final p = original.getPixel(x, y),
              q = head.getPixel(x, y),
              r = nose.getPixel(x, y);
          if (p.r != q.r || p.g != q.g || p.b != q.b) headChanges++;
          if (p.r != r.r || p.g != r.g || p.b != r.b) noseChanges++;
        }
      }
      expect(headChanges, greaterThan(100));
      expect(noseChanges, 0);
      for (var x = 0; x < original.width; x++) {
        final p = original.getPixel(x, 239), q = head.getPixel(x, 239);
        expect([q.r, q.g, q.b, q.a], [p.r, p.g, p.b, p.a]);
      }
    },
  );
  test(
    'selected lip and blush palettes change actual composited pixels',
    () async {
      final skin = im.Image(width: 220, height: 240, numChannels: 4);
      for (final p in skin) {
        p.setRgba(180, 130, 110, 255);
      }
      final input = Uint8List.fromList(im.encodePng(skin));
      final warm = im.decodePng(
        await renderImage(
          input,
          const EditSettings(lipstick: 1, blush: 1),
          faces: [face],
          maxDimension: 0,
        ),
      )!;
      final cool = im.decodePng(
        await renderImage(
          input,
          const EditSettings(
            lipstick: 1,
            blush: 1,
            lipstickColor: 0xff3868d0,
            blushColor: 0xff9848b8,
          ),
          faces: [face],
          maxDimension: 0,
        ),
      )!;
      expect(changedPixels(warm, cool), greaterThan(20));
      expect(cool.getPixel(110, 163).b, greaterThan(warm.getPixel(110, 163).b));
      expectFarBackgroundUnchanged(skin, cool);
    },
  );
  test(
    'upper and lower lip fullness leave the opposite lip contour fixed',
    () async {
      final upper = im.decodePng(
        await renderImage(
          bytes,
          const EditSettings(upperLipFullness: 1),
          faces: [face],
          maxDimension: 0,
        ),
      )!;
      final lower = im.decodePng(
        await renderImage(
          bytes,
          const EditSettings(lowerLipFullness: 1),
          faces: [face],
          maxDimension: 0,
        ),
      )!;
      for (final id in [14, 17]) {
        final p = face.points[id],
            x = (p.x * original.width).round(),
            y = (p.y * original.height).round();
        final a = original.getPixel(x, y), b = upper.getPixel(x, y);
        expect([b.r, b.g, b.b, b.a], [a.r, a.g, a.b, a.a]);
      }
      for (final id in [0, 13]) {
        final p = face.points[id],
            x = (p.x * original.width).round(),
            y = (p.y * original.height).round();
        final a = original.getPixel(x, y), b = lower.getPixel(x, y);
        expect([b.r, b.g, b.b, b.a], [a.r, a.g, a.b, a.a]);
      }
      expect(changedPixels(original, upper), greaterThan(3));
      expect(changedPixels(original, lower), greaterThan(3));
    },
  );
}
