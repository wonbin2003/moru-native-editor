import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/editor_engine.dart';
import 'package:moru_editor/face_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
    'optional locally credited older portrait retouch visual QA',
    () async {
      // External QA photographs remain outside the app/source release. CI without
      // them still runs the bundled real-model portrait and algorithm regressions.
      final source = File(
        '../qa/reference-portraits/charles-bolden-administrator.jpg',
      );
      if (!source.existsSync()) return;
      final decoded = img.bakeOrientation(
        img.decodeJpg(await source.readAsBytes())!,
      );
      final input = img.copyResize(
        decoded,
        width: (decoded.width * 1200 / decoded.height).round(),
        height: 1200,
        interpolation: img.Interpolation.cubic,
      );
      final bytes = Uint8List.fromList(img.encodePng(input));
      final faces = await detectFaces(bytes);
      expect(faces, hasLength(1));
      final outDir = Directory('../qa/retouch-real-portrait')
        ..createSync(recursive: true);
      final cases = <String, EditSettings>{
        'original': const EditSettings(),
        'fold-65': const EditSettings(nasolabialFoldRemove: .65),
        'fold-100': const EditSettings(nasolabialFoldRemove: 1),
        'skin-45': const EditSettings(
          skinSmooth: .4,
          blemishRemoval: .25,
          nasolabialFoldRemove: .45,
          wrinkleRemove: .4,
          darkCircleReduce: .2,
        ),
        'head-smaller': const EditSettings(headSize: -.5),
        'head-larger': const EditSettings(headSize: .5),
      };
      final p = faces.first.points;
      final left = ((math.min(p[234].x, p[454].x) - .04) * input.width)
          .floor()
          .clamp(0, input.width - 1);
      final right = ((math.max(p[234].x, p[454].x) + .04) * input.width)
          .ceil()
          .clamp(left + 1, input.width);
      final top = ((p[10].y - .07) * input.height).floor().clamp(
        0,
        input.height - 1,
      );
      final bottom = ((p[152].y + .04) * input.height).ceil().clamp(
        top + 1,
        input.height,
      );
      for (final entry in cases.entries) {
        final output = await renderImage(
          bytes,
          entry.value,
          faces: faces,
          maxDimension: 0,
        );
        final result = img.decodePng(output)!;
        expect((result.width, result.height), (input.width, input.height));
        await File('${outDir.path}/${entry.key}.png').writeAsBytes(output);
        await File('${outDir.path}/${entry.key}-face.png').writeAsBytes(
          img.encodePng(
            img.copyCrop(
              result,
              x: left,
              y: top,
              width: right - left,
              height: bottom - top,
            ),
          ),
        );
        if (entry.key.startsWith('fold')) {
          // The automatic fold pass must preserve eye and mouth landmarks.
          for (final i in [33, 133, 263, 362, 13, 14]) {
            final x = (p[i].x * input.width).round().clamp(0, input.width - 1);
            final y = (p[i].y * input.height).round().clamp(
              0,
              input.height - 1,
            );
            final before = input.getPixel(x, y), after = result.getPixel(x, y);
            expect(
              [after.r, after.g, after.b, after.a],
              [before.r, before.g, before.b, before.a],
              reason: '${entry.key} landmark$i',
            );
          }
        }
      }
      await File(
        '${outDir.path}/landmarks.json',
      ).writeAsString('[${p.map((p) => '[${p.x},${p.y}]').join(',')}]');
    },
    timeout: const Timeout(Duration(minutes: 5)),
  );
}
