import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/editor_engine.dart';
import 'package:moru_editor/retouch_engine.dart';
import 'package:moru_editor/retouch_presets.dart';

void main() {
  test(
    'wrinkle target reduces a dark crease while preserving alpha and flat skin',
    () {
      final skin = img.Image(width: 96, height: 96, numChannels: 4);
      img.fill(skin, color: img.ColorRgba8(170, 125, 105, 137));
      for (var y = 25; y < 71; y++) {
        skin.setPixelRgba(47, y, 132, 87, 67, 137);
        skin.setPixelRgba(48, y, 132, 87, 67, 137);
      }
      final output = repairFineWrinkles(skin, radiusFraction: .025);
      final before = skin.getPixel(48, 45), after = output.getPixel(48, 45);
      expect(after.r, greaterThan(before.r + 10));
      expect(after.g, greaterThan(before.g + 10));
      expect(after.b, greaterThan(before.b + 10));
      expect(after.r, lessThanOrEqualTo(170));
      expect(output.getPixel(10, 10).r, 170);
      for (final p in output) {
        expect(p.a, 137);
      }
      expect(
        repairFineWrinkles(skin, strength: 0).getBytes(),
        orderedEquals(skin.getBytes()),
      );
    },
  );

  test(
    'touch wrinkle repair changes only the drawn region and keeps dimensions',
    () async {
      final skin = img.Image(width: 96, height: 96, numChannels: 4);
      img.fill(skin, color: img.ColorRgba8(170, 125, 105, 137));
      for (var y = 10; y < 86; y++) {
        skin.setPixelRgba(47, y, 132, 87, 67, 137);
        skin.setPixelRgba(48, y, 132, 87, 67, 137);
      }
      final result = img.decodePng(
        await applyBrush(
          Uint8List.fromList(img.encodePng(skin)),
          'wrinkle',
          const [FacePoint(.5, .4), FacePoint(.5, .6)],
          radius: .08,
          strength: .85,
        ),
      )!;
      expect((result.width, result.height), (96, 96));
      expect(
        result.getPixel(48, 48).r,
        greaterThan(skin.getPixel(48, 48).r + 5),
      );
      expect(result.getPixel(48, 15).r, skin.getPixel(48, 15).r);
      expect(result.getPixel(10, 48).r, skin.getPixel(10, 48).r);
      expect(result.getPixel(48, 48).a, 137);
    },
  );

  test(
    'automatic intensity is absolute and preserves manual geometry and colours',
    () {
      const initial = EditSettings(
        noseTipSize: -.2,
        headSize: -.12,
        exposure: .25,
        lipstickColor: 0xffa05070,
      );
      final strong = applyRetouchPreset(initial, 'clear', 1);
      expect(strong.nasolabialFoldRemove, greaterThan(0));
      expect(strong.wrinkleRemove, greaterThan(0));
      expect(strong.blemishRemoval, greaterThan(0));
      final lower = applyRetouchPreset(strong, 'clear', .4);
      final direct = applyRetouchPreset(initial, 'clear', .4);
      expect(lower.skinSmooth, direct.skinSmooth);
      expect(lower.nasolabialFoldRemove, direct.nasolabialFoldRemove);
      expect(lower.noseTipSize, -.2);
      expect(lower.headSize, -.12);
      expect(lower.exposure, .25);
      expect(lower.lipstickColor, initial.lipstickColor);
      final off = applyRetouchPreset(lower, 'clear', 0);
      expect(off.skinSmooth, 0);
      expect(off.nasolabialFoldRemove, 0);
      expect(off.noseTipSize, -.2);
    },
  );
}
