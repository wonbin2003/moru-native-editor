import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/main.dart';
import 'package:moru_editor/ui/composition.dart';

Uint8List solidPhoto(int width, int height, int r, int g, int b) {
  final photo = img.Image(width: width, height: height);
  img.fill(photo, color: img.ColorRgb8(r, g, b));
  return Uint8List.fromList(img.encodePng(photo));
}

void main() {
  testWidgets('mobile welcome screen has accessible entry actions without overflow', (tester) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(const MoruApp());
    await tester.pumpAndSettle();
    expect(find.text('사진 열기'), findsOneWidget);
    expect(find.text('사진 촬영'), findsOneWidget);
    expect(find.text('콜라주'), findsOneWidget);
    expect(find.text('샘플로 둘러보기'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('wide welcome retains local photo privacy notice', (tester) async {
    tester.view.physicalSize = const Size(1280, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(const MoruApp());
    await tester.pumpAndSettle();
    expect(find.text('사진 업로드 없음'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('text overlay preserves pixel dimensions and untouched corners', (tester) async {
    final source = solidPhoto(320, 400, 30, 50, 90);
    final output = await tester.runAsync(() => addTextToPhoto(source, const TextDecorationOptions(
      text: 'moru', color: Colors.white, size: .12, position: .5,
    )));
    expect(output, isNotNull);
    final photo = img.decodePng(output!)!;
    expect((photo.width, photo.height), (320, 400));
    final corner = photo.getPixel(2, 2);
    expect((corner.r, corner.g, corner.b), (30, 50, 90));
    var changed = false;
    for (var y = 150; y < 250; y++) {
      for (var x = 50; x < 270; x++) {
        if (photo.getPixel(x, y).r > 50) changed = true;
      }
    }
    expect(changed, isTrue, reason: 'Text must be rasterized, not only shown in a preview.');
  });

  testWidgets('two-photo collage uses distinct full cells and a clean border', (tester) async {
    final output = await tester.runAsync(() => makeCollage([
      solidPhoto(80, 120, 240, 20, 30),
      solidPhoto(100, 70, 20, 50, 230),
    ]));
    final collage = img.decodePng(output!)!;
    expect((collage.width, collage.height), (2400, 1600));
    final left = collage.getPixel(400, 800), right = collage.getPixel(2000, 800);
    expect((left.r, left.g, left.b), (240, 20, 30));
    expect((right.r, right.g, right.b), (20, 50, 230));
    final border = collage.getPixel(5, 5);
    expect((border.r, border.g, border.b), (244, 238, 232));
  });
}
