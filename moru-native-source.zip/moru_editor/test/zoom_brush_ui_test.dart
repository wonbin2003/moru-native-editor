import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:moru_editor/face_service.dart';
import 'package:moru_editor/main.dart';

void main() {
  testWidgets(
    'a real touch on a zoomed portrait paints the scene pixel and preserves zoom',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.runAsync(() async {
        final data = await rootBundle.load('assets/samples/astronaut.png');
        final source = data.buffer.asUint8List(
          data.offsetInBytes,
          data.lengthInBytes,
        );
        try {
          await tester.pumpWidget(MoruApp(initialBytes: source));
          final imported = Stopwatch()..start();
          while (imported.elapsed < const Duration(seconds: 45)) {
            await Future<void>.delayed(const Duration(milliseconds: 40));
            await tester.pump(const Duration(milliseconds: 16));
            expect(tester.takeException(), isNull);
            if (find.textContaining('512 × 512').evaluate().isNotEmpty &&
                tester
                    .widgetList<RawImage>(find.byType(RawImage))
                    .any((w) => w.image?.width == 512)) {
              break;
            }
          }
          expect(find.textContaining('512 × 512'), findsOneWidget);
          final brushSection = find.byKey(
            const ValueKey('retouch-section-브러쉬'),
          );
          await tester.ensureVisible(brushSection);
          await tester.tap(brushSection);
          await tester.pump(const Duration(milliseconds: 40));

          final viewer = tester.widget<InteractiveViewer>(
            find.byType(InteractiveViewer),
          );
          final transform = viewer.transformationController!;
          transform.value = Matrix4.diagonal3Values(2, 2, 1)
            ..setTranslationRaw(-80, -40, 0);
          await tester.pump(const Duration(milliseconds: 20));
          final paint = find.byKey(const ValueKey('brush-paint'));
          await tester.ensureVisible(paint);
          await tester.tap(paint);
          await tester.pump(const Duration(milliseconds: 20));
          expect(
            transform.value.getMaxScaleOnAxis(),
            2,
            reason: 'Selecting a brush must retain the inspection zoom.',
          );
          expect(transform.value.storage[12], -80);
          expect(transform.value.storage[13], -40);

          final canvas = find.byKey(const ValueKey('photo-touch-canvas'));
          Future<Uint8List> pixels() async {
            final photo = tester
                .widgetList<RawImage>(
                  find.descendant(of: canvas, matching: find.byType(RawImage)),
                )
                .firstWhere((image) => image.image?.width == 512)
                .image!;
            final data = await photo.toByteData(
              format: ui.ImageByteFormat.rawRgba,
            );
            return Uint8List.fromList(
              data!.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
            );
          }

          final before = await pixels();
          final viewport = tester.getRect(canvas);
          final tap = Offset(viewport.width * .45, viewport.height * .45);
          final fitted = applyBoxFit(
            BoxFit.contain,
            const Size(512, 512),
            viewport.size,
          );
          final imageRect = Alignment.center.inscribe(
            fitted.destination,
            Offset.zero & viewport.size,
          );
          // Explicit inverse of scale=2, translation=(-80,-40), independent of
          // production's TransformationController.toScene implementation.
          final scene = Offset((tap.dx + 80) / 2, (tap.dy + 40) / 2);
          expect(imageRect.contains(scene), isTrue);
          final expected = Offset(
            (scene.dx - imageRect.left) / imageRect.width * 512,
            (scene.dy - imageRect.top) / imageRect.height * 512,
          );
          await tester.tapAt(viewport.topLeft + tap);
          await tester.pump(const Duration(milliseconds: 20));

          Uint8List? after;
          final repaired = Stopwatch()..start();
          while (repaired.elapsed < const Duration(seconds: 30)) {
            await Future<void>.delayed(const Duration(milliseconds: 60));
            await tester.pump(const Duration(milliseconds: 16));
            expect(tester.takeException(), isNull);
            if (find.text('부분 보정 중').evaluate().isNotEmpty) continue;
            final candidate = await pixels();
            var changed = false;
            for (var i = 0; i < candidate.length; i += 4) {
              if (candidate[i] != before[i] ||
                  candidate[i + 1] != before[i + 1] ||
                  candidate[i + 2] != before[i + 2]) {
                changed = true;
                break;
              }
            }
            if (changed) {
              after = candidate;
              break;
            }
          }
          expect(
            after,
            isNotNull,
            reason: 'An actual pointer tap must rasterize the selected brush.',
          );
          final painted = after!;
          var weightedX = 0.0, weightedY = 0.0, total = 0.0;
          var changedCount = 0;
          for (var y = 0; y < 512; y++) {
            for (var x = 0; x < 512; x++) {
              final i = (y * 512 + x) * 4;
              final weight =
                  (painted[i] - before[i]).abs() +
                  (painted[i + 1] - before[i + 1]).abs() +
                  (painted[i + 2] - before[i + 2]).abs();
              if (weight == 0) continue;
              weightedX += x * weight;
              weightedY += y * weight;
              total += weight;
              changedCount++;
            }
          }
          expect(changedCount, greaterThan(20));
          final actual = Offset(weightedX / total, weightedY / total);
          expect(
            math.sqrt(
              math.pow(actual.dx - expected.dx, 2) +
                  math.pow(actual.dy - expected.dy, 2),
            ),
            lessThan(8),
            reason:
                'Brush pixels must be centered at the transformed scene location, not the viewport location.',
          );
          expect(
            transform.value.getMaxScaleOnAxis(),
            2,
            reason: 'Completing a stroke must not jump back to fit-to-screen.',
          );
          expect(transform.value.storage[12], -80);
          expect(transform.value.storage[13], -40);
          expect(find.byKey(const ValueKey('canvas-zoom-in')), findsOneWidget);
          expect(find.byKey(const ValueKey('canvas-zoom-out')), findsOneWidget);
          await tester.tap(find.byKey(const ValueKey('canvas-fit')));
          await tester.pump(const Duration(milliseconds: 20));
          expect(transform.value.getMaxScaleOnAxis(), 1);
          expect(tester.takeException(), isNull);
        } finally {
          await tester.pumpWidget(const SizedBox.shrink());
          await disposeFaceDetector().timeout(const Duration(seconds: 5));
          await tester.pump();
        }
      });
    },
    timeout: const Timeout(Duration(seconds: 100)),
  );
}
