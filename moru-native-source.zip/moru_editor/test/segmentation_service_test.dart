import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:moru_editor/segmentation_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('cutout preserves size and source alpha with feathered boundaries', () {
    final result = img.decodePng(
      composeSegmentationEffect(
        _source(),
        confidence: Float32List.fromList([0, 1]),
        maskWidth: 2,
        maskHeight: 1,
        effect: 'cutout',
      ),
    )!;
    expect((result.width, result.height), (5, 3));
    expect(result.getPixel(0, 1).a, 200);
    expect(result.getPixel(2, 1).a, 100);
    expect(result.getPixel(4, 1).a, 0);
    expect(result.getPixel(0, 1).r, 100);
  });

  test(
    'solid replacement preserves foreground and makes background opaque',
    () {
      final result = img.decodePng(
        composeSegmentationEffect(
          _source(alpha: 255),
          confidence: Float32List.fromList([0, 1]),
          maskWidth: 2,
          maskHeight: 1,
          effect: 'background',
          color: 0xff112233,
        ),
      )!;
      expect(result.getPixel(0, 1).r, 100);
      final background = result.getPixel(4, 1);
      expect(
        [background.r, background.g, background.b, background.a],
        [17, 34, 51, 255],
      );
    },
  );

  test('hair tint changes the selected region and preserves other pixels', () {
    final result = img.decodePng(
      composeSegmentationEffect(
        _source(),
        confidence: Float32List.fromList([0, 1]),
        maskWidth: 2,
        maskHeight: 1,
        effect: 'hair',
        color: 0xffed3020,
        strength: 1,
      ),
    )!;
    final unchanged = result.getPixel(0, 1);
    expect(
      [unchanged.r, unchanged.g, unchanged.b, unchanged.a],
      [100, 150, 200, 200],
    );
    final selected = result.getPixel(4, 1);
    expect(selected.r, greaterThan(selected.g));
    expect(selected.a, 200);
  });

  test(
    'background blur does not spread foreground color into the background',
    () {
      final source = img.Image(width: 9, height: 3, numChannels: 4);
      final mask = Float32List(9 * 3);
      for (final pixel in source) {
        final background = pixel.x >= 4;
        pixel.setRgba(background ? 0 : 255, 0, background ? 255 : 0, 255);
        mask[pixel.y * 9 + pixel.x] = background ? 1 : 0;
      }
      final result = img.decodePng(
        composeSegmentationEffect(
          img.encodePng(source),
          confidence: mask,
          maskWidth: 9,
          maskHeight: 3,
          effect: 'blur',
        ),
      )!;
      final foreground = result.getPixel(2, 1),
          background = result.getPixel(4, 1);
      expect([foreground.r, foreground.g, foreground.b], [255, 0, 0]);
      expect(background.r, lessThan(2));
      expect(background.b, greaterThan(250));
    },
  );
}

Uint8List _source({int alpha = 200}) {
  final image = img.Image(width: 5, height: 3, numChannels: 4);
  for (final pixel in image) {
    pixel.setRgba(100, 150, 200, alpha);
  }
  return img.encodePng(image);
}
