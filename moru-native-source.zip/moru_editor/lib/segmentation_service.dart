import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:mediapipe_vision/mediapipe_vision.dart' as mp;

import 'face_service.dart' show decodePhotoForProcessing;

enum SegmentationFailure {
  modelUnavailable,
  inferenceFailed,
  invalidResult,
  noSubject,
}

class SegmentationException implements Exception {
  const SegmentationException(this.code, this.message, {this.cause});
  final SegmentationFailure code;
  final String message;
  final Object? cause;

  @override
  String toString() => message;
}

Future<mp.ImageSegmenter>? _segmenter;

Future<mp.ImageSegmenter> _getSegmenter() => _segmenter ??= _createSegmenter();

Future<mp.ImageSegmenter> _createSegmenter() async {
  try {
    final asset = await rootBundle.load(
      'assets/models/selfie_multiclass_256x256.tflite',
    );
    if (kIsWeb) mp.MediaPipeWebRuntime.baseUrl = 'mediapipe/';
    return await mp.ImageSegmenter.create(
      mp.ImageSegmenterOptions(
        modelBytes: asset.buffer.asUint8List(
          asset.offsetInBytes,
          asset.lengthInBytes,
        ),
        runningMode: mp.RunningMode.image,
        delegate: mp.Delegate.cpu,
        outputCategoryMask: false,
        outputConfidenceMasks: true,
      ),
    );
  } catch (_) {
    _segmenter = null;
    rethrow;
  }
}

class _SegmentInput {
  const _SegmentInput(this.rgba, this.width, this.height);
  final Uint8List rgba;
  final int width;
  final int height;
}

_SegmentInput _prepareSegmentInput(Uint8List bytes) {
  var image = decodePhotoForProcessing(bytes);
  final longest = math.max(image.width, image.height);
  if (longest > 1200) {
    final ratio = 1200 / longest;
    image = img.copyResize(
      image,
      width: math.max(1, (image.width * ratio).round()),
      height: math.max(1, (image.height * ratio).round()),
      interpolation: img.Interpolation.linear,
    );
  }
  return _SegmentInput(
    image.getBytes(order: img.ChannelOrder.rgba),
    image.width,
    image.height,
  );
}

/// Applies real model segmentation to the full-resolution, upright source.
///
/// [effect] is cutout, blur, background, or hair. [color] uses ARGB. Strength
/// affects blur/hair; cutout/background fully replace the selected background.
/// Selfie Multiclass categories: background, hair, body skin, face skin,
/// clothes, others. This model is a semantic segmenter, not perfect matting.
Future<Uint8List> segmentEdit(
  Uint8List bytes, {
  required String effect,
  int color = 0xffbba2cf,
  double strength = .6,
}) async {
  if (!const {'cutout', 'blur', 'background', 'hair'}.contains(effect)) {
    throw ArgumentError.value(effect, 'effect', 'Unknown segmentation effect');
  }
  if (!strength.isFinite) throw ArgumentError.value(strength, 'strength');
  final input = await compute(
    _prepareSegmentInput,
    bytes,
    debugLabel: 'prepare-segmentation',
  );
  try {
    final task = await _getSegmenter();
    final result = await task.segment(
      mp.VisionImage.fromPixels(
        pixels: input.rgba,
        width: input.width,
        height: input.height,
        format: mp.VisionPixelFormat.rgba,
      ),
    );
    final masks = result.confidenceMasks;
    if (masks == null || masks.length != 6) {
      throw const SegmentationException(
        SegmentationFailure.invalidResult,
        '인물 분리 모델의 결과를 읽을 수 없습니다.',
      );
    }
    final selected = masks[effect == 'hair' ? 1 : 0];
    if (selected.width <= 0 ||
        selected.height <= 0 ||
        selected.confidence.length != selected.width * selected.height ||
        selected.confidence.any((v) => !v.isFinite)) {
      throw const SegmentationException(
        SegmentationFailure.invalidResult,
        '인물 분리 마스크가 올바르지 않습니다.',
      );
    }
    final hasSubject = selected.confidence.any(
      (v) => effect == 'hair' ? v > .5 : v < .5,
    );
    if (!hasSubject) {
      throw SegmentationException(
        SegmentationFailure.noSubject,
        effect == 'hair' ? '머리카락 영역을 찾지 못했습니다.' : '인물 영역을 찾지 못했습니다.',
      );
    }
    return await compute(
      _renderSegmentWork,
      _SegmentWork(
        bytes: bytes,
        confidence: selected.confidence,
        maskWidth: selected.width,
        maskHeight: selected.height,
        effect: effect,
        color: color,
        strength: strength.clamp(0, 1),
      ),
      debugLabel: 'render-segmentation',
    );
  } on SegmentationException {
    rethrow;
  } on mp.RuntimeUnavailableException catch (error) {
    throw SegmentationException(
      SegmentationFailure.modelUnavailable,
      '인물 분리 실행 환경을 불러오지 못했습니다. 기본 사진 편집은 사용할 수 있습니다.',
      cause: error,
    );
  } on FlutterError catch (error) {
    throw SegmentationException(
      SegmentationFailure.modelUnavailable,
      '인물 분리 모델을 불러오지 못했습니다. 앱의 모델 파일을 확인해 주세요.',
      cause: error,
    );
  } catch (error) {
    throw SegmentationException(
      SegmentationFailure.inferenceFailed,
      '인물 분리에 실패했습니다. 다른 사진으로 다시 시도해 주세요.',
      cause: error,
    );
  }
}

class _SegmentWork {
  const _SegmentWork({
    required this.bytes,
    required this.confidence,
    required this.maskWidth,
    required this.maskHeight,
    required this.effect,
    required this.color,
    required this.strength,
  });
  final Uint8List bytes;
  final Float32List confidence;
  final int maskWidth, maskHeight;
  final String effect;
  final int color;
  final double strength;
}

Uint8List _renderSegmentWork(_SegmentWork work) => composeSegmentationEffect(
  work.bytes,
  confidence: work.confidence,
  maskWidth: work.maskWidth,
  maskHeight: work.maskHeight,
  effect: work.effect,
  color: work.color,
  strength: work.strength,
);

/// Pure compositor separated for deterministic edge/alpha tests. The caller
/// supplies actual model confidence; the production path never fabricates it.
@visibleForTesting
Uint8List composeSegmentationEffect(
  Uint8List bytes, {
  required Float32List confidence,
  required int maskWidth,
  required int maskHeight,
  required String effect,
  int color = 0xffbba2cf,
  double strength = .6,
}) {
  if (maskWidth <= 0 ||
      maskHeight <= 0 ||
      confidence.length != maskWidth * maskHeight) {
    throw ArgumentError('Invalid confidence dimensions');
  }
  final image = decodePhotoForProcessing(
    bytes,
  ).convert(format: img.Format.uint8, numChannels: 4);
  img.Image? blurred;
  if (effect == 'blur' && strength > 0) {
    final longest = math.max(image.width, image.height);
    final ratio = math.min(1.0, 640 / longest);
    final small = img.copyResize(
      image,
      width: math.max(1, (image.width * ratio).round()),
      height: math.max(1, (image.height * ratio).round()),
      interpolation: img.Interpolation.linear,
    );
    // Blur premultiplied background RGB and its confidence together, then
    // divide by the blurred confidence. Foreground colors never enter the
    // background blur, preventing the usual colored halo around a subject.
    final weighted = img.Image(
      width: small.width,
      height: small.height,
      numChannels: 4,
      format: img.Format.float32,
    );
    for (final pixel in weighted) {
      final source = small.getPixel(pixel.x, pixel.y);
      final weight =
          _featheredConfidence(
            confidence,
            maskWidth,
            maskHeight,
            (pixel.x + .5) / small.width,
            (pixel.y + .5) / small.height,
          ) *
          source.a /
          255;
      pixel.setRgba(
        source.r / 255 * weight,
        source.g / 255 * weight,
        source.b / 255 * weight,
        weight,
      );
    }
    img.gaussianBlur(
      weighted,
      radius: math.max(1, (3 + strength * 18).round()),
    );
    blurred = img.Image(
      width: small.width,
      height: small.height,
      numChannels: 3,
    );
    for (final pixel in blurred) {
      final weightedPixel = weighted.getPixel(pixel.x, pixel.y);
      if (weightedPixel.a > 0.000001) {
        pixel.setRgb(
          (weightedPixel.r / weightedPixel.a * 255).clamp(0, 255),
          (weightedPixel.g / weightedPixel.a * 255).clamp(0, 255),
          (weightedPixel.b / weightedPixel.a * 255).clamp(0, 255),
        );
      } else {
        final source = small.getPixel(pixel.x, pixel.y);
        pixel.setRgb(source.r, source.g, source.b);
      }
    }
  }
  final red = (color >> 16) & 255;
  final green = (color >> 8) & 255;
  final blue = color & 255;
  final colorAlpha = ((color >> 24) & 255) / 255;
  for (final pixel in image) {
    final mx = ((pixel.x + .5) * maskWidth / image.width - .5).clamp(
      0.0,
      maskWidth - 1.0,
    );
    final my = ((pixel.y + .5) * maskHeight / image.height - .5).clamp(
      0.0,
      maskHeight - 1.0,
    );
    final x0 = mx.floor(), y0 = my.floor();
    final x1 = math.min(x0 + 1, maskWidth - 1),
        y1 = math.min(y0 + 1, maskHeight - 1);
    final tx = mx - x0, ty = my - y0;
    final top =
        confidence[y0 * maskWidth + x0] * (1 - tx) +
        confidence[y0 * maskWidth + x1] * tx;
    final bottom =
        confidence[y1 * maskWidth + x0] * (1 - tx) +
        confidence[y1 * maskWidth + x1] * tx;
    // A soft confidence ramp removes low-confidence halos without a hard edge.
    final ramp = ((top * (1 - ty) + bottom * ty - .08) / .84).clamp(0.0, 1.0);
    final selected = ramp * ramp * (3 - 2 * ramp);
    if (effect == 'cutout') {
      pixel.a = (pixel.a * (1 - selected)).round();
    } else if (effect == 'background') {
      final foregroundAlpha = (1 - selected) * pixel.a / 255;
      final backgroundAlpha = (1 - foregroundAlpha) * colorAlpha;
      final alpha = foregroundAlpha + backgroundAlpha;
      pixel.setRgba(
        alpha == 0
            ? 0
            : ((pixel.r * foregroundAlpha + red * backgroundAlpha) / alpha)
                  .round(),
        alpha == 0
            ? 0
            : ((pixel.g * foregroundAlpha + green * backgroundAlpha) / alpha)
                  .round(),
        alpha == 0
            ? 0
            : ((pixel.b * foregroundAlpha + blue * backgroundAlpha) / alpha)
                  .round(),
        (alpha * 255).round(),
      );
    } else if (effect == 'hair') {
      final amount = selected * strength * colorAlpha;
      final luminance =
          (pixel.r * .2126 + pixel.g * .7152 + pixel.b * .0722) / 255;
      final shade = .25 + luminance * .95;
      pixel.setRgb(
        (pixel.r * (1 - amount) + (red * shade).clamp(0, 255) * amount).round(),
        (pixel.g * (1 - amount) + (green * shade).clamp(0, 255) * amount)
            .round(),
        (pixel.b * (1 - amount) + (blue * shade).clamp(0, 255) * amount)
            .round(),
      );
    } else if (effect == 'blur' && blurred != null) {
      final background = blurred.getPixelInterpolate(
        ((pixel.x + .5) * blurred.width / image.width - .5).clamp(
          0.0,
          blurred.width - 1.0,
        ),
        ((pixel.y + .5) * blurred.height / image.height - .5).clamp(
          0.0,
          blurred.height - 1.0,
        ),
        interpolation: img.Interpolation.linear,
      );
      pixel.setRgb(
        (pixel.r * (1 - selected) + background.r * selected).round(),
        (pixel.g * (1 - selected) + background.g * selected).round(),
        (pixel.b * (1 - selected) + background.b * selected).round(),
      );
    }
  }
  return img.encodePng(image, level: 3);
}

double _featheredConfidence(
  Float32List values,
  int width,
  int height,
  double normalizedX,
  double normalizedY,
) {
  final x = (normalizedX * width - .5).clamp(0.0, width - 1.0);
  final y = (normalizedY * height - .5).clamp(0.0, height - 1.0);
  final x0 = x.floor(), y0 = y.floor();
  final x1 = math.min(x0 + 1, width - 1), y1 = math.min(y0 + 1, height - 1);
  final tx = x - x0, ty = y - y0;
  final top = values[y0 * width + x0] * (1 - tx) + values[y0 * width + x1] * tx;
  final bottom =
      values[y1 * width + x0] * (1 - tx) + values[y1 * width + x1] * tx;
  final ramp = ((top * (1 - ty) + bottom * ty - .08) / .84).clamp(0.0, 1.0);
  return ramp * ramp * (3 - 2 * ramp);
}

Future<void> disposeSegmenter() async {
  final pending = _segmenter;
  _segmenter = null;
  if (pending == null) return;
  try {
    final task = await pending;
    await task.dispose();
  } on mp.MediaPipeException {
    // Creation already reported through segmentEdit.
  } on FlutterError {
    // Missing model already reported through segmentEdit.
  }
}
