import 'dart:async';
import 'dart:collection';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';

import 'editor_engine.dart';
import 'export_service.dart';
import 'face_service.dart';
import 'reference_style.dart';
import 'retouch_presets.dart';
import 'segmentation_service.dart';
import 'ui/composition.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MoruApp());
}

const _ink = Color(0xff17191d);
const _panel = Color(0xff22252b);
const _accent = Color(0xfff2b7a8);
const _muted = Color(0xffa5a8b0);

class MoruApp extends StatelessWidget {
  const MoruApp({super.key, this.initialBytes});
  final Uint8List? initialBytes;

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'moru · 포토 스튜디오',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      fontFamily: 'NotoSansKR',
      scaffoldBackgroundColor: _ink,
      colorScheme: ColorScheme.fromSeed(
        seedColor: _accent,
        brightness: Brightness.dark,
        primary: _accent,
        surface: _panel,
      ),
      sliderTheme: const SliderThemeData(
        activeTrackColor: _accent,
        thumbColor: _accent,
        trackHeight: 3,
        overlayShape: RoundSliderOverlayShape(overlayRadius: 18),
        thumbShape: RoundSliderThumbShape(enabledThumbRadius: 7),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          foregroundColor: _ink,
          backgroundColor: _accent,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
      ),
      tooltipTheme: const TooltipThemeData(
        waitDuration: Duration(milliseconds: 400),
      ),
    ),
    home: EditorScreen(initialBytes: initialBytes),
  );
}

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, this.initialBytes});
  final Uint8List? initialBytes;
  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _Document {
  const _Document({
    required this.base,
    required this.before,
    required this.original,
    required this.settings,
    required this.faces,
    required this.size,
    required this.name,
    required this.autoPreset,
    required this.autoIntensity,
    this.preview,
    this.faceMessage,
  });
  final Uint8List base, before, original;
  final Uint8List? preview;
  final EditSettings settings;
  final List<FaceGeometry> faces;
  final Size size;
  final String name;
  final String autoPreset;
  final double autoIntensity;
  final String? faceMessage;
}

class _Control {
  const _Control(
    this.label,
    this.value,
    this.update, {
    this.min = 0,
    this.negativeLabel,
    this.positiveLabel,
  });
  final String label;
  final double Function(EditSettings) value;
  final EditSettings Function(EditSettings, double) update;
  final double min;
  final String? negativeLabel, positiveLabel;
  double get max => 1;
}

class _EditorScreenState extends State<EditorScreen> {
  Uint8List? _base, _before, _original, _preview;
  Size _size = const Size(1, 1);
  EditSettings _settings = const EditSettings();
  List<FaceGeometry> _faces = const [];
  String? _faceMessage, _action, _brush;
  String _name = '사진', _group = '조정', _faceSection = '윤곽';
  String _retouchSection = '자동', _autoPreset = 'natural';
  double _autoIntensity = 0;
  int _brushColor = 0xffed7798;
  int _control = 0, _version = 0;
  bool _comparing = false, _rendering = false, _renderAgain = false;
  Timer? _previewTimer;
  _Document? _gestureStart;
  final List<_Document> _undo = [], _redo = [];
  final TransformationController _transform = TransformationController();
  double _brushRadius = .045, _brushStrength = .5;
  final List<FacePoint> _stroke = [];
  bool get _hasPhoto => _base != null;
  bool get _busy => _action != null;
  bool get _isFaceEditor => _group == '리터치' && _retouchSection == '얼굴보정';
  bool get _isMakeupEditor => _group == '리터치' && _retouchSection == '메이크업';
  bool get _faceGroup => _group == '리터치' && _retouchSection != '브러쉬';

  static const _groups = <(String, IconData)>[
    ('조정', Icons.tune_rounded),
    ('리터치', Icons.face_retouching_natural_rounded),
    ('필터', Icons.tonality_rounded),
    ('도구', Icons.crop_rotate_rounded),
    ('꾸미기', Icons.auto_awesome_mosaic_outlined),
  ];

  @override
  void initState() {
    super.initState();
    if (widget.initialBytes != null) {
      WidgetsBinding.instance.addPostFrameCallback(
        (_) => _loadPhoto(widget.initialBytes!, '샘플 사진'),
      );
    }
  }

  @override
  void dispose() {
    _previewTimer?.cancel();
    _transform.dispose();
    super.dispose();
  }

  Future<Size> _readSize(Uint8List bytes) async {
    // Every editing source is normalized to PNG. Parsing only its header is
    // portable and avoids another full-resolution pixel allocation. Flutter's
    // ImageDescriptor.width/height are unsupported for encoded images on web.
    final header = img.PngDecoder(maxPixels: maxPhotoPixels).startDecode(bytes);
    if (header == null) {
      throw const FormatException('사진 크기를 읽을 수 없습니다.');
    }
    return Size(header.width.toDouble(), header.height.toDouble());
  }

  void _notice(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
      );
  }

  _Document _snapshot() => _Document(
    base: _base!,
    before: _before!,
    original: _original!,
    preview: _preview,
    settings: _settings,
    faces: _faces,
    size: _size,
    name: _name,
    autoPreset: _autoPreset,
    autoIntensity: _autoIntensity,
    faceMessage: _faceMessage,
  );

  void _remember(_Document previous) {
    _undo.add(previous);
    if (_undo.length > 18) _undo.removeAt(0);
    _redo.clear();
    // Raster edits retain full-resolution images; cap their encoded history too.
    int historyBytes() {
      final distinct = HashSet<Uint8List>.identity();
      for (final item in _undo) {
        distinct.addAll([item.base, item.before, item.original]);
        if (item.preview != null) distinct.add(item.preview!);
      }
      return distinct.fold(0, (total, bytes) => total + bytes.lengthInBytes);
    }

    while (_undo.length > 1 && historyBytes() > 96 * 1024 * 1024) {
      _undo.removeAt(0);
    }
  }

  void _restore(_Document d) {
    _version++;
    _previewTimer?.cancel();
    setState(() {
      _base = d.base;
      _before = d.before;
      _original = d.original;
      _preview = d.preview ?? d.base;
      _settings = d.settings;
      _faces = d.faces;
      _size = d.size;
      _name = d.name;
      _autoPreset = d.autoPreset;
      _autoIntensity = d.autoIntensity;
      _faceMessage = d.faceMessage;
      _brush = null;
      _stroke.clear();
      _comparing = false;
      _gestureStart = null;
    });
    _transform.value = Matrix4.identity();
    _queuePreview(immediate: true);
  }

  void _undoEdit() {
    if (_busy || _undo.isEmpty) return;
    final previous = _undo.removeLast();
    _redo.add(_snapshot());
    _restore(previous);
  }

  void _redoEdit() {
    if (_busy || _redo.isEmpty) return;
    final next = _redo.removeLast();
    _undo.add(_snapshot());
    _restore(next);
  }

  Future<void> _pickPhoto(ImageSource source) async {
    if (_busy) return;
    try {
      final selected = await ImagePicker().pickImage(
        source: source,
        imageQuality: 100,
      );
      if (selected == null || !mounted) return;
      await _loadPhoto(await selected.readAsBytes(), selected.name);
    } catch (_) {
      _notice(
        source == ImageSource.camera
            ? '카메라를 열 수 없어요. 기기 설정에서 카메라 권한을 확인해 주세요.'
            : '사진을 열 수 없어요. JPG·PNG 사진을 다시 선택해 주세요.',
      );
    }
  }

  Future<void> _loadPhoto(Uint8List input, String name) async {
    if (_busy) return;
    _previewTimer?.cancel();
    _version++;
    setState(() => _action = '사진 준비 중');
    try {
      final bytes = await normalizePhoto(input);
      final size = await _readSize(bytes);
      if (!mounted) return;
      setState(() => _action = '얼굴 분석 중');
      final detection = await _findFaces(bytes);
      if (!mounted) return;
      _version++;
      setState(() {
        _base = bytes;
        _before = bytes;
        _original = bytes;
        _preview = bytes;
        _size = size;
        _name = name;
        _settings = const EditSettings();
        _faces = detection.$1;
        _faceMessage = detection.$2;
        _undo.clear();
        _redo.clear();
        _group = '리터치';
        _retouchSection = '자동';
        _autoPreset = 'natural';
        _autoIntensity = 0;
        _control = 0;
        _brush = null;
        _comparing = false;
        _action = null;
      });
      _transform.value = Matrix4.identity();
    } on PhotoInputException catch (error) {
      if (mounted) setState(() => _action = null);
      _notice(error.message);
    } catch (_) {
      if (mounted) setState(() => _action = null);
      _notice('사진을 읽을 수 없어요. JPG·PNG 형식의 다른 사진을 선택해 주세요.');
    }
  }

  Future<(List<FaceGeometry>, String?)> _findFaces(Uint8List bytes) async {
    try {
      final faces = await detectFaces(bytes);
      return (
        faces,
        faces.isEmpty ? '얼굴을 찾지 못했어요. 밝고 선명한 정면 사진을 사용해 보세요.' : null,
      );
    } catch (_) {
      return (
        <FaceGeometry>[],
        '이 환경에서는 얼굴 분석을 시작하지 못했어요. 조정·필터·수동 도구는 사용할 수 있어요.',
      );
    }
  }

  void _queuePreview({bool immediate = false}) {
    _version++;
    _previewTimer?.cancel();
    if (immediate) {
      _runPreview();
    } else {
      _previewTimer = Timer(const Duration(milliseconds: 210), _runPreview);
    }
  }

  Future<void> _runPreview() async {
    if (!mounted || !_hasPhoto || _busy) return;
    if (_rendering) {
      _renderAgain = true;
      return;
    }
    final version = _version;
    final bytes = _base!;
    final settings = _settings;
    final faces = _faces;
    _renderAgain = false;
    setState(() => _rendering = true);
    try {
      final result = await renderImage(
        bytes,
        settings,
        faces: faces,
        maxDimension: 1440,
      );
      if (mounted && version == _version) setState(() => _preview = result);
    } catch (_) {
      if (mounted && version == _version) {
        _notice('미리보기를 만들지 못했어요. 강도를 낮추거나 다시 시도해 주세요.');
      }
    } finally {
      if (mounted) {
        setState(() => _rendering = false);
        if (_renderAgain || version != _version) _runPreview();
      }
    }
  }

  void _changeSettings(EditSettings value, {bool record = false}) {
    if (_busy || !_hasPhoto) return;
    if (record) _remember(_snapshot());
    setState(() => _settings = value);
    _queuePreview();
  }

  void _startSlider(double _) => _gestureStart = _snapshot();
  void _endSlider(double _) {
    if (_gestureStart != null) {
      setState(() => _remember(_gestureStart!));
      _gestureStart = null;
    }
    _queuePreview(immediate: true);
  }

  Future<Uint8List> _fullRender() =>
      renderImage(_base!, _settings, faces: _faces, maxDimension: 0);

  Future<void> _save() async {
    if (!_hasPhoto || _busy) return;
    _previewTimer?.cancel();
    setState(() => _action = '고화질로 저장 중');
    try {
      final result = await _fullRender();
      await exportPhoto(
        result,
        filename: 'moru-${DateTime.now().millisecondsSinceEpoch}.png',
      );
      _notice(kIsWeb ? '사진을 다운로드했어요.' : '사진을 저장했어요.');
    } catch (_) {
      _notice('저장하지 못했어요. 사진 접근 권한과 기기 저장 공간을 확인해 주세요.');
    } finally {
      if (mounted) {
        setState(() => _action = null);
        _queuePreview(immediate: true);
      }
    }
  }

  Future<void> _reset() async {
    if (!_hasPhoto || _busy) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('처음 사진으로 돌아갈까요?'),
        content: const Text('지금까지의 보정을 초기화해요. 되돌리기로 다시 복원할 수 있어요.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('초기화'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final previous = _snapshot();
    setState(() => _action = '처음 사진으로 복원 중');
    try {
      await _replaceBase(_original!, before: _original!);
      if (mounted) setState(() => _remember(previous));
    } catch (_) {
      _notice('초기화하지 못했어요. 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => _action = null);
    }
  }

  Future<void> _replaceBase(
    Uint8List bytes, {
    Uint8List? before,
    bool keepOriginal = true,
    bool preserveView = false,
  }) async {
    final size = await _readSize(bytes);
    final keepTransform = preserveView && size == _size;
    final detection = await _findFaces(bytes);
    if (!mounted) return;
    _version++;
    setState(() {
      _base = bytes;
      _before = before ?? _before ?? bytes;
      if (!keepOriginal) _original = bytes;
      _preview = bytes;
      _settings = const EditSettings();
      _autoPreset = 'natural';
      _autoIntensity = 0;
      _size = size;
      _faces = detection.$1;
      _faceMessage = detection.$2;
      _stroke.clear();
      _comparing = false;
    });
    if (!keepTransform) _transform.value = Matrix4.identity();
  }

  Future<void> _transformPhoto(String kind, {double? ratio}) async {
    if (!_hasPhoto || _busy) return;
    final previous = _snapshot();
    setState(() => _action = '사진 편집 중');
    try {
      final rendered = await _fullRender();
      Future<Uint8List> change(Uint8List input) {
        if (kind == 'rotate') return rotateImage(input);
        if (kind == 'flip') return flipImage(input);
        return cropImage(input, ratio!);
      }

      final bytes = await change(rendered);
      final before = await change(_before!);
      await _replaceBase(bytes, before: before);
      if (mounted) setState(() => _remember(previous));
    } catch (_) {
      _notice('편집을 적용하지 못했어요. 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => _action = null);
    }
  }

  Future<void> _applyStroke() async {
    if (!_hasPhoto || _busy || _stroke.isEmpty || _brush == null) return;
    final previous = _snapshot();
    final points = List<FacePoint>.of(_stroke);
    final tool = _brush!;
    setState(() {
      _action = '부분 보정 중';
      _stroke.clear();
    });
    try {
      final bytes = await applyBrush(
        await _fullRender(),
        tool,
        points,
        radius: _brushRadius,
        strength: _brushStrength,
        color: _brushColor,
      );
      await _replaceBase(bytes, preserveView: true);
      if (mounted) setState(() => _remember(previous));
    } catch (_) {
      _notice('부분 보정을 적용하지 못했어요. 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => _action = null);
    }
  }

  Future<void> _addText() async {
    if (_busy || !_hasPhoto) return;
    final options = await showDialog<TextDecorationOptions>(
      context: context,
      builder: (_) => const PhotoTextDialog(),
    );
    if (options == null || !mounted) return;
    final previous = _snapshot();
    setState(() => _action = '글자 넣는 중');
    try {
      await _replaceBase(await addTextToPhoto(await _fullRender(), options));
      if (mounted) setState(() => _remember(previous));
    } catch (_) {
      _notice('글자를 넣지 못했어요. 글자 수를 줄이고 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => _action = null);
    }
  }

  Future<void> _collage() async {
    if (_busy) return;
    try {
      final picked = await ImagePicker().pickMultiImage(imageQuality: 100);
      if (picked.length < 2) {
        if (picked.isNotEmpty) _notice('콜라주에 사용할 사진을 2장 이상 선택해 주세요.');
        return;
      }
      if (!mounted) return;
      final previous = _hasPhoto ? _snapshot() : null;
      setState(() => _action = '콜라주 만드는 중');
      final photos = <Uint8List>[];
      for (final item in picked.take(4)) {
        photos.add(await normalizePhoto(await item.readAsBytes()));
      }
      final bytes = await makeCollage(photos);
      await _replaceBase(bytes, before: bytes, keepOriginal: false);
      if (mounted) {
        setState(() {
          _name = '콜라주';
          _brush = null;
          if (previous != null) _remember(previous);
        });
      }
      if (picked.length > 4) _notice('선택한 사진 중 처음 4장으로 콜라주를 만들었어요.');
    } catch (_) {
      _notice('콜라주를 만들지 못했어요. JPG·PNG 사진 2~4장으로 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => _action = null);
    }
  }

  Future<void> _sample() async {
    try {
      final data = await rootBundle.load('assets/samples/astronaut.png');
      await _loadPhoto(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        '샘플 사진',
      );
    } catch (_) {
      _notice('샘플 사진을 열지 못했어요. 직접 사진을 선택해 주세요.');
    }
  }

  Future<void> _referenceStyle() async {
    if (_busy || !_hasPhoto) return;
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 100,
      );
      if (picked == null || !mounted) return;
      final previous = _snapshot();
      setState(() => _action = '참고 사진의 색감 맞추는 중');
      final reference = await normalizePhoto(await picked.readAsBytes());
      await _replaceBase(
        await matchReferenceStyle(await _fullRender(), reference),
      );
      if (mounted) setState(() => _remember(previous));
    } catch (_) {
      _notice('참고 색감을 적용하지 못했어요. 다른 사진으로 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => _action = null);
    }
  }

  Future<void> _segment(String effect) async {
    if (_busy || !_hasPhoto) return;
    int color = effect == 'hair' ? 0xff8f6789 : 0xffe8ddd1;
    if (effect == 'hair' || effect == 'background') {
      final selected = await showDialog<int>(
        context: context,
        builder: (context) => SimpleDialog(
          title: Text(effect == 'hair' ? '염색 컬러 선택' : '배경 컬러 선택'),
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Wrap(
                spacing: 15,
                runSpacing: 15,
                children:
                    <int>[
                          0xffe8ddd1,
                          0xffbba2cf,
                          0xff8f6789,
                          0xffb37a59,
                          0xff89aaa1,
                          0xff383237,
                          0xfffafafa,
                          0xff647695,
                        ]
                        .map(
                          (value) => InkWell(
                            onTap: () => Navigator.pop(context, value),
                            borderRadius: BorderRadius.circular(30),
                            child: Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                color: Color(value),
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white38),
                              ),
                            ),
                          ),
                        )
                        .toList(),
              ),
            ),
          ],
        ),
      );
      if (selected == null || !mounted) return;
      color = selected;
    }
    final previous = _snapshot();
    setState(() => _action = effect == 'hair' ? '헤어 컬러 적용 중' : '배경 편집 중');
    try {
      await _replaceBase(
        await segmentEdit(await _fullRender(), effect: effect, color: color),
      );
      if (mounted) setState(() => _remember(previous));
    } catch (_) {
      _notice('인물 영역을 분석하지 못했어요. 인물이 선명하게 보이는 사진으로 다시 시도해 주세요.');
    } finally {
      if (mounted) setState(() => _action = null);
    }
  }

  List<_Control> _controls() {
    if (_group == '리터치') {
      if (_retouchSection == '얼굴보정') return _faceControls();
      if (_retouchSection == '볼륨·리프팅') {
        return [
          _Control(
            '볼 리프팅',
            (s) => s.cheekLift,
            (s, v) => s.copyWith(cheekLift: v),
            negativeLabel: '기본',
            positiveLabel: '올리기',
          ),
          _Control(
            '관자 리프팅',
            (s) => s.templeLift,
            (s, v) => s.copyWith(templeLift: v),
            negativeLabel: '기본',
            positiveLabel: '올리기',
          ),
          _Control(
            '팔자 리프팅',
            (s) => s.nasolabialLift,
            (s, v) => s.copyWith(nasolabialLift: v),
            negativeLabel: '기본',
            positiveLabel: '올리기',
          ),
          _fineControl(
            '눈밑 볼륨',
            (s) => s.underEyeVolume,
            (s, v) => s.copyWith(underEyeVolume: v),
            negative: '줄이기',
            positive: '채우기',
          ),
          _fineControl(
            '볼 볼륨',
            (s) => s.cheekVolume,
            (s, v) => s.copyWith(cheekVolume: v),
            negative: '줄이기',
            positive: '채우기',
          ),
        ];
      }
      if (_retouchSection == '메이크업') {
        return [
          _Control(
            '립 컬러',
            (s) => s.lipstick,
            (s, v) => s.copyWith(lipstick: v),
          ),
          _Control('블러셔', (s) => s.blush, (s, v) => s.copyWith(blush: v)),
          _Control(
            '아이섀도',
            (s) => s.eyeshadow,
            (s, v) => s.copyWith(eyeshadow: v),
          ),
          _Control(
            '아이라인',
            (s) => s.eyeliner,
            (s, v) => s.copyWith(eyeliner: v),
          ),
          _Control(
            '눈썹 채우기',
            (s) => s.browFill,
            (s, v) => s.copyWith(browFill: v),
          ),
          _Control(
            '립 글로스',
            (s) => s.lipGloss,
            (s, v) => s.copyWith(lipGloss: v),
          ),
        ];
      }
      if (_retouchSection == '피부') {
        return [
          _Control(
            '팔자주름 제거',
            (s) => s.nasolabialFoldRemove,
            (s, v) => s.copyWith(nasolabialFoldRemove: v),
          ),
          _Control(
            '잔주름 완화',
            (s) => s.wrinkleRemove,
            (s, v) => s.copyWith(wrinkleRemove: v),
          ),
          _Control(
            '피부결',
            (s) => s.skinSmooth,
            (s, v) => s.copyWith(skinSmooth: v),
          ),
          _Control(
            '잡티 완화',
            (s) => s.blemishRemoval,
            (s, v) => s.copyWith(blemishRemoval: v),
          ),
          _Control(
            '피부결 복원',
            (s) => s.skinTexture,
            (s, v) => s.copyWith(skinTexture: v),
          ),
          _Control(
            '피부 톤',
            (s) => s.skinBrighten,
            (s, v) => s.copyWith(skinBrighten: v),
          ),
          _Control(
            '다크서클',
            (s) => s.darkCircleReduce,
            (s, v) => s.copyWith(darkCircleReduce: v),
          ),
          _Control(
            '붉은기',
            (s) => s.rednessReduce,
            (s, v) => s.copyWith(rednessReduce: v),
          ),
          _Control(
            '눈 밝기',
            (s) => s.eyeBrighten,
            (s, v) => s.copyWith(eyeBrighten: v),
          ),
          _Control(
            '치아 미백',
            (s) => s.teethWhiten,
            (s, v) => s.copyWith(teethWhiten: v),
          ),
        ];
      }
    }
    switch (_group) {
      case '피부':
        return [
          _Control(
            '피부결',
            (s) => s.skinSmooth,
            (s, v) => s.copyWith(skinSmooth: v),
          ),
          _Control(
            '피부 톤',
            (s) => s.skinBrighten,
            (s, v) => s.copyWith(skinBrighten: v),
          ),
          _Control(
            '눈 밝기',
            (s) => s.eyeBrighten,
            (s, v) => s.copyWith(eyeBrighten: v),
          ),
          _Control(
            '치아 미백',
            (s) => s.teethWhiten,
            (s, v) => s.copyWith(teethWhiten: v),
          ),
        ];
      case '얼굴':
        return _faceControls();
      case '메이크업':
        return [
          _Control(
            '립 컬러',
            (s) => s.lipstick,
            (s, v) => s.copyWith(lipstick: v),
          ),
          _Control('블러셔', (s) => s.blush, (s, v) => s.copyWith(blush: v)),
        ];
      default:
        return [
          _Control(
            '밝기',
            (s) => s.exposure,
            (s, v) => s.copyWith(exposure: v),
            min: -1,
          ),
          _Control(
            '대비',
            (s) => s.contrast,
            (s, v) => s.copyWith(contrast: v),
            min: -1,
          ),
          _Control(
            '채도',
            (s) => s.saturation,
            (s, v) => s.copyWith(saturation: v),
            min: -1,
          ),
          _Control(
            '색온도',
            (s) => s.warmth,
            (s, v) => s.copyWith(warmth: v),
            min: -1,
          ),
          _Control(
            '밝은 영역',
            (s) => s.highlights,
            (s, v) => s.copyWith(highlights: v),
            min: -1,
          ),
          _Control(
            '어두운 영역',
            (s) => s.shadows,
            (s, v) => s.copyWith(shadows: v),
            min: -1,
          ),
          _Control(
            '선명도',
            (s) => s.sharpness,
            (s, v) => s.copyWith(sharpness: v),
          ),
          _Control('비네트', (s) => s.vignette, (s, v) => s.copyWith(vignette: v)),
          _Control('그레인', (s) => s.grain, (s, v) => s.copyWith(grain: v)),
        ];
    }
  }

  _Control _fineControl(
    String label,
    double Function(EditSettings) read,
    EditSettings Function(EditSettings, double) update, {
    String negative = '좁게',
    String positive = '넓게',
  }) => _Control(
    label,
    read,
    update,
    min: -1,
    negativeLabel: negative,
    positiveLabel: positive,
  );

  List<_Control> _faceControls() {
    switch (_faceSection) {
      case '눈':
        return [
          _fineControl(
            '눈 가로 폭',
            (s) => s.eyeWidth,
            (s, v) => s.copyWith(eyeWidth: v),
          ),
          _fineControl(
            '눈 세로 폭',
            (s) => s.eyeHeight,
            (s, v) => s.copyWith(eyeHeight: v),
            negative: '낮게',
            positive: '높게',
          ),
          _fineControl(
            '눈 사이 간격',
            (s) => s.eyeSpacing,
            (s, v) => s.copyWith(eyeSpacing: v),
            negative: '가깝게',
            positive: '멀게',
          ),
          _fineControl(
            '눈꼬리 각도',
            (s) => s.eyeTilt,
            (s, v) => s.copyWith(eyeTilt: v),
            negative: '눈꼬리 내리기',
            positive: '눈꼬리 올리기',
          ),
          _fineControl(
            '눈 위치',
            (s) => s.eyePosition,
            (s, v) => s.copyWith(eyePosition: v),
            negative: '위로',
            positive: '아래로',
          ),
          _Control(
            '눈 전체 확대',
            (s) => s.eyeEnlarge,
            (s, v) => s.copyWith(eyeEnlarge: v),
            negativeLabel: '기본',
            positiveLabel: '크게',
          ),
        ];
      case '코':
        return [
          _fineControl(
            '콧망울 너비',
            (s) => s.noseAlarWidth,
            (s, v) => s.copyWith(noseAlarWidth: v),
          ),
          _fineControl(
            '콧대 너비',
            (s) => s.noseBridgeWidth,
            (s, v) => s.copyWith(noseBridgeWidth: v),
          ),
          _fineControl(
            '콧등 너비',
            (s) => s.noseDorsumWidth,
            (s, v) => s.copyWith(noseDorsumWidth: v),
          ),
          _fineControl(
            '코끝 크기',
            (s) => s.noseTipSize,
            (s, v) => s.copyWith(noseTipSize: v),
            negative: '작게',
            positive: '크게',
          ),
          _fineControl(
            '코끝 들기',
            (s) => s.noseTipLift,
            (s, v) => s.copyWith(noseTipLift: v),
            negative: '내리기',
            positive: '올리기',
          ),
          _fineControl(
            '코 길이',
            (s) => s.noseLength,
            (s, v) => s.copyWith(noseLength: v),
            negative: '짧게',
            positive: '길게',
          ),
          _fineControl(
            '코 위치',
            (s) => s.nosePosition,
            (s, v) => s.copyWith(nosePosition: v),
            negative: '위로',
            positive: '아래로',
          ),
          _Control(
            '코 전체 슬림',
            (s) => s.noseSlim,
            (s, v) => s.copyWith(noseSlim: v),
            negativeLabel: '기본',
            positiveLabel: '슬림하게',
          ),
        ];
      case '입':
        return [
          _fineControl(
            '입 너비',
            (s) => s.lipWidth,
            (s, v) => s.copyWith(lipWidth: v),
          ),
          _fineControl(
            '윗입술 볼륨',
            (s) => s.upperLipFullness,
            (s, v) => s.copyWith(upperLipFullness: v),
            negative: '얇게',
            positive: '도톰하게',
          ),
          _fineControl(
            '아랫입술 볼륨',
            (s) => s.lowerLipFullness,
            (s, v) => s.copyWith(lowerLipFullness: v),
            negative: '얇게',
            positive: '도톰하게',
          ),
          _fineControl(
            '입 위치',
            (s) => s.mouthPosition,
            (s, v) => s.copyWith(mouthPosition: v),
            negative: '위로',
            positive: '아래로',
          ),
          _fineControl(
            '입꼬리',
            (s) => s.mouthSmile,
            (s, v) => s.copyWith(mouthSmile: v),
            negative: '입꼬리 내리기',
            positive: '입꼬리 올리기',
          ),
        ];
      case '눈썹':
        return [
          _fineControl(
            '눈썹 높이',
            (s) => s.browHeight,
            (s, v) => s.copyWith(browHeight: v),
            negative: '아래로',
            positive: '위로',
          ),
          _fineControl(
            '눈썹 간격',
            (s) => s.browSpacing,
            (s, v) => s.copyWith(browSpacing: v),
            negative: '가깝게',
            positive: '멀게',
          ),
          _fineControl(
            '눈썹 각도',
            (s) => s.browTilt,
            (s, v) => s.copyWith(browTilt: v),
            negative: '바깥쪽 내리기',
            positive: '바깥쪽 올리기',
          ),
        ];
      default:
        return [
          _fineControl(
            '머리 크기',
            (s) => s.headSize,
            (s, v) => s.copyWith(headSize: v),
            negative: '작게',
            positive: '크게',
          ),
          _fineControl(
            '광대 너비',
            (s) => s.cheekboneWidth,
            (s, v) => s.copyWith(cheekboneWidth: v),
          ),
          _fineControl(
            '턱선 너비',
            (s) => s.jawWidth,
            (s, v) => s.copyWith(jawWidth: v),
          ),
          _fineControl(
            '턱끝 너비',
            (s) => s.chinWidth,
            (s, v) => s.copyWith(chinWidth: v),
          ),
          _fineControl(
            '얼굴 길이',
            (s) => s.faceLength,
            (s, v) => s.copyWith(faceLength: v),
            negative: '짧게',
            positive: '길게',
          ),
          _Control(
            '턱 길이',
            (s) => s.chinLength,
            (s, v) => s.copyWith(chinLength: v),
            min: -1,
            negativeLabel: '짧게',
            positiveLabel: '길게',
          ),
          _Control(
            '얼굴 전체 슬림',
            (s) => s.faceSlim,
            (s, v) => s.copyWith(faceSlim: v),
            negativeLabel: '기본',
            positiveLabel: '슬림하게',
          ),
        ];
    }
  }

  void _setGroup(String group) {
    setState(() {
      _group = group;
      _control = 0;
      _brush = null;
      _stroke.clear();
      _comparing = false;
    });
    _transform.value = Matrix4.identity();
  }

  @override
  Widget build(BuildContext context) => Shortcuts(
    shortcuts: const <ShortcutActivator, Intent>{
      SingleActivator(LogicalKeyboardKey.keyZ, control: true): UndoIntent(),
      SingleActivator(LogicalKeyboardKey.keyZ, control: true, shift: true):
          RedoIntent(),
      SingleActivator(LogicalKeyboardKey.keyS, control: true): SaveIntent(),
      SingleActivator(LogicalKeyboardKey.keyZ, meta: true): UndoIntent(),
      SingleActivator(LogicalKeyboardKey.keyZ, meta: true, shift: true):
          RedoIntent(),
      SingleActivator(LogicalKeyboardKey.keyS, meta: true): SaveIntent(),
    },
    child: Actions(
      actions: {
        UndoIntent: CallbackAction<UndoIntent>(
          onInvoke: (_) {
            _undoEdit();
            return null;
          },
        ),
        RedoIntent: CallbackAction<RedoIntent>(
          onInvoke: (_) {
            _redoEdit();
            return null;
          },
        ),
        SaveIntent: CallbackAction<SaveIntent>(
          onInvoke: (_) {
            _save();
            return null;
          },
        ),
      },
      child: Focus(
        autofocus: true,
        child: Scaffold(
          body: SafeArea(
            child: Column(
              children: [
                _header(),
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      if (!_hasPhoto) return _welcome(constraints);
                      if (constraints.maxWidth >= 900) {
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(24, 4, 24, 24),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Expanded(child: _photoWorkspace()),
                              const SizedBox(width: 20),
                              SizedBox(
                                width: 350,
                                child: _controlsPanel(wide: true),
                              ),
                            ],
                          ),
                        );
                      }
                      return Column(
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                              child: _photoWorkspace(),
                            ),
                          ),
                          _controlsPanel(wide: false),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );

  Widget _header() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
    child: Row(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: _accent,
            borderRadius: BorderRadius.circular(11),
          ),
          child: const Icon(
            Icons.filter_vintage_rounded,
            color: _ink,
            size: 22,
          ),
        ),
        const SizedBox(width: 10),
        const Text(
          'moru',
          style: TextStyle(
            fontSize: 25,
            letterSpacing: -.8,
            fontWeight: FontWeight.w700,
          ),
        ),
        if (MediaQuery.sizeOf(context).width >= 550) ...[
          const SizedBox(width: 14),
          const Text(
            '나답게, 조금 더.',
            style: TextStyle(color: _muted, fontSize: 12),
          ),
        ],
        const Spacer(),
        if (_hasPhoto) ...[
          IconButton(
            tooltip: '사진 바꾸기',
            onPressed: _busy ? null : () => _pickPhoto(ImageSource.gallery),
            icon: const Icon(Icons.add_photo_alternate_outlined, size: 22),
          ),
          const SizedBox(width: 5),
          FilledButton.icon(
            onPressed: _busy ? null : _save,
            icon: _action == '고화질로 저장 중'
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.file_download_outlined, size: 19),
            label: const Text('저장'),
          ),
        ] else
          IconButton(
            tooltip: '오픈소스 라이선스',
            onPressed: () => showLicensePage(
              context: context,
              applicationName: 'moru',
              applicationVersion: '0.1.0',
            ),
            icon: const Icon(
              Icons.info_outline_rounded,
              color: _muted,
              size: 22,
            ),
          ),
      ],
    ),
  );

  Widget _welcome(BoxConstraints constraints) => Center(
    child: SingleChildScrollView(
      padding: EdgeInsets.symmetric(
        horizontal: constraints.maxWidth < 600 ? 26 : 56,
        vertical: 22,
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 680),
        child: Column(
          children: [
            SizedBox(
              width: 230,
              height: 205,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 170,
                    height: 170,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          _accent.withValues(alpha: .14),
                          _ink.withValues(alpha: 0),
                        ],
                      ),
                    ),
                  ),
                  Transform.rotate(
                    angle: -.13,
                    child: Container(
                      width: 124,
                      height: 158,
                      decoration: BoxDecoration(
                        color: const Color(0xffdba594),
                        borderRadius: BorderRadius.circular(19),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: .2),
                            blurRadius: 25,
                            offset: const Offset(0, 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Transform.rotate(
                    angle: .10,
                    child: Container(
                      width: 124,
                      height: 158,
                      margin: const EdgeInsets.only(left: 38, top: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xfff1dbce),
                        borderRadius: BorderRadius.circular(19),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: .5),
                        ),
                      ),
                      child: const Icon(
                        Icons.face_retouching_natural,
                        size: 69,
                        color: Color(0xff8a645d),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 29,
                    top: 13,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        color: _accent,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.tune_rounded,
                        color: _ink,
                        size: 22,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Text(
              '좋은 순간을,\n내 취향으로.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 29,
                height: 1.45,
                fontWeight: FontWeight.w700,
                letterSpacing: -1.1,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              '피부결부터 색감까지 섬세하게 다듬어 보세요.\n사진은 기기 안에서만 처리돼요.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: _muted, height: 1.9),
            ),
            const SizedBox(height: 30),
            if (_busy)
              _loadingPill(_action!)
            else ...[
              FilledButton.icon(
                onPressed: () => _pickPhoto(ImageSource.gallery),
                icon: const Icon(Icons.add_photo_alternate_outlined),
                label: const Text('사진 열기'),
                style: FilledButton.styleFrom(minimumSize: const Size(240, 54)),
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt_outlined, size: 18),
                    label: const Text('사진 촬영'),
                  ),
                  const SizedBox(width: 8),
                  TextButton.icon(
                    onPressed: _collage,
                    icon: const Icon(Icons.dashboard_outlined, size: 18),
                    label: const Text('콜라주'),
                  ),
                ],
              ),
              TextButton(
                onPressed: _sample,
                child: const Text(
                  '샘플로 둘러보기',
                  style: TextStyle(fontSize: 11, color: _muted),
                ),
              ),
            ],
            const SizedBox(height: 37),
            const Wrap(
              spacing: 24,
              runSpacing: 12,
              alignment: WrapAlignment.center,
              children: [
                _WelcomeNote(Icons.water_drop_outlined, '섬세한 피부 보정'),
                _WelcomeNote(Icons.palette_outlined, '취향을 담은 색감'),
                _WelcomeNote(Icons.lock_outline_rounded, '사진 업로드 없음'),
              ],
            ),
          ],
        ),
      ),
    ),
  );

  Widget _photoWorkspace() => Container(
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(
      color: const Color(0xff101216),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 9, 8, 0),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  _name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _muted, fontSize: 11),
                ),
              ),
              IconButton(
                tooltip: '되돌리기',
                onPressed: _busy || _undo.isEmpty ? null : _undoEdit,
                icon: const Icon(Icons.undo_rounded, size: 20),
              ),
              IconButton(
                tooltip: '다시 적용',
                onPressed: _busy || _redo.isEmpty ? null : _redoEdit,
                icon: const Icon(Icons.redo_rounded, size: 20),
              ),
              IconButton(
                tooltip: '전체 초기화',
                onPressed: _busy ? null : _reset,
                icon: const Icon(Icons.restart_alt_rounded, size: 20),
              ),
            ],
          ),
        ),
        Expanded(
          child: Stack(
            children: [
              Positioned.fill(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final fitted = applyBoxFit(
                      BoxFit.contain,
                      _size,
                      constraints.biggest,
                    );
                    final rect = Alignment.center.inscribe(
                      fitted.destination,
                      Offset.zero & constraints.biggest,
                    );
                    void addPoint(Offset offset) {
                      if (_brush == null || _busy) {
                        return;
                      }
                      final scene = _transform.toScene(offset);
                      if (!rect.contains(scene)) return;
                      setState(
                        () => _stroke.add(
                          FacePoint(
                            (scene.dx - rect.left) / rect.width,
                            (scene.dy - rect.top) / rect.height,
                          ),
                        ),
                      );
                    }

                    return MouseRegion(
                      cursor: _brush == null
                          ? SystemMouseCursors.basic
                          : SystemMouseCursors.precise,
                      child: GestureDetector(
                        key: const ValueKey('photo-touch-canvas'),
                        behavior: HitTestBehavior.opaque,
                        onPanStart: _brush == null
                            ? null
                            : (d) {
                                _stroke.clear();
                                addPoint(d.localPosition);
                              },
                        onPanUpdate: _brush == null
                            ? null
                            : (d) => addPoint(d.localPosition),
                        onPanEnd: _brush == null ? null : (_) => _applyStroke(),
                        onTapUp: _brush == null
                            ? null
                            : (d) {
                                _stroke.clear();
                                addPoint(d.localPosition);
                                _applyStroke();
                              },
                        child: Stack(
                          children: [
                            Positioned.fill(
                              child: IgnorePointer(
                                ignoring: _brush != null,
                                child: InteractiveViewer(
                                  transformationController: _transform,
                                  minScale: 1,
                                  maxScale: 6,
                                  panEnabled: _brush == null,
                                  scaleEnabled: _brush == null,
                                  child: Image.memory(
                                    _comparing
                                        ? _before!
                                        : (_preview ?? _base!),
                                    fit: BoxFit.contain,
                                    gaplessPlayback: true,
                                    filterQuality: FilterQuality.high,
                                    width: constraints.maxWidth,
                                    height: constraints.maxHeight,
                                  ),
                                ),
                              ),
                            ),
                            if (_stroke.isNotEmpty)
                              Positioned.fill(
                                child: IgnorePointer(
                                  child: AnimatedBuilder(
                                    animation: _transform,
                                    builder: (context, child) => CustomPaint(
                                      painter: _StrokePainter(
                                        List<FacePoint>.of(_stroke),
                                        rect,
                                        _brushRadius,
                                        Matrix4.copy(_transform.value),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            if (_brush != null)
                              Positioned(
                                right: 10,
                                bottom: 10,
                                child: _zoomTools(constraints.biggest),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              if (_comparing)
                Positioned(top: 12, left: 12, child: _tag('편집 전')),
              if (_busy)
                Positioned.fill(
                  child: ColoredBox(
                    color: Colors.black.withValues(alpha: .40),
                    child: Center(child: _loadingPill(_action!)),
                  ),
                )
              else if (_rendering)
                const Positioned(
                  top: 12,
                  right: 14,
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: _accent,
                    ),
                  ),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  '${_size.width.toInt()} × ${_size.height.toInt()}  ·  ${_faces.isEmpty ? '수동 편집' : '얼굴 ${_faces.length}명'}',
                  style: const TextStyle(color: _muted, fontSize: 10),
                ),
              ),
              Semantics(
                label: '길게 눌러 편집 전 사진 비교',
                button: true,
                child: GestureDetector(
                  onTapDown: _busy
                      ? null
                      : (_) => setState(() => _comparing = true),
                  onTapUp: (_) => setState(() => _comparing = false),
                  onTapCancel: () => setState(() => _comparing = false),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: _comparing
                          ? _accent
                          : Colors.white.withValues(alpha: .07),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.compare_rounded,
                          size: 16,
                          color: _comparing ? _ink : Colors.white70,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          '길게 눌러 비교',
                          style: TextStyle(
                            fontSize: 11,
                            color: _comparing ? _ink : Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  void _zoomPhoto(double factor, Size viewport) {
    if (_busy) return;
    final oldScale = _transform.value.getMaxScaleOnAxis();
    final scale = (oldScale * factor).clamp(1.0, 6.0).toDouble();
    if (scale <= 1) {
      _transform.value = Matrix4.identity();
      return;
    }
    final center = Offset(viewport.width / 2, viewport.height / 2);
    final scene = _transform.toScene(center);
    _transform.value = Matrix4.diagonal3Values(scale, scale, 1)
      ..setTranslationRaw(
        center.dx - scene.dx * scale,
        center.dy - scene.dy * scale,
        0,
      );
  }

  Widget _zoomTools(Size viewport) => AnimatedBuilder(
    animation: _transform,
    builder: (context, child) {
      final scale = _transform.value.getMaxScaleOnAxis();
      return Material(
        color: const Color(0xe622252b),
        borderRadius: BorderRadius.circular(12),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 36,
              height: 36,
              child: IconButton(
                key: const ValueKey('canvas-zoom-out'),
                tooltip: '사진 축소',
                padding: EdgeInsets.zero,
                iconSize: 20,
                onPressed: _busy || scale <= 1
                    ? null
                    : () => _zoomPhoto(1 / 1.35, viewport),
                icon: const Icon(Icons.zoom_out_rounded),
              ),
            ),
            SizedBox(
              width: 35,
              child: Text(
                '${scale.toStringAsFixed(1)}×',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 10),
              ),
            ),
            SizedBox(
              width: 36,
              height: 36,
              child: IconButton(
                key: const ValueKey('canvas-zoom-in'),
                tooltip: '사진 확대',
                padding: EdgeInsets.zero,
                iconSize: 20,
                onPressed: _busy || scale >= 6
                    ? null
                    : () => _zoomPhoto(1.35, viewport),
                icon: const Icon(Icons.zoom_in_rounded),
              ),
            ),
            SizedBox(
              width: 36,
              height: 36,
              child: IconButton(
                key: const ValueKey('canvas-fit'),
                tooltip: '화면에 맞추기',
                padding: EdgeInsets.zero,
                iconSize: 19,
                onPressed: _busy
                    ? null
                    : () => _transform.value = Matrix4.identity(),
                icon: const Icon(Icons.fit_screen_rounded),
              ),
            ),
          ],
        ),
      );
    },
  );

  Widget _controlsPanel({required bool wide}) => Container(
    decoration: BoxDecoration(
      color: _panel,
      borderRadius: wide
          ? BorderRadius.circular(20)
          : const BorderRadius.vertical(top: Radius.circular(22)),
    ),
    child: Column(
      mainAxisSize: wide ? MainAxisSize.max : MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (wide)
          const Padding(
            padding: EdgeInsets.fromLTRB(22, 23, 22, 16),
            child: Row(
              children: [
                Text(
                  'EDIT STUDIO',
                  style: TextStyle(
                    color: _muted,
                    fontSize: 10,
                    letterSpacing: 2.2,
                  ),
                ),
                Spacer(),
                Icon(Icons.lock_outline_rounded, size: 13, color: _muted),
                SizedBox(width: 4),
                Text('기기에서 편집', style: TextStyle(color: _muted, fontSize: 10)),
              ],
            ),
          ),
        _groupSelector(wide),
        if (wide) const SizedBox(height: 16),
        if (wide)
          Expanded(child: SingleChildScrollView(child: _editorControls(true)))
        else
          SizedBox(
            height: _group == '리터치'
                ? 320
                : (_group == '도구' || _group == '꾸미기' ? 222 : 185),
            child: SingleChildScrollView(child: _editorControls(false)),
          ),
        if (wide)
          Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                const Icon(Icons.pinch_outlined, size: 15, color: _muted),
                const SizedBox(width: 7),
                const Expanded(
                  child: Text(
                    '확대해서 피부결과 윤곽을 확인해 보세요.',
                    style: TextStyle(fontSize: 10, color: _muted),
                  ),
                ),
                IconButton(
                  tooltip: '오픈소스 라이선스',
                  icon: const Icon(Icons.info_outline_rounded, size: 17),
                  onPressed: () => showLicensePage(
                    context: context,
                    applicationName: 'moru',
                    applicationVersion: '0.1.0',
                  ),
                ),
              ],
            ),
          ),
      ],
    ),
  );

  Widget _groupSelector(bool wide) {
    final chips = _groups.map((item) {
      final selected = _group == item.$1;
      return Padding(
        padding: const EdgeInsets.only(right: 5),
        child: Material(
          color: selected ? _accent.withValues(alpha: .13) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            onTap: _busy ? null : () => _setGroup(item.$1),
            borderRadius: BorderRadius.circular(12),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(item.$2, size: 22, color: selected ? _accent : _muted),
                  const SizedBox(height: 5),
                  Text(
                    item.$1,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                      color: selected ? _accent : _muted,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }).toList();
    if (wide) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 13),
        child: Wrap(spacing: 1, runSpacing: 5, children: chips),
      );
    }
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.fromLTRB(12, 12, 6, 2),
      child: Row(children: chips),
    );
  }

  Widget _editorControls(bool wide) {
    if (_group == '필터') return _filters(wide);
    if (_group == '도구') return _tools(wide);
    if (_group == '꾸미기') return _decorationTools();
    if (_group == '리터치' && _retouchSection == '자동') {
      return Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _retouchSectionSelector(),
            const SizedBox(height: 18),
            _automaticControls(),
          ],
        ),
      );
    }
    if (_group == '리터치' && _retouchSection == '브러쉬') {
      return Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _retouchSectionSelector(),
            const SizedBox(height: 18),
            _brushControls(),
          ],
        ),
      );
    }
    final controls = _controls();
    final selected = controls[math.min(_control, controls.length - 1)];
    final enabled = !_busy && (!_faceGroup || _faces.isNotEmpty);
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 13, 18, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (_group == '리터치') ...[
            _retouchSectionSelector(),
            const SizedBox(height: 12),
          ],
          if (_isFaceEditor) ...[
            _faceSectionSelector(),
            const SizedBox(height: 10),
            Text(
              '$_faceSection · ${controls.length}개 항목${wide ? '' : ' · 좌우로 선택'}',
              style: const TextStyle(color: _muted, fontSize: 10),
            ),
            const SizedBox(height: 6),
          ],
          if (_faceGroup && _faces.isEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                _faceMessage ?? '얼굴이 보이는 사진을 열면 사용할 수 있어요.',
                style: const TextStyle(
                  fontSize: 11,
                  color: _muted,
                  height: 1.7,
                ),
              ),
            ),
          if (wide)
            Wrap(
              spacing: 7,
              runSpacing: 9,
              children: controls
                  .asMap()
                  .entries
                  .map((e) => _controlChip(e.key, e.value))
                  .toList(),
            )
          else
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: controls
                    .asMap()
                    .entries
                    .map(
                      (e) => Padding(
                        padding: const EdgeInsets.only(right: 7),
                        child: _controlChip(e.key, e.value),
                      ),
                    )
                    .toList(),
              ),
            ),
          const SizedBox(height: 20),
          Row(
            children: [
              Text(
                selected.label,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              Text(
                '${selected.value(_settings) > 0 && selected.min < 0 ? '+' : ''}${(selected.value(_settings) * 100).round()}',
                style: const TextStyle(
                  color: _accent,
                  fontSize: 12,
                  fontFeatures: [ui.FontFeature.tabularFigures()],
                ),
              ),
              const SizedBox(width: 10),
              Tooltip(
                message: '${selected.label} 초기화',
                child: InkWell(
                  onTap: enabled
                      ? () => _changeSettings(
                          selected.update(_settings, 0),
                          record: true,
                        )
                      : null,
                  child: const Padding(
                    padding: EdgeInsets.all(3),
                    child: Icon(Icons.refresh_rounded, size: 17, color: _muted),
                  ),
                ),
              ),
            ],
          ),
          Slider(
            key: ValueKey('slider-$_group-$_faceSection-${selected.label}'),
            value: selected.value(_settings).clamp(selected.min, selected.max),
            min: selected.min,
            max: selected.max,
            divisions: _group == '리터치' ? (selected.min < 0 ? 200 : 100) : null,
            semanticFormatterCallback: (value) {
              final direction = value < 0
                  ? selected.negativeLabel
                  : selected.positiveLabel;
              return '${selected.label}, ${(value * 100).round()}${value == 0
                  ? ', 기본'
                  : direction == null
                  ? ''
                  : ', $direction'}';
            },
            onChangeStart: enabled ? _startSlider : null,
            onChanged: enabled
                ? (v) => _changeSettings(selected.update(_settings, v))
                : null,
            onChangeEnd: enabled ? _endSlider : null,
          ),
          if (selected.negativeLabel != null && selected.positiveLabel != null)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${selected.min < 0 ? '-100' : '0'} · ${selected.negativeLabel}',
                  style: const TextStyle(color: _muted, fontSize: 10),
                ),
                if (selected.min < 0)
                  const Text(
                    '기본 0',
                    style: TextStyle(color: _muted, fontSize: 10),
                  ),
                Text(
                  '${selected.positiveLabel} · +100',
                  style: const TextStyle(color: _muted, fontSize: 10),
                ),
              ],
            ),
          if (_isMakeupEditor) ...[
            const SizedBox(height: 16),
            _makeupPalette(selected.label),
          ],
          if (wide) ...[
            const SizedBox(height: 20),
            Text(
              _group == '조정'
                  ? '빛과 색을 천천히 맞춰 보세요. 작은 조절만으로도 사진의 분위기가 달라져요.'
                  : _isFaceEditor
                  ? '강도를 조금씩 높여 자연스러운 윤곽을 찾아보세요.'
                  : _retouchSection == '피부'
                  ? '확대해서 피부결을 확인하며 원하는 만큼만 다듬어 보세요.'
                  : '컬러가 원래 피부와 어우러지도록 강도를 조절해 보세요.',
              style: const TextStyle(color: _muted, fontSize: 11, height: 1.9),
            ),
          ],
        ],
      ),
    );
  }

  Widget _retouchSectionSelector() => Wrap(
    spacing: 6,
    runSpacing: 6,
    children: const ['자동', '얼굴보정', '피부', '볼륨·리프팅', '메이크업', '브러쉬'].map((
      section,
    ) {
      final selected = _retouchSection == section;
      return ChoiceChip(
        key: ValueKey('retouch-section-$section'),
        label: Text(section, style: const TextStyle(fontSize: 11)),
        selected: selected,
        showCheckmark: false,
        onSelected: _busy
            ? null
            : (_) => setState(() {
                _retouchSection = section;
                _control = 0;
                _brush = null;
                _stroke.clear();
              }),
        selectedColor: _accent.withValues(alpha: .18),
        backgroundColor: const Color(0xff191c21),
        labelStyle: TextStyle(color: selected ? _accent : Colors.white70),
        side: BorderSide(
          color: selected
              ? _accent.withValues(alpha: .6)
              : const Color(0xff42454d),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 4),
      );
    }).toList(),
  );

  Widget _automaticControls() {
    final enabled = !_busy && _faces.isNotEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          '내 취향의 자동 보정',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        Text(
          _faces.isEmpty
              ? (_faceMessage ?? '얼굴이 보이는 사진을 선택해 주세요.')
              : '피부와 메이크업을 함께 조절해요. 얼굴 형태는 그대로 유지해요.',
          style: const TextStyle(fontSize: 11, height: 1.8, color: _muted),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: retouchPresetLabels.entries
              .map(
                (preset) => ChoiceChip(
                  key: ValueKey('retouch-preset-${preset.key}'),
                  label: Text(
                    preset.value,
                    style: const TextStyle(fontSize: 11),
                  ),
                  selected: _autoPreset == preset.key,
                  onSelected: enabled
                      ? (_) {
                          // Capture both recipe selection and pixels before changing either.
                          final previous = _snapshot();
                          final intensity = _autoIntensity == 0
                              ? .5
                              : _autoIntensity;
                          final settings = applyRetouchPreset(
                            _settings,
                            preset.key,
                            intensity,
                          );
                          setState(() {
                            _remember(previous);
                            _autoPreset = preset.key;
                            _autoIntensity = intensity;
                            _settings = settings;
                          });
                          _queuePreview();
                        }
                      : null,
                  showCheckmark: false,
                  selectedColor: _accent.withValues(alpha: .2),
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            const Text('보정 강도', style: TextStyle(fontSize: 12)),
            const Spacer(),
            Text(
              '${(_autoIntensity * 100).round()}',
              style: const TextStyle(fontSize: 12, color: _accent),
            ),
          ],
        ),
        Slider(
          key: const ValueKey('automatic-intensity'),
          value: _autoIntensity,
          min: 0,
          max: 1,
          divisions: 100,
          onChangeStart: enabled ? _startSlider : null,
          onChanged: enabled
              ? (value) {
                  setState(() => _autoIntensity = value);
                  _changeSettings(
                    applyRetouchPreset(_settings, _autoPreset, value),
                  );
                }
              : null,
          onChangeEnd: enabled ? _endSlider : null,
          semanticFormatterCallback: (value) =>
              '자동 보정 강도 ${(value * 100).round()}',
        ),
        const Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('약하게', style: TextStyle(color: _muted, fontSize: 10)),
            Text('강하게', style: TextStyle(color: _muted, fontSize: 10)),
          ],
        ),
      ],
    );
  }

  Widget _makeupPalette(String control) {
    int? current;
    EditSettings Function(int)? change;
    if (control == '립 컬러') {
      current = _settings.lipstickColor;
      change = (color) => _settings.copyWith(
        lipstickColor: color,
        lipstick: _settings.lipstick == 0 ? .3 : _settings.lipstick,
      );
    } else if (control == '블러셔') {
      current = _settings.blushColor;
      change = (color) => _settings.copyWith(
        blushColor: color,
        blush: _settings.blush == 0 ? .3 : _settings.blush,
      );
    } else if (control == '아이섀도') {
      current = _settings.eyeshadowColor;
      change = (color) => _settings.copyWith(
        eyeshadowColor: color,
        eyeshadow: _settings.eyeshadow == 0 ? .3 : _settings.eyeshadow,
      );
    }
    if (current == null || change == null) return const SizedBox.shrink();
    final update = change;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('컬러 선택', style: TextStyle(color: _muted, fontSize: 11)),
        const SizedBox(height: 9),
        _colorPalette(
          current,
          (color) => _changeSettings(update(color), record: true),
          enabled: !_busy && _faces.isNotEmpty,
        ),
      ],
    );
  }

  Widget _colorPalette(
    int selected,
    ValueChanged<int> onSelected, {
    bool enabled = true,
  }) => Wrap(
    spacing: 10,
    runSpacing: 10,
    children:
        const <int>[
              0xffe84668,
              0xffee8492,
              0xffb75b64,
              0xffbd765b,
              0xff9c6a80,
              0xff715452,
              0xffe9b99a,
              0xfff5e1cc,
            ]
            .map(
              (color) => Semantics(
                button: true,
                selected: selected == color,
                label: '컬러 ${color.toRadixString(16).substring(2)}',
                child: InkWell(
                  onTap: enabled ? () => onSelected(color) : null,
                  borderRadius: BorderRadius.circular(24),
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: Color(color),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: selected == color
                            ? Colors.white
                            : Colors.white24,
                        width: selected == color ? 2 : 1,
                      ),
                    ),
                    child: selected == color
                        ? const Icon(Icons.check, size: 15, color: Colors.white)
                        : null,
                  ),
                ),
              ),
            )
            .toList(),
  );

  Widget _faceSectionSelector() => Wrap(
    spacing: 6,
    runSpacing: 6,
    children: const ['윤곽', '눈', '코', '입', '눈썹'].map((section) {
      final selected = _faceSection == section;
      return ChoiceChip(
        key: ValueKey('face-section-$section'),
        label: Text(section, style: const TextStyle(fontSize: 12)),
        selected: selected,
        showCheckmark: false,
        onSelected: _busy
            ? null
            : (_) => setState(() {
                _faceSection = section;
                _control = 0;
              }),
        selectedColor: _accent,
        backgroundColor: const Color(0xff191c21),
        labelStyle: TextStyle(
          color: selected ? _ink : Colors.white70,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
        ),
        side: BorderSide(color: selected ? _accent : const Color(0xff42454d)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      );
    }).toList(),
  );

  Widget _controlChip(int index, _Control control) {
    final selected = _control == index;
    return ChoiceChip(
      key: ValueKey('control-$_group-$_faceSection-${control.label}'),
      label: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(control.label, style: const TextStyle(fontSize: 11)),
          if (control.value(_settings) != 0) ...[
            const SizedBox(width: 5),
            Container(
              width: 4,
              height: 4,
              decoration: const BoxDecoration(
                color: _accent,
                shape: BoxShape.circle,
              ),
            ),
          ],
        ],
      ),
      selected: selected,
      showCheckmark: false,
      onSelected: _busy ? null : (_) => setState(() => _control = index),
      selectedColor: _accent.withValues(alpha: .15),
      labelStyle: TextStyle(color: selected ? _accent : _muted),
      backgroundColor: const Color(0xff2b2e35),
      side: BorderSide(
        color: selected ? _accent.withValues(alpha: .4) : Colors.transparent,
      ),
      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    );
  }

  Widget _filters(bool wide) {
    const filters = <(String, String, List<Color>)>[
      ('none', '원본', [Color(0xffaaa7a2), Color(0xff555762)]),
      ('natural', '내추럴', [Color(0xffd7c4a7), Color(0xff718475)]),
      ('cream', '크림', [Color(0xffead6bd), Color(0xffc1a18b)]),
      ('rose', '로즈', [Color(0xffdbb6bb), Color(0xffaa7f91)]),
      ('film', '필름', [Color(0xffc2b381), Color(0xff637571)]),
      ('mono', '흑백', [Color(0xffd2d3d4), Color(0xff363a41)]),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 15, 18, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            '사진의 분위기를 골라 보세요.',
            style: TextStyle(color: _muted, fontSize: 11),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 15,
            children: filters.map((f) {
              final selected = _settings.filter == f.$1;
              return Semantics(
                button: true,
                selected: selected,
                label: '${f.$2} 필터',
                child: InkWell(
                  onTap: _busy
                      ? null
                      : () => _changeSettings(
                          _settings.copyWith(filter: f.$1),
                          record: true,
                        ),
                  borderRadius: BorderRadius.circular(13),
                  child: SizedBox(
                    width: wide ? 88 : 66,
                    child: Column(
                      children: [
                        Container(
                          height: wide ? 76 : 58,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: selected ? _accent : Colors.transparent,
                              width: 2,
                            ),
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: f.$3,
                            ),
                          ),
                          child: Center(
                            child: Icon(
                              selected
                                  ? Icons.check_rounded
                                  : Icons.landscape_outlined,
                              color: selected
                                  ? Colors.white
                                  : Colors.white.withValues(alpha: .6),
                              size: 25,
                            ),
                          ),
                        ),
                        const SizedBox(height: 7),
                        Text(
                          f.$2,
                          style: TextStyle(
                            fontSize: 11,
                            color: selected ? _accent : _muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _tools(bool wide) => Padding(
    padding: const EdgeInsets.fromLTRB(18, 9, 18, 18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(
          spacing: 6,
          runSpacing: 4,
          children: [
            _toolButton(
              '90° 회전',
              Icons.rotate_right_rounded,
              () => _transformPhoto('rotate'),
            ),
            _toolButton(
              '좌우 반전',
              Icons.flip_rounded,
              () => _transformPhoto('flip'),
            ),
            _toolButton('가운데 자르기', Icons.crop_rounded, _cropDialog),
            _toolButton('참고 색감', Icons.color_lens_outlined, _referenceStyle),
          ],
        ),
        const SizedBox(height: 20),
        const Text(
          '수동 체형 보정',
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
        ),
        if (wide) ...[
          const SizedBox(height: 8),
          _bodySlider(
            '가운데 슬림',
            _settings.bodySlim,
            (v) => _settings.copyWith(bodySlim: v),
          ),
          _bodySlider(
            '아래쪽 길이',
            _settings.legLength,
            (v) => _settings.copyWith(legLength: v),
          ),
        ] else
          TextButton.icon(
            onPressed: _busy ? null : _bodyDialog,
            icon: const Icon(Icons.accessibility_new_rounded, size: 17),
            label: const Text('체형 조절 열기', style: TextStyle(fontSize: 11)),
            style: TextButton.styleFrom(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.zero,
            ),
          ),
        const SizedBox(height: 16),
        const Text(
          '인물과 배경',
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          runSpacing: 5,
          children: [
            _toolButton(
              '배경 지우기',
              Icons.content_cut_rounded,
              () => _segment('cutout'),
            ),
            _toolButton(
              '배경 흐림',
              Icons.portrait_rounded,
              () => _segment('blur'),
            ),
            _toolButton(
              '배경 컬러',
              Icons.format_color_fill_rounded,
              () => _segment('background'),
            ),
            _toolButton('헤어 컬러', Icons.face_rounded, () => _segment('hair')),
          ],
        ),
      ],
    ),
  );

  Widget _brushControls() {
    const tools = <(String, String, IconData)>[
      ('heal', '잡티 복구', Icons.healing_outlined),
      ('wrinkle', '주름 보정', Icons.gesture_rounded),
      ('smooth', '부분 피부결', Icons.water_drop_outlined),
      ('mosaic', '모자이크', Icons.grid_view_rounded),
      ('blur', '부분 흐림', Icons.blur_on_rounded),
      ('liquify', '밀어서 보정', Icons.touch_app_outlined),
      ('paint', '컬러 브러쉬', Icons.brush_outlined),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(
          spacing: 7,
          runSpacing: 7,
          children: tools
              .map(
                (tool) => FilterChip(
                  key: ValueKey('brush-${tool.$1}'),
                  selected: _brush == tool.$1,
                  label: Text(tool.$2, style: const TextStyle(fontSize: 11)),
                  avatar: Icon(tool.$3, size: 16),
                  showCheckmark: false,
                  onSelected: _busy
                      ? null
                      : (selected) {
                          setState(() {
                            _brush = selected ? tool.$1 : null;
                            _stroke.clear();
                          });
                        },
                  selectedColor: _accent.withValues(alpha: .18),
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 12),
        Text(
          _brush == null
              ? '도구를 고른 뒤 사진 위를 터치하거나 문질러 주세요.'
              : _brush == 'liquify'
              ? '사진 위에서 원하는 방향으로 천천히 밀어 주세요.'
              : _brush == 'wrinkle'
              ? '지우고 싶은 주름을 따라 짧게 문질러 주세요.'
              : '사진에서 다듬을 부분을 터치하거나 문질러 주세요.',
          style: const TextStyle(fontSize: 11, height: 1.8, color: _muted),
        ),
        const SizedBox(height: 5),
        const Text(
          '사진 위 확대 버튼으로 부위를 맞춰 보세요. 브러쉬를 해제하면 사진을 움직일 수 있어요.',
          style: TextStyle(fontSize: 10, height: 1.8, color: _muted),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            const SizedBox(
              width: 76,
              child: Text(
                '브러쉬 크기',
                style: TextStyle(color: _muted, fontSize: 11),
              ),
            ),
            Expanded(
              child: Slider(
                key: const ValueKey('brush-radius'),
                value: _brushRadius,
                min: .012,
                max: .12,
                onChanged: _busy
                    ? null
                    : (value) => setState(() => _brushRadius = value),
              ),
            ),
            SizedBox(
              width: 30,
              child: Text(
                '${(_brushRadius * 1000).round()}',
                style: const TextStyle(fontSize: 11),
              ),
            ),
          ],
        ),
        Row(
          children: [
            const SizedBox(
              width: 76,
              child: Text(
                '보정 강도',
                style: TextStyle(color: _muted, fontSize: 11),
              ),
            ),
            Expanded(
              child: Slider(
                key: const ValueKey('brush-strength'),
                value: _brushStrength,
                min: .1,
                max: 1,
                onChanged: _busy
                    ? null
                    : (value) => setState(() => _brushStrength = value),
              ),
            ),
            SizedBox(
              width: 30,
              child: Text(
                '${(_brushStrength * 100).round()}',
                style: const TextStyle(fontSize: 11),
              ),
            ),
          ],
        ),
        if (_brush == 'paint') ...[
          const SizedBox(height: 10),
          const Text('브러쉬 컬러', style: TextStyle(color: _muted, fontSize: 11)),
          const SizedBox(height: 9),
          _colorPalette(
            _brushColor,
            (color) => setState(() => _brushColor = color),
            enabled: !_busy,
          ),
        ],
      ],
    );
  }

  Widget _bodySlider(
    String label,
    double value,
    EditSettings Function(double) update,
  ) => Row(
    children: [
      SizedBox(
        width: 80,
        child: Text(label, style: const TextStyle(color: _muted, fontSize: 10)),
      ),
      Expanded(
        child: Slider(
          value: value.clamp(0, 1),
          onChangeStart: _busy ? null : _startSlider,
          onChanged: _busy ? null : (v) => _changeSettings(update(v)),
          onChangeEnd: _busy ? null : _endSlider,
        ),
      ),
    ],
  );

  Future<void> _bodyDialog() async {
    final previous = _snapshot();
    final result = await showModalBottomSheet<(double, double)>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        double body = _settings.bodySlim, leg = _settings.legLength;
        return StatefulBuilder(
          builder: (context, update) => SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    '수동 체형 보정',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 9),
                  const Text(
                    '사진 가운데와 아래쪽을 조절해요. 배경과 인물 윤곽을 함께 확인해 주세요.',
                    style: TextStyle(color: _muted, fontSize: 12, height: 1.8),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    '가운데 슬림  ${(body * 100).round()}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  Slider(value: body, onChanged: (v) => update(() => body = v)),
                  Text(
                    '아래쪽 길이  ${(leg * 100).round()}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  Slider(value: leg, onChanged: (v) => update(() => leg = v)),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () => Navigator.pop(context, (body, leg)),
                    child: const Text('적용'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
    if (result != null && mounted) {
      setState(() {
        _remember(previous);
        _settings = _settings.copyWith(
          bodySlim: result.$1,
          legLength: result.$2,
        );
      });
      _queuePreview(immediate: true);
    }
  }

  Widget _toolButton(String label, IconData icon, VoidCallback action) =>
      TextButton.icon(
        onPressed: _busy ? null : action,
        icon: Icon(icon, size: 17),
        label: Text(label, style: const TextStyle(fontSize: 10)),
        style: TextButton.styleFrom(
          foregroundColor: Colors.white70,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
        ),
      );

  Future<void> _cropDialog() async {
    final ratio = await showDialog<double>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('가운데 자르기'),
        children:
            <(String, double)>[
                  ('정사각형  1:1', 1),
                  ('인물 사진  3:4', 3 / 4),
                  ('피드 사진  4:5', 4 / 5),
                  ('세로 화면  9:16', 9 / 16),
                  ('가로 사진  4:3', 4 / 3),
                  ('와이드  16:9', 16 / 9),
                ]
                .map(
                  (item) => SimpleDialogOption(
                    onPressed: () => Navigator.pop(context, item.$2),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      child: Text(item.$1),
                    ),
                  ),
                )
                .toList(),
      ),
    );
    if (ratio != null) await _transformPhoto('crop', ratio: ratio);
  }

  Widget _decorationTools() => Padding(
    padding: const EdgeInsets.all(20),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          '사진에 이야기를 더해 보세요.',
          style: TextStyle(color: _muted, fontSize: 11),
        ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: _busy ? null : _addText,
          icon: const Icon(Icons.text_fields_rounded, size: 20),
          label: const Text('글자 넣기'),
        ),
        const SizedBox(height: 9),
        OutlinedButton.icon(
          onPressed: _busy ? null : _collage,
          icon: const Icon(Icons.dashboard_outlined, size: 20),
          label: const Text('2~4장 콜라주 만들기'),
        ),
      ],
    ),
  );

  Widget _tag(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: Colors.black54,
      borderRadius: BorderRadius.circular(8),
    ),
    child: Text(text, style: const TextStyle(fontSize: 10)),
  );
  Widget _loadingPill(String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
    decoration: BoxDecoration(
      color: _panel,
      borderRadius: BorderRadius.circular(16),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(
          width: 17,
          height: 17,
          child: CircularProgressIndicator(strokeWidth: 2, color: _accent),
        ),
        const SizedBox(width: 12),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    ),
  );
}

class UndoIntent extends Intent {
  const UndoIntent();
}

class RedoIntent extends Intent {
  const RedoIntent();
}

class SaveIntent extends Intent {
  const SaveIntent();
}

class _WelcomeNote extends StatelessWidget {
  const _WelcomeNote(this.icon, this.label);
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Icon(icon, size: 15, color: _accent.withValues(alpha: .8)),
      const SizedBox(width: 6),
      Text(label, style: const TextStyle(fontSize: 10, color: _muted)),
    ],
  );
}

class _StrokePainter extends CustomPainter {
  _StrokePainter(this.points, this.rect, this.radius, this.transform);
  final List<FacePoint> points;
  final Rect rect;
  final double radius;
  final Matrix4 transform;
  @override
  void paint(Canvas canvas, Size size) {
    if (points.isEmpty) return;
    canvas.save();
    canvas.transform(transform.storage);
    canvas.clipRect(rect);
    final paint = Paint()
      ..color = _accent.withValues(alpha: .4)
      ..strokeWidth = radius * math.min(rect.width, rect.height) * 2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    final path = Path()
      ..moveTo(
        rect.left + points.first.x * rect.width,
        rect.top + points.first.y * rect.height,
      );
    if (points.length == 1) {
      canvas.drawCircle(
        Offset(
          rect.left + points.first.x * rect.width,
          rect.top + points.first.y * rect.height,
        ),
        paint.strokeWidth / 2,
        paint..style = PaintingStyle.fill,
      );
    } else {
      for (final p in points.skip(1)) {
        path.lineTo(rect.left + p.x * rect.width, rect.top + p.y * rect.height);
      }
      canvas.drawPath(path, paint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _StrokePainter oldDelegate) => true;
}
