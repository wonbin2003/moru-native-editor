import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

/// Reinhard-style colour transfer in perceptual CIELAB, with conservative
/// variance limits. The source geometry and high-frequency texture stay intact.
Future<Uint8List> matchReferenceStyle(Uint8List source, Uint8List reference,
    {double strength = .65}) => compute(_transfer, (source, reference, strength));

Uint8List _transfer((Uint8List, Uint8List, double) request) {
  final src = img.decodeImage(request.$1);
  final ref = img.decodeImage(request.$2);
  if (src == null || ref == null) {
    throw const FormatException('색감을 비교할 사진을 읽지 못했습니다.');
  }
  final original = img.bakeOrientation(src).convert(numChannels: 4);
  final target = img.bakeOrientation(ref);
  final amount = request.$3.clamp(0.0, 1.0);
  final a = _stats(original), b = _stats(target);
  final scales = List<double>.generate(3,
    (i) => (b[i + 3] / math.max(a[i + 3], 1)).clamp(.65, 1.45));
  for (final p in original) {
    if (p.a < 16) continue;
    final lab = _toLab(p.r.toDouble(), p.g.toDouble(), p.b.toDouble());
    final edited = List<double>.generate(3,
      (i) => lab[i] + (((lab[i] - a[i]) * scales[i] + b[i]) - lab[i]) * amount);
    final rgb = _fromLab(edited[0], edited[1], edited[2]);
    p..r = rgb[0]..g = rgb[1]..b = rgb[2];
  }
  return img.encodePng(original, level: 3);
}

List<double> _stats(img.Image source) {
  // Sample at most about 65k points; never downsample the exported photograph.
  final stride = math.max(1, math.sqrt(source.width * source.height / 65536).ceil());
  final sum = List<double>.filled(3, 0), sq = List<double>.filled(3, 0);
  var n = 0;
  for (var y = 0; y < source.height; y += stride) {
    for (var x = 0; x < source.width; x += stride) {
      final p = source.getPixel(x, y);
      if (p.a < 16) continue;
      final lab = _toLab(p.r.toDouble(), p.g.toDouble(), p.b.toDouble());
      for (var c = 0; c < 3; c++) { sum[c] += lab[c]; sq[c] += lab[c] * lab[c]; }
      n++;
    }
  }
  if (n == 0) throw const FormatException('투명한 사진에서는 색감을 추출할 수 없습니다.');
  final mean = sum.map((s) => s / n).toList();
  return [...mean, for (var c = 0; c < 3; c++) math.sqrt(math.max(0, sq[c] / n - mean[c] * mean[c]))];
}

double _linear(double c) => c <= .04045 ? c / 12.92 : math.pow((c + .055) / 1.055, 2.4).toDouble();
double _curve(double c) => c <= .0031308 ? 12.92 * c : 1.055 * math.pow(c, 1 / 2.4) - .055;
double _f(double c) => c > .008856451679 ? math.pow(c, 1 / 3).toDouble() : 7.787037037 * c + 16 / 116;
double _fi(double c) => c > 6 / 29 ? c * c * c : (c - 16 / 116) / 7.787037037;
List<double> _toLab(double r, double g, double b) {
  r = _linear(r / 255); g = _linear(g / 255); b = _linear(b / 255);
  final x = _f((.4124564 * r + .3575761 * g + .1804375 * b) / .95047);
  final y = _f(.2126729 * r + .7151522 * g + .0721750 * b);
  final z = _f((.0193339 * r + .1191920 * g + .9503041 * b) / 1.08883);
  return [116 * y - 16, 500 * (x - y), 200 * (y - z)];
}
List<int> _fromLab(double l, double a, double b) {
  final fy = (l + 16) / 116;
  final x = .95047 * _fi(fy + a / 500), y = _fi(fy), z = 1.08883 * _fi(fy - b / 200);
  return [3.2404542*x-1.5371385*y-.4985314*z, -.969266*x+1.8760108*y+.041556*z, .0556434*x-.2040259*y+1.0572252*z]
    .map((v) => (_curve(v.clamp(0.0, 1.0)) * 255).round().clamp(0, 255)).toList();
}
