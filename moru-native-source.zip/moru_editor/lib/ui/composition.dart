import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

class TextDecorationOptions {
  const TextDecorationOptions({
    required this.text,
    required this.color,
    required this.size,
    required this.position,
  });
  final String text;
  final Color color;
  final double size;
  final double position;
}

Future<ui.Image> _decode(Uint8List bytes) async {
  final codec = await ui.instantiateImageCodec(bytes);
  try {
    return (await codec.getNextFrame()).image;
  } finally {
    codec.dispose();
  }
}

Future<Uint8List> addTextToPhoto(
  Uint8List bytes,
  TextDecorationOptions options,
) async {
  final image = await _decode(bytes);
  final recorder = ui.PictureRecorder();
  final canvas = Canvas(recorder)..drawImage(image, Offset.zero, Paint());
  final text = TextPainter(
    text: TextSpan(
      text: options.text,
      style: TextStyle(
        color: options.color,
        fontFamily: 'NotoSansKR',
        fontWeight: FontWeight.w600,
        fontSize: image.width * options.size,
        height: 1.45,
        shadows: [
          Shadow(
            color: Colors.black.withValues(alpha: .5),
            blurRadius: image.width * .005,
            offset: Offset(0, image.width * .0015),
          ),
        ],
      ),
    ),
    textDirection: TextDirection.ltr,
    textAlign: TextAlign.center,
    maxLines: 8,
    ellipsis: '…',
  )..layout(maxWidth: image.width * .86);
  final x = (image.width - text.width) / 2;
  final y = (image.height * options.position - text.height / 2).clamp(
    image.height * .04,
    math.max(image.height * .04, image.height * .96 - text.height),
  );
  text.paint(canvas, Offset(x, y.toDouble()));
  final picture = recorder.endRecording();
  final output = await picture.toImage(image.width, image.height);
  try {
    final data = await output.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw StateError('Image encoding failed');
    return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
  } finally {
    text.dispose();
    image.dispose();
    output.dispose();
    picture.dispose();
  }
}

Future<Uint8List> makeCollage(List<Uint8List> bytes) async {
  if (bytes.length < 2 || bytes.length > 4) {
    throw ArgumentError('Select 2 to 4 images');
  }
  final images = <ui.Image>[];
  try {
    for (final input in bytes) {
      images.add(await _decode(input));
    }
    const width = 2400;
    final height = images.length == 2 ? 1600 : 2400;
    const gap = 36.0;
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder)
      ..drawColor(const Color(0xfff4eee8), BlendMode.src);
    final cells = <Rect>[];
    if (images.length == 2) {
      final cellWidth = (width - gap * 3) / 2;
      cells.add(Rect.fromLTWH(gap, gap, cellWidth, height - gap * 2));
      cells.add(
        Rect.fromLTWH(gap * 2 + cellWidth, gap, cellWidth, height - gap * 2),
      );
    } else if (images.length == 3) {
      final topHeight = (height - gap * 3) * .55;
      cells.add(Rect.fromLTWH(gap, gap, width - gap * 2, topHeight));
      final cellWidth = (width - gap * 3) / 2;
      final bottomHeight = height - gap * 3 - topHeight;
      cells.add(
        Rect.fromLTWH(gap, gap * 2 + topHeight, cellWidth, bottomHeight),
      );
      cells.add(
        Rect.fromLTWH(
          gap * 2 + cellWidth,
          gap * 2 + topHeight,
          cellWidth,
          bottomHeight,
        ),
      );
    } else {
      final cellWidth = (width - gap * 3) / 2,
          cellHeight = (height - gap * 3) / 2;
      for (var y = 0; y < 2; y++) {
        for (var x = 0; x < 2; x++) {
          cells.add(
            Rect.fromLTWH(
              gap + x * (cellWidth + gap),
              gap + y * (cellHeight + gap),
              cellWidth,
              cellHeight,
            ),
          );
        }
      }
    }
    for (var i = 0; i < images.length; i++) {
      final image = images[i], cell = cells[i];
      final fit = applyBoxFit(
        BoxFit.cover,
        Size(image.width.toDouble(), image.height.toDouble()),
        cell.size,
      );
      final source = Alignment.center.inscribe(
        fit.source,
        Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      );
      canvas.drawImageRect(
        image,
        source,
        cell,
        Paint()..filterQuality = FilterQuality.high,
      );
    }
    final picture = recorder.endRecording();
    final output = await picture.toImage(width, height);
    try {
      final data = await output.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw StateError('Image encoding failed');
      return data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    } finally {
      output.dispose();
      picture.dispose();
    }
  } finally {
    for (final image in images) {
      image.dispose();
    }
  }
}

class PhotoTextDialog extends StatefulWidget {
  const PhotoTextDialog({super.key});
  @override
  State<PhotoTextDialog> createState() => _PhotoTextDialogState();
}

class _PhotoTextDialogState extends State<PhotoTextDialog> {
  final _controller = TextEditingController();
  Color _color = Colors.white;
  double _size = .05, _position = .82;
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('글자 넣기'),
    content: SizedBox(
      width: 340,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _controller,
              autofocus: true,
              maxLines: 4,
              maxLength: 160,
              decoration: const InputDecoration(
                hintText: '사진에 남기고 싶은 말',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            Wrap(
              spacing: 10,
              children:
                  [
                        Colors.white,
                        const Color(0xff242329),
                        const Color(0xffffc7b4),
                        const Color(0xfff7da85),
                        const Color(0xffa5c9bf),
                      ]
                      .map(
                        (color) => InkWell(
                          onTap: () => setState(() => _color = color),
                          child: Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              color: color,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: _color == color
                                    ? Theme.of(context).colorScheme.primary
                                    : Colors.white24,
                                width: _color == color ? 3 : 1,
                              ),
                            ),
                            child: _color == color
                                ? Icon(
                                    Icons.check,
                                    size: 16,
                                    color: color == const Color(0xff242329)
                                        ? Colors.white
                                        : Colors.black54,
                                  )
                                : null,
                          ),
                        ),
                      )
                      .toList(),
            ),
            const SizedBox(height: 19),
            const Text('글자 크기', style: TextStyle(fontSize: 12)),
            Slider(
              value: _size,
              min: .025,
              max: .12,
              onChanged: (v) => setState(() => _size = v),
            ),
            Wrap(
              spacing: 8,
              children: <(String, double)>[('위', .18), ('가운데', .5), ('아래', .82)]
                  .map(
                    (item) => ChoiceChip(
                      label: Text(item.$1),
                      selected: _position == item.$2,
                      onSelected: (_) => setState(() => _position = item.$2),
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('취소'),
      ),
      FilledButton(
        onPressed: () {
          final text = _controller.text.trim();
          if (text.isEmpty) return;
          Navigator.pop(
            context,
            TextDecorationOptions(
              text: text,
              color: _color,
              size: _size,
              position: _position,
            ),
          );
        },
        child: const Text('넣기'),
      ),
    ],
  );
}
