import 'dart:math' as math;
import 'dart:typed_data';

import 'package:image/image.dart' as im;
import 'editor_models.dart';

double _u(double v) => v.isFinite ? v.clamp(0.0, 1.0) : 0;
double _lum(num r, num g, num b) => .2126 * r + .7152 * g + .0722 * b;
double _smooth(double lo, double hi, double v) {
  final t = ((v - lo) / (hi - lo)).clamp(0.0, 1.0);
  return t * t * (3 - 2 * t);
}

int _byte(double v) => v.clamp(0.0, 255.0).round();

const _oval = [
  10,
  338,
  297,
  332,
  284,
  251,
  389,
  356,
  454,
  323,
  361,
  288,
  397,
  365,
  379,
  378,
  400,
  377,
  152,
  148,
  176,
  149,
  150,
  136,
  172,
  58,
  132,
  93,
  234,
  127,
  162,
  21,
  54,
  103,
  67,
  109,
];
const _leftEye = [33, 160, 158, 133, 153, 144];
const _rightEye = [263, 387, 385, 362, 380, 373];
const _leftUpper = [33, 246, 161, 160, 159, 158, 157, 173, 133];
const _rightUpper = [263, 466, 388, 387, 386, 385, 384, 398, 362];
const _leftBrow = [70, 63, 105, 66, 107, 55, 65, 52, 53, 46];
const _rightBrow = [336, 296, 334, 293, 300, 276, 283, 282, 295, 285];
const _outerLip = [
  61,
  185,
  40,
  39,
  37,
  0,
  267,
  269,
  270,
  409,
  291,
  375,
  321,
  405,
  314,
  17,
  84,
  181,
  91,
  146,
];
const _innerLip = [
  78,
  191,
  80,
  81,
  82,
  13,
  312,
  311,
  310,
  415,
  308,
  324,
  318,
  402,
  317,
  14,
  87,
  178,
  88,
  95,
];

/// Scale-aware grayscale closing repairs narrow dark creases. It raises only
/// negative detail, keeps colour/alpha, and attenuates strong structural edges.
/// The caller limits the result to skin or a user-drawn brush mask.
im.Image repairFineWrinkles(
  im.Image src, {
  double strength = 1,
  double radiusFraction = .006,
}) {
  final amount = _u(strength);
  if (amount == 0) return src;
  final scale = math.min(1.0, 1024 / math.max(src.width, src.height));
  final work = scale < 1
      ? im.copyResize(
          src,
          width: math.max(1, (src.width * scale).round()),
          height: math.max(1, (src.height * scale).round()),
          interpolation: im.Interpolation.linear,
        )
      : src;
  final w = work.width, h = work.height;
  final values = Float32List(w * h);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final p = work.getPixel(x, y);
      values[y * w + x] = _lum(p.r, p.g, p.b);
    }
  }
  final radius = (math.min(w, h) * radiusFraction).round().clamp(2, 12);
  final closed = _extrema(
    _extrema(values, w, h, radius, true),
    w,
    h,
    radius,
    false,
  );
  final softened = im.gaussianBlur(
    im.Image.from(work),
    radius: math.max(2, radius),
  );
  final lift = Float32List(w * h);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final i = y * w + x, l = values[i], q = softened.getPixel(x, y);
      final negativeDetail = _lum(q.r, q.g, q.b) - l;
      final gradient = math.max(
        (values[y * w + (x - 1).clamp(0, w - 1)] -
                values[y * w + (x + 1).clamp(0, w - 1)])
            .abs(),
        (values[(y - 1).clamp(0, h - 1) * w + x] -
                values[(y + 1).clamp(0, h - 1) * w + x])
            .abs(),
      );
      final confidence =
          _smooth(.5, 4, negativeDetail) *
          (1 - _smooth(42, 90, gradient)) *
          _smooth(10, 45, l);
      lift[i] = (closed[i] - l).clamp(0.0, 32.0) * confidence * amount * .85;
    }
  }
  final out = im.Image.from(src);
  for (var y = 0; y < src.height; y++) {
    for (var x = 0; x < src.width; x++) {
      final delta = _sample(
        lift,
        w,
        h,
        (x + .5) * w / src.width - .5,
        (y + .5) * h / src.height - .5,
      );
      if (delta < .05) continue;
      final p = src.getPixel(x, y);
      out.setPixelRgba(
        x,
        y,
        _byte(p.r + delta),
        _byte(p.g + delta),
        _byte(p.b + delta),
        p.a,
      );
    }
  }
  return out;
}

Float32List _extrema(Float32List src, int w, int h, int radius, bool maximum) {
  final tmp = Float32List(src.length), out = Float32List(src.length);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      var v = maximum ? -double.infinity : double.infinity;
      for (var d = -radius; d <= radius; d++) {
        final p = src[y * w + (x + d).clamp(0, w - 1)];
        v = maximum ? math.max(v, p) : math.min(v, p);
      }
      tmp[y * w + x] = v;
    }
  }
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      var v = maximum ? -double.infinity : double.infinity;
      for (var d = -radius; d <= radius; d++) {
        final p = tmp[(y + d).clamp(0, h - 1) * w + x];
        v = maximum ? math.max(v, p) : math.min(v, p);
      }
      out[y * w + x] = v;
    }
  }
  return out;
}

/// Additional retouch passes operate in each detected face's own bounded ROI.
/// Shadows are corrected separately from skin smoothing; no new skin is invented.
im.Image applyRetouchPixels(
  im.Image src,
  EditSettings s,
  List<FaceGeometry> faces,
) {
  if (!s.hasRetouchPixels || faces.isEmpty) return src;
  final out = im.Image.from(src);
  for (final face in faces.where((f) => f.isValid)) {
    final full = face.points
        .map((p) => FacePoint(p.x * src.width, p.y * src.height))
        .toList();
    final outline = _oval.map((i) => full[i]).toList();
    final minX = outline.map((p) => p.x).reduce(math.min),
        maxX = outline.map((p) => p.x).reduce(math.max);
    final minY = outline.map((p) => p.y).reduce(math.min),
        maxY = outline.map((p) => p.y).reduce(math.max);
    final fw = _distance(full[234], full[454]);
    final fh = _distance(full[10], full[152]);
    if (fw < 4 || fh < 4) continue;
    final x0 = (minX - fw * .08).floor().clamp(0, src.width - 1),
        y0 = (minY - fh * .04).floor().clamp(0, src.height - 1);
    final x1 = (maxX + fw * .08).ceil().clamp(x0 + 1, src.width),
        y1 = (maxY + fh * .04).ceil().clamp(y0 + 1, src.height);
    final crop = im.copyCrop(
      src,
      x: x0,
      y: y0,
      width: x1 - x0,
      height: y1 - y0,
    );
    final scale = math.min(1.0, 640 / math.max(crop.width, crop.height));
    final work = scale < 1
        ? im.copyResize(
            crop,
            width: math.max(1, (crop.width * scale).round()),
            height: math.max(1, (crop.height * scale).round()),
          )
        : crop;
    final w = work.width, h = work.height;
    final sx = w / crop.width, sy = h / crop.height;
    final p = full
        .map((p) => FacePoint((p.x - x0) * sx, (p.y - y0) * sy))
        .toList();
    final skin = Float32List(w * h),
        lips = Float32List(w * h),
        brows = Float32List(w * h),
        shadow = Float32List(w * h),
        liner = Float32List(w * h);
    List<FacePoint> poly(List<int> ids) => ids.map((i) => p[i]).toList();
    _fill(skin, w, h, poly(_oval), 1);
    for (final ids in [_leftEye, _rightEye, _leftBrow, _rightBrow, _outerLip]) {
      _fill(skin, w, h, _expand(poly(ids), 1.18), 0);
    }
    // Nostrils are structure, not skin blemishes or wrinkles.
    for (final i in [98, 327]) {
      _ellipse(skin, w, h, p[i], fw * sx * .045, fh * sy * .024, 0);
    }
    _fill(lips, w, h, poly(_outerLip), 1);
    _fill(lips, w, h, poly(_innerLip), 0);
    _fill(brows, w, h, poly(_leftBrow), 1);
    _fill(brows, w, h, poly(_rightBrow), 1);
    final eyeDX = (p[263].x + p[362].x - p[33].x - p[133].x) / 2;
    final eyeDY = (p[263].y + p[362].y - p[33].y - p[133].y) / 2;
    final eyeD = math.sqrt(eyeDX * eyeDX + eyeDY * eyeDY);
    if (eyeD < 1) continue;
    final ux = eyeDX / eyeD, uy = eyeDY / eyeD;
    for (final ids in [_leftUpper, _rightUpper]) {
      final upper = poly(ids);
      final ew = _distance(upper.first, upper.last);
      final top = upper.reversed.map(
        (q) => FacePoint(q.x + uy * ew * .26, q.y - ux * ew * .26),
      );
      _fill(shadow, w, h, [...upper, ...top], 1);
      _pathMask(liner, w, h, upper, math.max(.65, ew * .025));
    }
    final feather = math.max(1, (fw * sx * .012).round());
    final sm = _feather(skin, w, h, feather),
        lm = _feather(lips, w, h, math.max(1, feather ~/ 2));
    final bm = _feather(brows, w, h, math.max(1, feather ~/ 2)),
        em = _feather(shadow, w, h, feather);
    final low = im.gaussianBlur(
      im.Image.from(work),
      radius: math.max(1, (fw * sx * .025).round()),
    );
    final medium = s.nasolabialFoldRemove > 0
        ? im.gaussianBlur(
            im.Image.from(work),
            radius: math.max(1, (fw * sx * .009).round()),
          )
        : null;
    final repaired = s.wrinkleRemove > 0
        ? repairFineWrinkles(work, radiusFraction: .013)
        : null;
    final folds = Float32List(w * h), foldRef = Float32List(w * h);
    if (s.nasolabialFoldRemove > 0) {
      // Outer mid-cheek points follow the nasolabial groove. Inner nostril
      // points sit too medially for a deep smile-line fold.
      for (final spec in [
        ([203, 206, 216, 214], -1.0),
        ([423, 426, 436, 434], 1.0),
      ]) {
        final anchors = spec.$1.map((i) => p[i]).toList();
        final side = spec.$2;
        final curve = <FacePoint>[];
        for (var segment = 1; segment < anchors.length; segment++) {
          final a = anchors[segment - 1], b = anchors[segment];
          for (var step = 0; step <= 8; step++) {
            final t = step / 8;
            final expected = FacePoint(
              a.x + (b.x - a.x) * t,
              a.y + (b.y - a.y) * t,
            );
            var center = expected, best = -double.infinity;
            final search = fw * sx * .028;
            for (var k = -4; k <= 4; k++) {
              final offset = k * search / 4;
              final candidate = FacePoint(
                expected.x + ux * offset,
                expected.y + uy * offset,
              );
              if (_sample(sm, w, h, candidate.x, candidate.y) < .7) continue;
              final c = _colorAt(medium!, candidate.x, candidate.y);
              final flank = _colorAt(
                low,
                candidate.x + ux * side * fw * sx * .065,
                candidate.y + uy * side * fw * sx * .065,
              );
              final score =
                  _lum(flank.r, flank.g, flank.b) -
                  _lum(c.r, c.g, c.b) -
                  3 * (k / 4) * (k / 4);
              if (score > best) {
                best = score;
                center = candidate;
              }
            }
            curve.add(center);
          }
        }
        final smoothCurve = List<FacePoint>.generate(curve.length, (i) {
          if (i == 0 || i == curve.length - 1) return curve[i];
          return FacePoint(
            (curve[i - 1].x + 2 * curve[i].x + curve[i + 1].x) / 4,
            (curve[i - 1].y + 2 * curve[i].y + curve[i + 1].y) / 4,
          );
        });
        final mask = Float32List(w * h);
        final corridorRadius = math.max(1.6, fw * sx * .045);
        _pathMask(mask, w, h, smoothCurve, corridorRadius);
        for (var y = 0; y < h; y++) {
          for (var x = 0; x < w; x++) {
            final i = y * w + x;
            if (mask[i] <= folds[i]) continue;
            final samples = <double>[];
            var refConfidence = 0.0;
            for (final distance in [.05, .065, .08]) {
              final refX = x + ux * side * fw * sx * distance,
                  refY = y + uy * side * fw * sx * distance;
              final confidence = _smooth(
                .6,
                .95,
                _sample(sm, w, h, refX, refY),
              );
              if (confidence < .2) continue;
              final q = _colorAt(low, refX, refY);
              samples.add(_lum(q.r, q.g, q.b));
              refConfidence += confidence;
            }
            if (samples.isEmpty) continue;
            samples.sort();
            final endpointFade = math.min(
              _smooth(
                0,
                corridorRadius,
                _distance(
                  FacePoint(x.toDouble(), y.toDouble()),
                  smoothCurve.first,
                ),
              ),
              _smooth(
                0,
                corridorRadius,
                _distance(
                  FacePoint(x.toDouble(), y.toDouble()),
                  smoothCurve.last,
                ),
              ),
            );
            folds[i] =
                mask[i] * (refConfidence / samples.length) * endpointFade;
            foldRef[i] = samples[samples.length ~/ 2];
          }
        }
      }
    }
    for (var yy = 0; yy < crop.height; yy++) {
      for (var xx = 0; xx < crop.width; xx++) {
        final mx = (xx + .5) * sx - .5, my = (yy + .5) * sy - .5;
        final skinA = _smooth(.5, .98, _sample(sm, w, h, mx, my));
        final lipA = _sample(lm, w, h, mx, my),
            browA = _sample(bm, w, h, mx, my),
            eyeA = _sample(em, w, h, mx, my),
            lineA = _sample(liner, w, h, mx, my);
        if (skinA + lipA + browA + eyeA + lineA < .001) continue;
        final original = src.getPixel(x0 + xx, y0 + yy);
        var r = original.r.toDouble(),
            g = original.g.toDouble(),
            b = original.b.toDouble();
        final l = _lum(r, g, b);
        final q = _colorAt(low, mx, my), baseL = _lum(q.r, q.g, q.b);
        if (skinA > 0) {
          final confidence = _smooth(8, 40, l) * (1 - _smooth(245, 255, l));
          final edge = (l - baseL).abs();
          if (s.blemishRemoval > 0) {
            final darkSpot = _smooth(3, 14, baseL - l);
            final redSpot = _smooth(4, 18, (r - g) - (q.r - q.g));
            final a =
                skinA *
                confidence *
                _u(s.blemishRemoval) *
                .7 *
                math.max(darkSpot, redSpot) *
                (1 - _smooth(38, 75, edge));
            r += (q.r - r) * a;
            g += (q.g - g) * a;
            b += (q.b - b) * a;
          }
          if (repaired != null) {
            final target = _colorAt(repaired, mx, my);
            final crease = (_lum(target.r, target.g, target.b) - l).clamp(
              0.0,
              32.0,
            );
            final delta = crease * _u(s.wrinkleRemove) * skinA;
            r += delta;
            g += delta;
            b += delta;
          }
          if (s.nasolabialFoldRemove > 0) {
            final mask = _sample(folds, w, h, mx, my) * skinA;
            final reference = _sample(foldRef, w, h, mx, my);
            final mid = _colorAt(medium!, mx, my),
                midL = _lum(mid.r, mid.g, mid.b);
            // Lift the low-frequency groove while retaining the original skin
            // texture. Only a bounded dark fine-line component is attenuated.
            final negative =
                (reference - midL).clamp(0.0, 52.0) +
                (midL - l).clamp(0.0, 18.0) * .4;
            final delta =
                negative *
                _smooth(1, 7, reference - midL) *
                mask *
                _u(s.nasolabialFoldRemove) *
                .95;
            r += delta;
            g += delta;
            b += delta;
          }
          if (s.rednessReduce > 0) {
            final excess = (r - (g + b) / 2).clamp(0.0, 60.0);
            final a =
                skinA * _u(s.rednessReduce) * .42 * _smooth(7, 30, excess);
            r -= excess * a;
            g += excess * a * .25;
            b += excess * a * .12;
          }
          if (s.skinTexture > 0) {
            final detail =
                (l - baseL).clamp(-8.0, 8.0) * skinA * _u(s.skinTexture) * .3;
            r += detail;
            g += detail;
            b += detail;
          }
          if (s.darkCircleReduce > 0) {
            var under = 0.0;
            for (final pair in [(33, 133), (263, 362)]) {
              final ea = p[pair.$1], eb = p[pair.$2], ew = _distance(ea, eb);
              final cx = (ea.x + eb.x) / 2 - uy * ew * .22,
                  cy = (ea.y + eb.y) / 2 + ux * ew * .22;
              final dx = (mx - cx) * ux + (my - cy) * uy,
                  dy = -(mx - cx) * uy + (my - cy) * ux;
              final d =
                  dx * dx / (ew * .62 * ew * .62) +
                  dy * dy / (ew * .24 * ew * .24);
              if (d < 1) under = math.max(under, (1 - d) * (1 - d));
            }
            final delta =
                under *
                skinA *
                _u(s.darkCircleReduce) *
                (7 + (baseL - l).clamp(0.0, 16.0)) *
                (1 - _smooth(200, 250, l));
            r += delta;
            g += delta;
            b += delta * .8;
          }
        }
        if (s.eyeshadow > 0 && eyeA > 0) {
          final color = s.eyeshadowColor, a = eyeA * _u(s.eyeshadow) * .42;
          final cr = ((color >> 16) & 255).toDouble(),
              cg = ((color >> 8) & 255).toDouble(),
              cb = (color & 255).toDouble();
          final cl = math.max(20.0, _lum(cr, cg, cb));
          r += (l * cr / cl - r) * a;
          g += (l * cg / cl - g) * a;
          b += (l * cb / cl - b) * a;
        }
        if (s.eyeliner > 0 && lineA > 0) {
          final a = lineA * _u(s.eyeliner) * .65;
          r *= 1 - a;
          g *= 1 - a;
          b *= 1 - a;
        }
        if (s.browFill > 0 && browA > 0) {
          final a = browA * _u(s.browFill) * .55;
          r += (l * .55 + 8 - r) * a;
          g += (l * .45 + 5 - g) * a;
          b += (l * .4 + 4 - b) * a;
        }
        if (s.lipGloss > 0 && lipA > 0) {
          final center = FacePoint(
            (p[14].x + p[17].x) / 2,
            (p[14].y + p[17].y) / 2,
          );
          final mw = _distance(p[61], p[291]);
          final dx = (mx - center.x) * ux + (my - center.y) * uy,
              dy = -(mx - center.x) * uy + (my - center.y) * ux;
          final d =
              dx * dx / (mw * .3 * mw * .3) + dy * dy / (mw * .055 * mw * .055);
          final shine = d < 1 ? (1 - d) * (1 - d) : 0.0;
          final a = shine * lipA * _u(s.lipGloss) * .28;
          r += (255 - r) * a;
          g += (245 - g) * a;
          b += (248 - b) * a;
        }
        out.setPixelRgba(
          x0 + xx,
          y0 + yy,
          _byte(r),
          _byte(g),
          _byte(b),
          original.a,
        );
      }
    }
  }
  return out;
}

double _distance(FacePoint a, FacePoint b) =>
    math.sqrt(math.pow(a.x - b.x, 2) + math.pow(a.y - b.y, 2));
List<FacePoint> _expand(List<FacePoint> p, double scale) {
  final cx = p.fold(0.0, (v, p) => v + p.x) / p.length,
      cy = p.fold(0.0, (v, p) => v + p.y) / p.length;
  return p
      .map((p) => FacePoint(cx + (p.x - cx) * scale, cy + (p.y - cy) * scale))
      .toList();
}

void _fill(
  Float32List mask,
  int w,
  int h,
  List<FacePoint> points,
  double value,
) {
  if (points.isEmpty) return;
  final y0 = points.map((p) => p.y).reduce(math.min).floor().clamp(0, h - 1),
      y1 = points.map((p) => p.y).reduce(math.max).ceil().clamp(0, h - 1);
  for (var y = y0; y <= y1; y++) {
    final cuts = <double>[];
    for (var i = 0, j = points.length - 1; i < points.length; j = i++) {
      final a = points[j], b = points[i], scan = y + .5;
      if ((a.y > scan) != (b.y > scan)) {
        cuts.add(a.x + (scan - a.y) * (b.x - a.x) / (b.y - a.y));
      }
    }
    cuts.sort();
    for (var i = 0; i + 1 < cuts.length; i += 2) {
      for (
        var x = (cuts[i] - .5).ceil().clamp(0, w - 1);
        x <= (cuts[i + 1] - .5).floor().clamp(0, w - 1);
        x++
      ) {
        mask[y * w + x] = value;
      }
    }
  }
}

void _ellipse(
  Float32List mask,
  int w,
  int h,
  FacePoint c,
  double rx,
  double ry,
  double value,
) {
  for (
    var y = (c.y - ry).floor().clamp(0, h - 1);
    y <= (c.y + ry).ceil().clamp(0, h - 1);
    y++
  ) {
    for (
      var x = (c.x - rx).floor().clamp(0, w - 1);
      x <= (c.x + rx).ceil().clamp(0, w - 1);
      x++
    ) {
      if ((x - c.x) * (x - c.x) / (rx * rx) +
              (y - c.y) * (y - c.y) / (ry * ry) <
          1) {
        mask[y * w + x] = value;
      }
    }
  }
}

void _pathMask(
  Float32List mask,
  int w,
  int h,
  List<FacePoint> path,
  double radius,
) {
  for (var i = 1; i < path.length; i++) {
    final a = path[i - 1],
        b = path[i],
        length2 = math.pow(b.x - a.x, 2) + math.pow(b.y - a.y, 2);
    for (
      var y = (math.min(a.y, b.y) - radius).floor().clamp(0, h - 1);
      y <= (math.max(a.y, b.y) + radius).ceil().clamp(0, h - 1);
      y++
    ) {
      for (
        var x = (math.min(a.x, b.x) - radius).floor().clamp(0, w - 1);
        x <= (math.max(a.x, b.x) + radius).ceil().clamp(0, w - 1);
        x++
      ) {
        final t = length2 > 0
            ? (((x - a.x) * (b.x - a.x) + (y - a.y) * (b.y - a.y)) / length2)
                  .clamp(0.0, 1.0)
            : 0.0;
        final dx = x - a.x - t * (b.x - a.x),
            dy = y - a.y - t * (b.y - a.y),
            d = (dx * dx + dy * dy) / (radius * radius);
        if (d < 1) {
          mask[y * w + x] = math.max(mask[y * w + x], (1 - d) * (1 - d));
        }
      }
    }
  }
}

Float32List _feather(Float32List src, int w, int h, int r) {
  final tmp = Float32List(src.length), out = Float32List(src.length);
  for (var y = 0; y < h; y++) {
    var sum = 0.0;
    for (var x = -r; x <= r; x++) {
      sum += src[y * w + x.clamp(0, w - 1)];
    }
    for (var x = 0; x < w; x++) {
      tmp[y * w + x] = sum / (2 * r + 1);
      sum +=
          src[y * w + (x + r + 1).clamp(0, w - 1)] -
          src[y * w + (x - r).clamp(0, w - 1)];
    }
  }
  for (var x = 0; x < w; x++) {
    var sum = 0.0;
    for (var y = -r; y <= r; y++) {
      sum += tmp[y.clamp(0, h - 1) * w + x];
    }
    for (var y = 0; y < h; y++) {
      out[y * w + x] = sum / (2 * r + 1);
      sum +=
          tmp[(y + r + 1).clamp(0, h - 1) * w + x] -
          tmp[(y - r).clamp(0, h - 1) * w + x];
    }
  }
  return out;
}

im.Color _colorAt(im.Image image, double x, double y) =>
    image.getPixelInterpolate(
      x.clamp(0.0, image.width - 1.0),
      y.clamp(0.0, image.height - 1.0),
      interpolation: im.Interpolation.linear,
    );

double _sample(Float32List src, int w, int h, double x, double y) {
  x = x.clamp(0.0, w - 1.0);
  y = y.clamp(0.0, h - 1.0);
  final a = x.floor(),
      b = y.floor(),
      c = math.min(w - 1, a + 1),
      d = math.min(h - 1, b + 1),
      fx = x - a,
      fy = y - b;
  return (src[b * w + a] * (1 - fx) + src[b * w + c] * fx) * (1 - fy) +
      (src[d * w + a] * (1 - fx) + src[d * w + c] * fx) * fy;
}
