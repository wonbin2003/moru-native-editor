import 'dart:typed_data';

void downloadPhoto(Uint8List bytes, String filename) {
  throw UnsupportedError('Browser download is available on the web only.');
}
