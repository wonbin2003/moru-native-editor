import 'dart:ui' show Rect;
import 'package:flutter/foundation.dart';
import 'package:gal/gal.dart';
import 'package:share_plus/share_plus.dart';
import 'export_stub.dart' if (dart.library.js_interop) 'export_web.dart' as browser;

Future<void> exportPhoto(Uint8List bytes, {String filename = 'moru-edit.jpg'}) async {
  if (kIsWeb) {
    browser.downloadPhoto(bytes, filename);
    return;
  }
  await Gal.putImageBytes(bytes, name: filename.replaceAll(RegExp(r'\.[^.]+$'), ''));
}

Future<void> sharePhoto(Uint8List bytes, {String filename = 'moru-edit.jpg'}) async {
  final actualName = _mime(bytes) == 'image/png'
      ? filename.replaceAll(RegExp(r'\.[^.]+$'), '.png') : filename;
  await SharePlus.instance.share(ShareParams(
    files: [XFile.fromData(bytes, mimeType: _mime(bytes), name: actualName)],
    fileNameOverrides: [actualName],
    sharePositionOrigin: const Rect.fromLTWH(0, 0, 1, 1),
  ));
}

String _mime(Uint8List bytes) => bytes.length > 4 && bytes[0] == 0x89 && bytes[1] == 0x50
    ? 'image/png' : 'image/jpeg';
