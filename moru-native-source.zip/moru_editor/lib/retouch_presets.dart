import 'editor_models.dart';

const retouchPresetLabels = <String, String>{
  'natural': '자연스럽게',
  'clear': '깨끗하게',
  'fresh': '생기있게',
};

/// Absolute strengths make changing the slider reversible and non-accumulating.
/// Geometry, tonal edits and chosen makeup colours remain the user's choices.
EditSettings applyRetouchPreset(
  EditSettings current,
  String preset,
  double intensity,
) {
  if (!retouchPresetLabels.containsKey(preset)) {
    throw ArgumentError.value(preset, 'preset', 'Unknown retouch preset');
  }
  final a = intensity.isFinite ? intensity.clamp(0.0, 1.0) : 0.0;
  final clear = preset == 'clear', fresh = preset == 'fresh';
  return current.copyWith(
    skinSmooth: a * (clear ? .56 : .32),
    skinBrighten: a * (clear ? .18 : .08),
    blemishRemoval: a * (clear ? .6 : .28),
    wrinkleRemove: a * (clear ? .32 : .18),
    nasolabialFoldRemove: a * .22,
    darkCircleReduce: a * (clear ? .38 : .24),
    rednessReduce: a * (clear ? .36 : .18),
    skinTexture: a * .16,
    lipstick: a * (fresh ? .28 : .05),
    blush: a * (fresh ? .32 : .04),
    teethWhiten: a * .15,
    eyeBrighten: a * (fresh ? .24 : .12),
    lipGloss: a * (fresh ? .18 : 0),
  );
}
