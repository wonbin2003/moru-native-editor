import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:mediapipe_vision/mediapipe_vision.dart' as mp;

import 'editor_models.dart';

/// Limits are explicit: importing never silently reduces export resolution.
const int maxPhotoPixels = 24000000;
const int maxPhotoDimension = 12000;
const int maxEncodedPhotoBytes = 96 * 1024 * 1024;

enum PhotoInputFailure {
  unsupportedFormat,
  invalidImage,
  tooLarge,
  animatedImage,
}

class PhotoInputException implements Exception {
  const PhotoInputException(this.code, this.message);

  final PhotoInputFailure code;
  final String message;

  @override
  String toString() => message;
}

enum FaceDetectionFailure { runtimeUnavailable, inferenceFailed, invalidResult }

class FaceDetectionException implements Exception {
  const FaceDetectionException(this.code, this.message, {this.cause});

  final FaceDetectionFailure code;
  final String message;
  final Object? cause;

  @override
  String toString() => message;
}

/// Decodes JPG/PNG/WebP, bakes EXIF rotation/reflection, and returns a PNG.
///
/// Resolution and the decoded pixels are preserved; JPEG is not recompressed.
/// Animated images and images beyond the stated limits fail explicitly.
/// Flutter's compute uses an isolate on mobile and the event loop on web.
Future<Uint8List> normalizePhoto(Uint8List bytes) =>
    compute(_normalizePhoto, bytes, debugLabel: 'normalize-photo');

Uint8List _normalizePhoto(Uint8List bytes) {
  final image = decodePhotoForProcessing(bytes);
  final png = img.encodePng(image, level: 3);
  if (png.lengthInBytes > maxEncodedPhotoBytes) {
    throw const PhotoInputException(
      PhotoInputFailure.tooLarge,
      '정규화한 사진이 96MB를 넘습니다. 해상도를 줄인 사본을 선택해 주세요.',
    );
  }
  return png;
}

/// Shared guarded decoding for image-processing workers. Does not resize.
img.Image decodePhotoForProcessing(Uint8List bytes) {
  if (bytes.lengthInBytes > maxEncodedPhotoBytes) {
    throw const PhotoInputException(
      PhotoInputFailure.tooLarge,
      '96MB 이하의 사진을 선택해 주세요. 원본 해상도는 자동으로 줄이지 않습니다.',
    );
  }
  final img.Decoder decoder;
  if (bytes.length >= 2 && bytes[0] == 0xff && bytes[1] == 0xd8) {
    decoder = img.JpegDecoder(maxPixels: maxPhotoPixels);
  } else if (bytes.length >= 8 &&
      bytes[0] == 137 &&
      bytes[1] == 80 &&
      bytes[2] == 78 &&
      bytes[3] == 71 &&
      bytes[4] == 13 &&
      bytes[5] == 10 &&
      bytes[6] == 26 &&
      bytes[7] == 10) {
    decoder = img.PngDecoder(maxPixels: maxPhotoPixels);
  } else if (bytes.length >= 12 &&
      bytes[0] == 82 &&
      bytes[1] == 73 &&
      bytes[2] == 70 &&
      bytes[3] == 70 &&
      bytes[8] == 87 &&
      bytes[9] == 69 &&
      bytes[10] == 66 &&
      bytes[11] == 80) {
    decoder = img.WebPDecoder()..maxPixels = maxPhotoPixels;
  } else {
    throw const PhotoInputException(
      PhotoInputFailure.unsupportedFormat,
      'JPG, PNG, WebP 사진을 선택해 주세요. HEIC는 JPG로 변환한 후 사용할 수 있습니다.',
    );
  }

  try {
    // Read dimensions before asking the decoder to allocate pixel buffers.
    final info = decoder.startDecode(bytes);
    if (info == null || info.width <= 0 || info.height <= 0) {
      throw const PhotoInputException(
        PhotoInputFailure.invalidImage,
        '손상되었거나 읽을 수 없는 사진입니다.',
      );
    }
    if (info.width > maxPhotoDimension ||
        info.height > maxPhotoDimension ||
        info.width * info.height > maxPhotoPixels) {
      throw const PhotoInputException(
        PhotoInputFailure.tooLarge,
        '2,400만 화소 이하, 한 변 12,000px 이하의 사진을 선택해 주세요. '
        '원본 해상도는 자동으로 줄이지 않습니다.',
      );
    }
    if (info.numFrames > 1) {
      throw const PhotoInputException(
        PhotoInputFailure.animatedImage,
        '움직이는 이미지는 지원하지 않습니다. 정지 사진을 선택해 주세요.',
      );
    }
    final decoded = decoder.decodeFrame(0);
    if (decoded == null) {
      throw const PhotoInputException(
        PhotoInputFailure.invalidImage,
        '사진 데이터를 읽을 수 없습니다.',
      );
    }
    return img.bakeOrientation(decoded);
  } on PhotoInputException {
    rethrow;
  } on img.ImageException catch (error) {
    final tooLarge = error.toString().toLowerCase().contains('pixel');
    throw PhotoInputException(
      tooLarge ? PhotoInputFailure.tooLarge : PhotoInputFailure.invalidImage,
      tooLarge
          ? '사진이 허용 크기를 넘습니다. 2,400만 화소 이하의 사본을 선택해 주세요.'
          : '손상되었거나 읽을 수 없는 사진입니다.',
    );
  } on FormatException {
    throw const PhotoInputException(
      PhotoInputFailure.invalidImage,
      '손상되었거나 읽을 수 없는 사진입니다.',
    );
  } on RangeError {
    throw const PhotoInputException(
      PhotoInputFailure.invalidImage,
      '사진 데이터가 불완전합니다.',
    );
  }
}

class _DetectionInput {
  const _DetectionInput(this.rgba, this.width, this.height);
  final Uint8List rgba;
  final int width;
  final int height;
}

_DetectionInput _prepareDetectionInput(Uint8List bytes) {
  var image = decodePhotoForProcessing(bytes);
  // Only the inference copy is smaller. Normalized coordinates are relative
  // to the full image, and the source used for export remains untouched.
  final longest = math.max(image.width, image.height);
  if (longest > 1600) {
    final scale = 1600 / longest;
    image = img.copyResize(
      image,
      width: math.max(1, (image.width * scale).round()),
      height: math.max(1, (image.height * scale).round()),
      interpolation: img.Interpolation.linear,
    );
  }
  return _DetectionInput(
    image.getBytes(order: img.ChannelOrder.rgba),
    image.width,
    image.height,
  );
}

Future<mp.FaceLandmarker>? _landmarker;

Future<mp.FaceLandmarker> _getLandmarker() {
  return _landmarker ??= _createLandmarker();
}

Future<mp.FaceLandmarker> _createLandmarker() async {
  try {
    // The bundler names verified official assets by their pinned SHA-256.
    // Reading bytes also works in test hosts without a path_provider plugin.
    final asset = await rootBundle.load(
      'assets/mediapipe/${mp.VisionModels.faceLandmarker.sha256}',
    );
    if (kIsWeb) {
      // Root build setup vendors the verified JS/WASM here. No CDN at runtime.
      mp.MediaPipeWebRuntime.baseUrl = 'mediapipe/';
    }
    return await mp.FaceLandmarker.create(
      mp.FaceLandmarkerOptions(
        modelBytes: asset.buffer.asUint8List(
          asset.offsetInBytes,
          asset.lengthInBytes,
        ),
        runningMode: mp.RunningMode.image,
        delegate: mp.Delegate.cpu,
        numFaces: 5,
      ),
    );
  } catch (_) {
    _landmarker = null;
    rethrow;
  }
}

/// Returns actual MediaPipe 478-point model outputs in upright image space.
///
/// An empty list means inference succeeded and no face was found. Missing
/// models/runtimes and inference failures throw; no placeholder points exist.
Future<List<FaceGeometry>> detectFaces(Uint8List encodedBytes) async {
  final input = await compute(
    _prepareDetectionInput,
    encodedBytes,
    debugLabel: 'prepare-face-detection',
  );
  try {
    final task = await _getLandmarker();
    final result = await task.detect(
      mp.VisionImage.fromPixels(
        pixels: input.rgba,
        width: input.width,
        height: input.height,
        format: mp.VisionPixelFormat.rgba,
      ),
    );
    final faces = <FaceGeometry>[];
    for (final landmarks in result.faceLandmarks) {
      if (landmarks.length != 478 ||
          landmarks.any((point) => !point.x.isFinite || !point.y.isFinite)) {
        throw const FaceDetectionException(
          FaceDetectionFailure.invalidResult,
          '얼굴 모델의 결과를 읽을 수 없습니다. 기본 사진 편집은 사용할 수 있습니다.',
        );
      }
      faces.add(
        FaceGeometry(
          points: List<FacePoint>.unmodifiable(
            landmarks.map((point) => FacePoint(point.x, point.y)),
          ),
        ),
      );
    }
    return List<FaceGeometry>.unmodifiable(faces);
  } on FaceDetectionException {
    rethrow;
  } on mp.RuntimeUnavailableException catch (error) {
    throw FaceDetectionException(
      FaceDetectionFailure.runtimeUnavailable,
      '얼굴 인식 모델 또는 실행 환경을 불러오지 못했습니다. '
      '기본 사진 편집은 사용할 수 있습니다.',
      cause: error,
    );
  } on mp.MediaPipeException catch (error) {
    throw FaceDetectionException(
      FaceDetectionFailure.inferenceFailed,
      '얼굴 인식에 실패했습니다. 다른 사진으로 시도하거나 기본 사진 편집을 사용해 주세요.',
      cause: error,
    );
  } catch (error) {
    throw FaceDetectionException(
      FaceDetectionFailure.inferenceFailed,
      '얼굴 인식을 실행하지 못했습니다. 기본 사진 편집은 사용할 수 있습니다.',
      cause: error,
    );
  }
}

/// Call when the editor is permanently closed, after pending detections finish.
Future<void> disposeFaceDetector() async {
  final pending = _landmarker;
  _landmarker = null;
  if (pending == null) return;
  try {
    final task = await pending;
    await task.dispose();
  } on mp.MediaPipeException {
    // Creation already reported this failure through detectFaces.
  }
}
