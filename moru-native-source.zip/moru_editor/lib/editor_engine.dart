import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show compute;
import 'package:image/image.dart' as im;
import 'editor_models.dart';
import 'retouch_engine.dart';
export 'editor_models.dart';

/// Render the immutable source off the UI isolate. PNG avoids repeated JPEG loss.
Future<Uint8List> renderImage(
  Uint8List bytes,
  EditSettings settings, {
  List<FaceGeometry> faces = const [],
  int maxDimension = 1440,
}) => compute(_render, _Render(bytes, settings, faces, maxDimension));

class _Render {
  const _Render(this.bytes, this.settings, this.faces, this.limit);
  final Uint8List bytes;
  final EditSettings settings;
  final List<FaceGeometry> faces;
  final int limit;
}

im.Image _decode(Uint8List bytes) {
  final decoded = im.decodeImage(bytes);
  if (decoded == null) {
    throw const FormatException('사진을 읽을 수 없습니다. JPG 또는 PNG 사진을 선택하세요.');
  }
  return im.bakeOrientation(decoded).convert(numChannels: 4);
}

Uint8List _encode(im.Image image) =>
    Uint8List.fromList(im.encodePng(image, level: 3));
double _unit(double value) => value.isFinite ? value.clamp(0.0, 1.0) : 0;
double _signed(double value) => value.isFinite ? value.clamp(-1.0, 1.0) : 0;
double _clamp(num v) => v.toDouble().clamp(0.0, 255.0).roundToDouble();
double _luma(num r, num g, num b) => .2126 * r + .7152 * g + .0722 * b;
double _smooth(double low, double high, double v) {
  final t = ((v - low) / (high - low)).clamp(0.0, 1.0);
  return t * t * (3 - 2 * t);
}

Uint8List _render(_Render req) {
  var image = _decode(req.bytes);
  if (req.limit > 0 && math.max(image.width, image.height) > req.limit) {
    final scale = req.limit / math.max(image.width, image.height);
    image = im.copyResize(
      image,
      width: math.max(1, (image.width * scale).round()),
      height: math.max(1, (image.height * scale).round()),
      interpolation: im.Interpolation.cubic,
    );
  }
  if (req.settings.isNeutral) return _encode(image);
  final s = req.settings;
  image = _tonal(image, s);
  final faces = req.faces
      .where(
        (f) => f.isValid && f.points.every((p) => p.x.isFinite && p.y.isFinite),
      )
      .toList(growable: false);
  if (faces.isNotEmpty &&
      (s.skinSmooth != 0 ||
          s.skinBrighten != 0 ||
          s.lipstick != 0 ||
          s.blush != 0 ||
          s.teethWhiten != 0 ||
          s.eyeBrighten != 0)) {
    image = _beauty(image, s, faces);
  }
  if (faces.isNotEmpty && s.hasRetouchPixels) {
    image = applyRetouchPixels(image, s, faces);
  }
  if (s.sharpness > 0) image = _sharpen(image, _unit(s.sharpness));
  if (faces.isNotEmpty && s.hasFaceWarp) {
    image = _warpFace(image, s, faces);
  }
  if (s.bodySlim > 0 || s.legLength > 0) image = _body(image, s);
  return _encode(image);
}

im.Image _tonal(im.Image src, EditSettings s) {
  // Skip an entire full-resolution copy/pass when only portrait controls change.
  if (s.filter == 'none' &&
      s.exposure == 0 &&
      s.contrast == 0 &&
      s.saturation == 0 &&
      s.warmth == 0 &&
      s.highlights == 0 &&
      s.shadows == 0 &&
      s.vignette == 0 &&
      s.grain == 0) {
    return src;
  }
  final out = im.Image.from(src);
  final exposure = math.pow(2, _signed(s.exposure) * 1.8).toDouble();
  final contrast = 1 + _signed(s.contrast) * .65;
  final saturation = 1 + _signed(s.saturation);
  final warmth = _signed(s.warmth) * 22;
  final vignette = _unit(s.vignette);
  for (var y = 0; y < src.height; y++) {
    for (var x = 0; x < src.width; x++) {
      final p = src.getPixel(x, y);
      var r = p.r.toDouble(), g = p.g.toDouble(), b = p.b.toDouble();
      final l = _luma(r, g, b) / 255;
      final lift = _signed(s.shadows) * 48 * (1 - _smooth(.05, .7, l));
      final recover = _signed(s.highlights) * 44 * _smooth(.35, .95, l);
      r = ((r * exposure + lift + recover - 127.5) * contrast + 127.5) + warmth;
      g =
          ((g * exposure + lift + recover - 127.5) * contrast + 127.5) +
          warmth * .12;
      b = ((b * exposure + lift + recover - 127.5) * contrast + 127.5) - warmth;
      var lum = _luma(r, g, b);
      r = lum + (r - lum) * saturation;
      g = lum + (g - lum) * saturation;
      b = lum + (b - lum) * saturation;
      switch (s.filter) {
        case 'natural':
          r = r * 1.015 + 2;
          g = g * 1.01 + 1;
          b *= .985;
        case 'cream':
          r = r * .94 + 16;
          g = g * .94 + 12;
          b = b * .91 + 9;
        case 'rose':
          r = r * 1.025 + 8;
          g = g * .965 + 2;
          b = b * .99 + 5;
        case 'film':
          r = r * .91 + 17;
          g = g * .94 + 10;
          b = b * .87 + 16;
          final t = _smooth(140, 250, lum);
          r -= 8 * t;
          b -= 4 * t;
        case 'mono':
          lum = _luma(r, g, b);
          r = lum;
          g = lum;
          b = lum;
      }
      if (vignette > 0) {
        final dx = (x + .5 - src.width / 2) / (src.width / 2);
        final dy = (y + .5 - src.height / 2) / (src.height / 2);
        final factor =
            1 - .42 * vignette * _smooth(.25, 1.65, dx * dx + dy * dy);
        r *= factor;
        g *= factor;
        b *= factor;
      }
      if (s.grain > 0) {
        // Fixed, source-coordinate noise: sliders never flicker between renders.
        var hash = (x * 374761393 + y * 668265263 + 1447) & 0x7fffffff;
        hash = ((hash ^ (hash >> 13)) * 1274126177) & 0x7fffffff;
        final n = ((hash & 1023) / 1023 - .5) * 26 * _unit(s.grain);
        r += n;
        g += n;
        b += n;
      }
      out.setPixelRgba(x, y, _clamp(r), _clamp(g), _clamp(b), p.a);
    }
  }
  return out;
}

const _oval = [
  10,
  338,
  297,
  332,
  284,
  251,
  389,
  356,
  454,
  323,
  361,
  288,
  397,
  365,
  379,
  378,
  400,
  377,
  152,
  148,
  176,
  149,
  150,
  136,
  172,
  58,
  132,
  93,
  234,
  127,
  162,
  21,
  54,
  103,
  67,
  109,
];
const _leftEye = [
  33,
  7,
  163,
  144,
  145,
  153,
  154,
  155,
  133,
  173,
  157,
  158,
  159,
  160,
  161,
  246,
];
const _rightEye = [
  263,
  249,
  390,
  373,
  374,
  380,
  381,
  382,
  362,
  398,
  384,
  385,
  386,
  387,
  388,
  466,
];
const _outerLip = [
  61,
  185,
  40,
  39,
  37,
  0,
  267,
  269,
  270,
  409,
  291,
  375,
  321,
  405,
  314,
  17,
  84,
  181,
  91,
  146,
];
const _innerLip = [
  78,
  191,
  80,
  81,
  82,
  13,
  312,
  311,
  310,
  415,
  308,
  324,
  318,
  402,
  317,
  14,
  87,
  178,
  88,
  95,
];
const _leftBrow = [70, 63, 105, 66, 107, 55, 65, 52, 53, 46];
const _rightBrow = [336, 296, 334, 293, 300, 276, 283, 282, 295, 285];

List<FacePoint> _polygon(FaceGeometry face, List<int> ids, int w, int h) => ids
    .map((i) => FacePoint(face.points[i].x * w, face.points[i].y * h))
    .toList();

/// Scanline rasterization avoids testing every pixel against every polygon edge.
void _fill(
  Float32List mask,
  int w,
  int h,
  List<FacePoint> points,
  double value,
) {
  if (points.isEmpty) return;
  final top = math.max(0, points.map((p) => p.y).reduce(math.min).floor());
  final bottom = math.min(
    h - 1,
    points.map((p) => p.y).reduce(math.max).ceil(),
  );
  for (var y = top; y <= bottom; y++) {
    final intersections = <double>[];
    for (var i = 0, j = points.length - 1; i < points.length; j = i++) {
      final a = points[j], b = points[i], scan = y + .5;
      if ((a.y > scan) != (b.y > scan)) {
        intersections.add(a.x + (scan - a.y) * (b.x - a.x) / (b.y - a.y));
      }
    }
    intersections.sort();
    for (var i = 0; i + 1 < intersections.length; i += 2) {
      final left = math.max(0, (intersections[i] - .5).ceil());
      final right = math.min(w - 1, (intersections[i + 1] - .5).floor());
      for (var x = left; x <= right; x++) {
        mask[y * w + x] = value;
      }
    }
  }
}

Float32List _feather(Float32List src, int w, int h, int r) {
  if (r < 1) return src;
  final tmp = Float32List(src.length), out = Float32List(src.length);
  for (var y = 0; y < h; y++) {
    var sum = 0.0;
    for (var x = -r; x <= r; x++) {
      sum += src[y * w + x.clamp(0, w - 1)];
    }
    for (var x = 0; x < w; x++) {
      tmp[y * w + x] = sum / (2 * r + 1);
      sum +=
          src[y * w + (x + r + 1).clamp(0, w - 1)] -
          src[y * w + (x - r).clamp(0, w - 1)];
    }
  }
  for (var x = 0; x < w; x++) {
    var sum = 0.0;
    for (var y = -r; y <= r; y++) {
      sum += tmp[y.clamp(0, h - 1) * w + x];
    }
    for (var y = 0; y < h; y++) {
      out[y * w + x] = sum / (2 * r + 1);
      sum +=
          tmp[(y + r + 1).clamp(0, h - 1) * w + x] -
          tmp[(y - r).clamp(0, h - 1) * w + x];
    }
  }
  return out;
}

im.Image _beauty(im.Image src, EditSettings s, List<FaceGeometry> faces) {
  // Masks are smooth signals: bound their working resolution independently of
  // the lossless full-resolution output. This avoids six 24MP float buffers.
  final fullW = src.width, fullH = src.height;
  final scale = math.min(1.0, 1024 / math.max(fullW, fullH));
  final w = math.max(1, (fullW * scale).round());
  final h = math.max(1, (fullH * scale).round()), size = w * h;
  final skin = Float32List(size),
      lips = Float32List(size),
      mouth = Float32List(size);
  final eyes = Float32List(size), cheeks = Float32List(size);
  for (final face in faces) {
    final localSkin = Float32List(size);
    _fill(localSkin, w, h, _polygon(face, _oval, w, h), 1);
    for (final ids in [_leftEye, _rightEye, _outerLip, _leftBrow, _rightBrow]) {
      _fill(localSkin, w, h, _polygon(face, ids, w, h), 0);
    }
    _fill(lips, w, h, _polygon(face, _outerLip, w, h), 1);
    _fill(lips, w, h, _polygon(face, _innerLip, w, h), 0);
    _fill(mouth, w, h, _polygon(face, _innerLip, w, h), 1);
    _fill(eyes, w, h, _polygon(face, _leftEye, w, h), 1);
    _fill(eyes, w, h, _polygon(face, _rightEye, w, h), 1);
    final sideDx = (face.points[454].x - face.points[234].x) * w;
    final sideDy = (face.points[454].y - face.points[234].y) * h;
    final verticalDx = (face.points[152].x - face.points[10].x) * w;
    final verticalDy = (face.points[152].y - face.points[10].y) * h;
    final fw = math.sqrt(sideDx * sideDx + sideDy * sideDy);
    final fh = math.sqrt(verticalDx * verticalDx + verticalDy * verticalDy);
    final eyeDx =
        ((face.points[263].x + face.points[362].x) -
            (face.points[33].x + face.points[133].x)) *
        w;
    final eyeDy =
        ((face.points[263].y + face.points[362].y) -
            (face.points[33].y + face.points[133].y)) *
        h;
    final eyeLength = math.sqrt(eyeDx * eyeDx + eyeDy * eyeDy);
    final ux = eyeLength > 0 ? eyeDx / eyeLength : 1.0,
        uy = eyeLength > 0 ? eyeDy / eyeLength : 0.0;
    for (final index in [50, 280]) {
      final cx = face.points[index].x * w, cy = face.points[index].y * h;
      final rx = math.max(1.0, fw * .15), ry = math.max(1.0, fh * .065);
      final extentX = math.sqrt(rx * rx * ux * ux + ry * ry * uy * uy);
      final extentY = math.sqrt(rx * rx * uy * uy + ry * ry * ux * ux);
      for (
        var y = math.max(0, (cy - extentY).floor());
        y <= math.min(h - 1, (cy + extentY).ceil());
        y++
      ) {
        for (
          var x = math.max(0, (cx - extentX).floor());
          x <= math.min(w - 1, (cx + extentX).ceil());
          x++
        ) {
          final xx = (x - cx) * ux + (y - cy) * uy,
              yy = -(x - cx) * uy + (y - cy) * ux;
          final d = math.pow(xx / rx, 2) + math.pow(yy / ry, 2);
          if (d < 1) {
            cheeks[y * w + x] = math.max(
              cheeks[y * w + x],
              math.pow(1 - d, 2).toDouble(),
            );
          }
        }
      }
    }
    for (var i = 0; i < size; i++) {
      skin[i] = math.max(skin[i], localSkin[i]);
    }
  }
  final radius = math.max(1, (math.min(w, h) / 400).round());
  final sm = _feather(skin, w, h, radius * 2),
      lm = _feather(lips, w, h, radius);
  final em = _feather(eyes, w, h, radius), mm = _feather(mouth, w, h, radius);
  final blur = s.skinSmooth > 0
      ? im.gaussianBlur(
          im.copyResize(
            src,
            width: w,
            height: h,
            interpolation: im.Interpolation.linear,
          ),
          radius: math.max(2, radius * 2),
        )
      : null;
  final out = im.Image.from(src);
  final lipTint = _paletteTint(s.lipstickColor);
  final cheekTint = _paletteTint(s.blushColor);
  final customLip = (s.lipstickColor & 0xffffff) != 0xe84668;
  final customCheek = (s.blushColor & 0xffffff) != 0xee8492;
  for (var y = 0; y < fullH; y++) {
    for (var x = 0; x < fullW; x++) {
      final mx = (x + .5) * w / fullW - .5;
      final my = (y + .5) * h / fullH - .5;
      // Feather inward, not out across the face outline or onto eyes/lips.
      final skinMask = _smooth(.5, .98, _maskSample(sm, w, h, mx, my));
      final lipMask = s.lipstick > 0 ? _maskSample(lm, w, h, mx, my) : 0.0;
      final cheekMask = s.blush > 0 ? _maskSample(cheeks, w, h, mx, my) : 0.0;
      final eyeMask = s.eyeBrighten > 0
          ? _smooth(.5, .98, _maskSample(em, w, h, mx, my))
          : 0.0;
      final mouthMask = s.teethWhiten > 0
          ? _smooth(.5, .98, _maskSample(mm, w, h, mx, my))
          : 0.0;
      if (skinMask + lipMask + cheekMask + eyeMask + mouthMask < .0001) {
        continue;
      }
      final p = src.getPixel(x, y);
      var r = p.r.toDouble(), g = p.g.toDouble(), b = p.b.toDouble();
      final l = _luma(r, g, b);
      // Chroma and luminance confidence prevents smoothing hair, eyes and deep shadows.
      final skinConfidence =
          _smooth(10, 50, l) *
          (1 - _smooth(240, 255, l)) *
          _smooth(-18, 12, r - b) *
          _smooth(-24, 4, r - g);
      if (blur != null && skinMask > .001 && skinConfidence > 0) {
        final q = blur.getPixelInterpolate(
          mx,
          my,
          interpolation: im.Interpolation.linear,
        );
        final edge = (l - _luma(q.r, q.g, q.b)).abs();
        final weight =
            skinMask *
            skinConfidence *
            _unit(s.skinSmooth) *
            .72 *
            (1 - _smooth(8, 30, edge));
        r += (q.r - r) * weight;
        g += (q.g - g) * weight;
        b += (q.b - b) * weight;
      }
      if (s.skinBrighten > 0) {
        final lift =
            skinMask *
            skinConfidence *
            _unit(s.skinBrighten) *
            18 *
            (1 - _smooth(190, 250, l));
        r += lift;
        g += lift;
        b += lift * .95;
      }
      if (s.lipstick > 0 && lipMask > .001) {
        final a = lipMask * _unit(s.lipstick) * .48 * lipTint[3];
        // Preserve lip luminance and texture instead of painting an opaque patch.
        var tr = l * 1.38 + 20, tg = l * .63, tb = l * .82;
        if (customLip) {
          final tone = _luma(tr, tg, tb);
          tr = tone * lipTint[0];
          tg = tone * lipTint[1];
          tb = tone * lipTint[2];
        }
        r += (tr - r) * a;
        g += (tg - g) * a;
        b += (tb - b) * a;
      }
      if (s.blush > 0 && cheekMask > 0) {
        final a = cheekMask * skinMask * _unit(s.blush) * .23 * cheekTint[3];
        var tr = l * 1.2 + 20, tg = l * .82, tb = l * .94;
        if (customCheek) {
          final tone = _luma(tr, tg, tb);
          tr = tone * cheekTint[0];
          tg = tone * cheekTint[1];
          tb = tone * cheekTint[2];
        }
        r += (tr - r) * a;
        g += (tg - g) * a;
        b += (tb - b) * a;
      }
      final chroma = math.max(r, math.max(g, b)) - math.min(r, math.min(g, b));
      final tooth =
          mouthMask *
          _unit(s.teethWhiten) *
          _smooth(80, 180, l) *
          (1 - _smooth(40, 100, chroma));
      final eye =
          eyeMask *
          _unit(s.eyeBrighten) *
          _smooth(70, 180, l) *
          (1 - _smooth(45, 110, chroma));
      final white = math.max(tooth, eye) * .45;
      if (white > 0) {
        final target = l + (255 - l) * .22;
        r += (target - r) * white;
        g += (target - g) * white;
        b += (target - b) * white;
      }
      out.setPixelRgba(x, y, _clamp(r), _clamp(g), _clamp(b), p.a);
    }
  }
  return out;
}

List<double> _paletteTint(int color) {
  final r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
  final luminance = math.max(1.0, _luma(r, g, b));
  return [
    r / luminance,
    g / luminance,
    b / luminance,
    ((color >> 24) & 255) / 255,
  ];
}

double _maskSample(Float32List mask, int w, int h, double x, double y) {
  x = x.clamp(0.0, w - 1.0);
  y = y.clamp(0.0, h - 1.0);
  final x0 = x.floor(), y0 = y.floor();
  final x1 = math.min(w - 1, x0 + 1), y1 = math.min(h - 1, y0 + 1);
  final fx = x - x0, fy = y - y0;
  return (mask[y0 * w + x0] * (1 - fx) + mask[y0 * w + x1] * fx) * (1 - fy) +
      (mask[y1 * w + x0] * (1 - fx) + mask[y1 * w + x1] * fx) * fy;
}

im.Image _sharpen(im.Image src, double amount) {
  final blur = im.gaussianBlur(im.Image.from(src), radius: 1),
      out = im.Image.from(src);
  for (var y = 0; y < src.height; y++) {
    for (var x = 0; x < src.width; x++) {
      final p = src.getPixel(x, y), q = blur.getPixel(x, y);
      final edge = (_luma(p.r, p.g, p.b) - _luma(q.r, q.g, q.b)).abs();
      final a =
          amount *
          .7 *
          _smooth(1.5, 8, edge); // Ignore tiny noise, retain fine edges.
      out.setPixelRgba(
        x,
        y,
        _clamp(p.r + (p.r - q.r) * a),
        _clamp(p.g + (p.g - q.g) * a),
        _clamp(p.b + (p.b - q.b) * a),
        p.a,
      );
    }
  }
  return out;
}

class _Warp {
  const _Warp(
    this.x,
    this.y,
    this.rx,
    this.ry, {
    this.dx = 0,
    this.dy = 0,
    this.scaleX = 0,
    this.scaleY = 0,
    this.axisX = 1,
    this.axisY = 0,
    this.flatCore = false,
  });
  final double x, y, rx, ry, dx, dy, scaleX, scaleY, axisX, axisY;
  final bool flatCore;
  double get extentX =>
      math.sqrt(rx * rx * axisX * axisX + ry * ry * axisY * axisY);
  double get extentY =>
      math.sqrt(rx * rx * axisY * axisY + ry * ry * axisX * axisX);
}

im.Image _warpFace(im.Image src, EditSettings s, List<FaceGeometry> faces) {
  final warps = <_Warp>[];
  for (final face in faces) {
    final p = face.points, w = src.width.toDouble(), h = src.height.toDouble();
    double distance(int a, int b) => math.sqrt(
      math.pow((p[a].x - p[b].x) * w, 2) + math.pow((p[a].y - p[b].y) * h, 2),
    );
    final fw = distance(454, 234), fh = distance(152, 10);
    if (fw < 2 || fh < 2) continue;
    // Work in face coordinates, so a rolled head gets the same anatomical edit.
    final leftX = (p[33].x + p[133].x) * w / 2,
        leftY = (p[33].y + p[133].y) * h / 2;
    final eyeDx = (p[263].x + p[362].x) * w / 2 - leftX;
    final eyeDy = (p[263].y + p[362].y) * h / 2 - leftY;
    final eyeDistance = math.sqrt(eyeDx * eyeDx + eyeDy * eyeDy);
    if (eyeDistance < 1) continue;
    final ux = eyeDx / eyeDistance, uy = eyeDy / eyeDistance;
    final cx = p[168].x * w, cy = p[168].y * h;
    for (final i in [93, 132, 58, 323, 361, 288]) {
      final x = p[i].x * w, y = p[i].y * h;
      final delta = ((cx - x) * ux + (cy - y) * uy) * .095 * _unit(s.faceSlim);
      if (delta != 0) {
        warps.add(
          _Warp(
            x + delta * ux,
            y + delta * uy,
            fw * .26,
            fh * .15,
            dx: -delta * ux,
            dy: -delta * uy,
            axisX: ux,
            axisY: uy,
          ),
        );
      }
    }
    for (final pair in [
      [33, 133],
      [263, 362],
    ]) {
      final a = p[pair[0]],
          b = p[pair[1]],
          ex = (a.x + b.x) * w / 2,
          ey = (a.y + b.y) * h / 2;
      final ew = distance(pair[0], pair[1]);
      if (s.eyeEnlarge > 0 && ew > 1) {
        warps.add(
          _Warp(
            ex,
            ey,
            ew * .9,
            ew * .65,
            scaleX: _unit(s.eyeEnlarge) * .17,
            scaleY: _unit(s.eyeEnlarge) * .17,
            axisX: ux,
            axisY: uy,
          ),
        );
      }
    }
    if (s.noseSlim > 0) {
      warps.add(
        _Warp(
          p[1].x * w,
          p[1].y * h,
          fw * .19,
          fh * .17,
          scaleX: -_unit(s.noseSlim) * .14,
          axisX: ux,
          axisY: uy,
        ),
      );
    }
    if (s.chinLength != 0) {
      final delta = _signed(s.chinLength) * fh * .035;
      warps.add(
        _Warp(
          p[152].x * w - delta * uy,
          p[152].y * h + delta * ux,
          fw * .28,
          fh * .14,
          dx: delta * uy,
          dy: -delta * ux,
          axisX: ux,
          axisY: uy,
        ),
      );
    }
    _addFineFaceWarps(warps, face, s, w, h, fw, fh, ux, uy);
  }
  return _warp(src, warps);
}

/// Independent, compactly supported edits in an anatomical coordinate frame.
/// These are 2D appearance adjustments; they do not reconstruct nasal cartilage,
/// restore occluded detail, or change a person's actual three-dimensional shape.
void _addFineFaceWarps(
  List<_Warp> warps,
  FaceGeometry face,
  EditSettings s,
  double w,
  double h,
  double fw,
  double fh,
  double ux,
  double uy,
) {
  FacePoint point(int id) =>
      FacePoint(face.points[id].x * w, face.points[id].y * h);
  FacePoint average(List<int> ids) {
    var x = 0.0, y = 0.0;
    for (final id in ids) {
      final p = point(id);
      x += p.x;
      y += p.y;
    }
    return FacePoint(x / ids.length, y / ids.length);
  }

  double distance(int a, int b) {
    final p = point(a), q = point(b);
    return math.sqrt((p.x - q.x) * (p.x - q.x) + (p.y - q.y) * (p.y - q.y));
  }

  void scale(
    FacePoint c,
    double rx,
    double ry, {
    double horizontal = 0,
    double vertical = 0,
  }) {
    if (horizontal == 0 && vertical == 0) return;
    warps.add(
      _Warp(
        c.x,
        c.y,
        math.max(1.0, rx),
        math.max(1.0, ry),
        scaleX: horizontal,
        scaleY: vertical,
        axisX: ux,
        axisY: uy,
      ),
    );
  }

  void move(
    FacePoint c,
    double rx,
    double ry, {
    double horizontal = 0,
    double vertical = 0,
  }) {
    if (horizontal == 0 && vertical == 0) return;
    rx = math.max(1.0, rx);
    ry = math.max(1.0, ry);
    // Limit translation to a small fraction of its support: each individual
    // field stays smooth at both endpoints and cannot turn inside out.
    final u = horizontal.clamp(-rx * .18, rx * .18);
    final v = vertical.clamp(-ry * .18, ry * .18);
    final dx = u * ux - v * uy, dy = u * uy + v * ux;
    warps.add(
      _Warp(c.x + dx, c.y + dy, rx, ry, dx: -dx, dy: -dy, axisX: ux, axisY: uy),
    );
  }

  void pairWidth(
    int a,
    int b,
    double value,
    double amount,
    double rx,
    double ry,
  ) {
    final strength = _signed(value);
    if (strength == 0) return;
    final left = point(a), right = point(b);
    final direction = ((right.x - left.x) * ux + (right.y - left.y) * uy) >= 0
        ? 1.0
        : -1.0;
    move(left, rx, ry, horizontal: -direction * amount * strength);
    move(right, rx, ry, horizontal: direction * amount * strength);
  }

  // The nose contour follows MediaPipe's official topology: 168→6→197→195→
  // 5→4→1, with alar wings 98/327. Three width controls use distinct supports.
  final alarWidth = math.max(fw * .16, distance(98, 327));
  pairWidth(
    98,
    327,
    s.noseAlarWidth,
    fw * .012,
    math.max(fw * .065, alarWidth * .47),
    fh * .062,
  );
  scale(
    point(6),
    fw * .10,
    fh * .105,
    horizontal: _signed(s.noseBridgeWidth) * .22,
  );
  scale(
    point(195),
    fw * .105,
    fh * .080,
    horizontal: _signed(s.noseDorsumWidth) * .24,
  );
  final tip = average([1, 4]);
  scale(
    tip,
    fw * .105,
    fh * .067,
    horizontal: _signed(s.noseTipSize) * .20,
    vertical: _signed(s.noseTipSize) * .20,
  );
  move(
    tip,
    fw * .115,
    fh * .068,
    vertical: -_signed(s.noseTipLift) * fh * .012,
  );
  // Move the nasal base while the upper bridge remains anchored.
  move(
    average([2, 94]),
    fw * .16,
    fh * .13,
    vertical: _signed(s.noseLength) * fh * .018,
  );
  move(
    average([6, 2]),
    fw * .15,
    fh * .20,
    vertical: _signed(s.nosePosition) * fh * .020,
  );

  for (final eye in [
    [33, 133, 159, 145, -1],
    [263, 362, 386, 374, 1],
  ]) {
    final center = average([eye[0], eye[1]]);
    final width = math.max(fw * .09, distance(eye[0], eye[1]));
    final height = math.max(fh * .018, distance(eye[2], eye[3]));
    final rx = width * .95, ry = math.max(width * .48, height * 1.7);
    scale(center, rx, ry, horizontal: _signed(s.eyeWidth) * .22);
    scale(center, rx, ry, vertical: _signed(s.eyeHeight) * .25);
    move(
      center,
      rx,
      ry,
      horizontal: eye[4] * _signed(s.eyeSpacing) * fw * .018,
    );
    move(center, rx, ry, vertical: _signed(s.eyePosition) * fh * .014);
    // Keep the inner corner outside the outer-corner tilt's local support.
    move(
      point(eye[0]),
      width * .62,
      width * .48,
      vertical: -_signed(s.eyeTilt) * width * .12,
    );
    final lower = average([eye[3], eye[4] < 0 ? 50 : 280]);
    scale(
      lower,
      width * .90,
      fh * .055,
      horizontal: _signed(s.underEyeVolume) * .08,
      vertical: _signed(s.underEyeVolume) * .14,
    );
  }

  final mouthWidth = math.max(fw * .15, distance(61, 291));
  final mouthCenter = average([61, 291]);
  scale(
    mouthCenter,
    mouthWidth * .92,
    mouthWidth * .48,
    horizontal: _signed(s.lipWidth) * .22,
  );
  scale(
    average([0, 13]),
    mouthWidth * .60,
    math.max(fh * .018, distance(0, 13) * 1.2),
    vertical: _signed(s.upperLipFullness) * .28,
  );
  scale(
    average([17, 14]),
    mouthWidth * .60,
    math.max(fh * .018, distance(17, 14) * 1.2),
    vertical: _signed(s.lowerLipFullness) * .28,
  );
  move(
    mouthCenter,
    mouthWidth * .95,
    mouthWidth * .52,
    vertical: _signed(s.mouthPosition) * fh * .020,
  );
  for (final corner in [61, 291]) {
    move(
      point(corner),
      mouthWidth * .32,
      mouthWidth * .30,
      vertical: -_signed(s.mouthSmile) * fh * .014,
    );
  }

  pairWidth(234, 454, s.cheekboneWidth, fw * .021, fw * .17, fh * .11);
  pairWidth(172, 397, s.jawWidth, fw * .021, fw * .20, fh * .12);
  pairWidth(148, 377, s.chinWidth, fw * .015, fw * .19, fh * .095);
  move(
    point(10),
    fw * .40,
    fh * .19,
    vertical: -_signed(s.faceLength) * fh * .018,
  );
  move(
    point(152),
    fw * .40,
    fh * .20,
    vertical: _signed(s.faceLength) * fh * .025,
  );

  for (final brow in [
    [70, 63, 105, 66, 107, 46, 53, 52, 65, 55, -1],
    [300, 293, 334, 296, 336, 276, 283, 282, 295, 285, 1],
  ]) {
    final center = average(brow.sublist(0, 10));
    final width = math.max(fw * .13, distance(brow[0], brow[4]));
    move(
      center,
      width * .92,
      fh * .060,
      vertical: -_signed(s.browHeight) * fh * .011,
    );
    move(
      center,
      width * .92,
      fh * .060,
      horizontal: brow[10] * _signed(s.browSpacing) * fw * .015,
    );
    move(
      point(brow[0]),
      width * .62,
      fh * .060,
      vertical: -_signed(s.browTilt) * fh * .010,
    );
  }

  for (final side in [-1, 1]) {
    final cheek = point(side < 0 ? 50 : 280);
    move(cheek, fw * .18, fh * .13, vertical: -_unit(s.cheekLift) * fh * .015);
    move(
      point(side < 0 ? 127 : 356),
      fw * .16,
      fh * .11,
      horizontal: side * _unit(s.templeLift) * fw * .007,
      vertical: -_unit(s.templeLift) * fh * .014,
    );
    move(
      average(side < 0 ? [98, 61] : [327, 291]),
      fw * .13,
      fh * .10,
      horizontal: side * _unit(s.nasolabialLift) * fw * .004,
      vertical: -_unit(s.nasolabialLift) * fh * .010,
    );
    scale(
      cheek,
      fw * .20,
      fh * .14,
      horizontal: _signed(s.cheekVolume) * .12,
      vertical: _signed(s.cheekVolume) * .12,
    );
  }
  if (s.headSize != 0) {
    final forehead = point(10);
    // Estimate a scalp/head envelope above the facial mesh, then fade fully
    // before the neck. This is not a hair segmentation or a 3D head model;
    // nearby background inside this envelope can move with the head.
    final center = FacePoint(
      forehead.x - uy * fh * .38,
      forehead.y + ux * fh * .38,
    );
    warps.add(
      _Warp(
        center.x,
        center.y,
        fw * .72,
        fh * .72,
        scaleX: _signed(s.headSize) * .16,
        scaleY: _signed(s.headSize) * .16,
        axisX: ux,
        axisY: uy,
        flatCore: true,
      ),
    );
  }
}

class _WarpBounds {
  _WarpBounds(this.warp)
    : left = (warp.x - warp.extentX).floor(),
      right = (warp.x + warp.extentX).ceil(),
      top = (warp.y - warp.extentY).floor(),
      bottom = (warp.y + warp.extentY).ceil();
  final _Warp warp;
  final int left, right, top, bottom;
}

im.Image _warp(im.Image src, List<_Warp> warps) {
  if (warps.isEmpty) return src;
  final out = im.Image.from(src);
  final bounds = warps.map(_WarpBounds.new).toList(growable: false);
  final left = bounds
      .map((p) => p.left)
      .reduce(math.min)
      .clamp(0, src.width - 1);
  final right = bounds
      .map((p) => p.right)
      .reduce(math.max)
      .clamp(0, src.width - 1);
  final top = bounds
      .map((p) => p.top)
      .reduce(math.min)
      .clamp(0, src.height - 1);
  final bottom = bounds
      .map((p) => p.bottom)
      .reduce(math.max)
      .clamp(0, src.height - 1);
  for (var y = top; y <= bottom; y++) {
    // Conservative integer bounds only skip zero-contribution fields. Preserve
    // their original order and all floating-point arithmetic for identical pixels.
    final active = bounds
        .where((p) => y >= p.top && y <= p.bottom)
        .toList(growable: false);
    if (active.isEmpty) continue;
    for (var x = left; x <= right; x++) {
      var dx = 0.0, dy = 0.0;
      for (final entry in active) {
        if (x < entry.left || x > entry.right) continue;
        final p = entry.warp;
        final offsetX = x - p.x, offsetY = y - p.y;
        final xx = offsetX * p.axisX + offsetY * p.axisY,
            yy = -offsetX * p.axisY + offsetY * p.axisX,
            d = xx * xx / (p.rx * p.rx) + yy * yy / (p.ry * p.ry);
        if (d >= 1) continue;
        final weight = p.flatCore ? 1 - _smooth(.25, 1, d) : (1 - d) * (1 - d);
        final localX = xx * (1 / (1 + p.scaleX * weight) - 1);
        final localY = yy * (1 / (1 + p.scaleY * weight) - 1);
        dx += p.dx * weight + localX * p.axisX - localY * p.axisY;
        dy += p.dy * weight + localX * p.axisY + localY * p.axisX;
      }
      if (dx != 0 || dy != 0) _sample(src, out, x, y, x + dx, y + dy);
    }
  }
  return out;
}

void _sample(im.Image src, im.Image out, int x, int y, double sx, double sy) {
  sx = sx.clamp(0.0, src.width - 1.0);
  sy = sy.clamp(0.0, src.height - 1.0);
  final x0 = sx.floor(),
      y0 = sy.floor(),
      x1 = math.min(src.width - 1, x0 + 1),
      y1 = math.min(src.height - 1, y0 + 1);
  final fx = sx - x0,
      fy = sy - y0,
      a = src.getPixel(x0, y0),
      b = src.getPixel(x1, y0),
      c = src.getPixel(x0, y1),
      d = src.getPixel(x1, y1);
  double mix(num v0, num v1, num v2, num v3) =>
      (v0 * (1 - fx) + v1 * fx) * (1 - fy) + (v2 * (1 - fx) + v3 * fx) * fy;
  out.setPixelRgba(
    x,
    y,
    mix(a.r, b.r, c.r, d.r),
    mix(a.g, b.g, c.g, d.g),
    mix(a.b, b.b, c.b, d.b),
    mix(a.a, b.a, c.a, d.a),
  );
}

im.Image _body(im.Image src, EditSettings s) {
  // Explicitly a manual, centered adjustment: no unsupported automatic body claim.
  final out = im.Image.from(src),
      w = src.width.toDouble(),
      h = src.height.toDouble();
  final slim = _unit(s.bodySlim) * .10, leg = _unit(s.legLength) * .08;
  for (var y = 0; y < src.height; y++) {
    for (var x = 0; x < src.width; x++) {
      final nx = (x - w * .5) / (w * .5), ny = y / h;
      final local =
          (1 - _smooth(.60, 1, nx.abs())) *
          _smooth(.12, .32, ny) *
          (1 - _smooth(.82, 1, ny));
      final sx = x + (x - w * .5) * slim * local;
      // Smooth endpoint-preserving vertical remap, strongest around the knees.
      final t = ((ny - .38) / .62).clamp(0.0, 1.0);
      final sy = y - leg * h * math.sin(t * math.pi) * local;
      if (sx != x || sy != y) _sample(src, out, x, y, sx, sy);
    }
  }
  return out;
}

Future<Uint8List> cropImage(Uint8List bytes, double ratio) =>
    compute(_crop, (bytes, ratio));
Uint8List _crop((Uint8List, double) request) {
  final image = _decode(request.$1), ratio = request.$2;
  if (!ratio.isFinite || ratio <= 0) throw ArgumentError.value(ratio, 'ratio');
  var w = image.width, h = image.height;
  if (w / h > ratio) {
    w = math.max(1, (h * ratio).round());
  } else {
    h = math.max(1, (w / ratio).round());
  }
  return _encode(
    im.copyCrop(
      image,
      x: (image.width - w) ~/ 2,
      y: (image.height - h) ~/ 2,
      width: w,
      height: h,
    ),
  );
}

Future<Uint8List> rotateImage(Uint8List bytes) => compute(_rotate, bytes);
Uint8List _rotate(Uint8List bytes) =>
    _encode(im.copyRotate(_decode(bytes), angle: 90));
Future<Uint8List> flipImage(Uint8List bytes) => compute(_flip, bytes);
Uint8List _flip(Uint8List bytes) => _encode(im.flipHorizontal(_decode(bytes)));

Future<Uint8List> applyBrush(
  Uint8List bytes,
  String tool,
  List<FacePoint> points, {
  double radius = .04,
  double strength = .5,
  int color = 0xffed7798,
}) => compute(_brush, _Brush(bytes, tool, points, radius, strength, color));

class _Brush {
  const _Brush(
    this.bytes,
    this.tool,
    this.points,
    this.radius,
    this.strength,
    this.color,
  );
  final Uint8List bytes;
  final String tool;
  final List<FacePoint> points;
  final double radius, strength;
  final int color;
}

Uint8List _brush(_Brush req) {
  final src = _decode(req.bytes),
      out = im.Image.from(src),
      w = src.width,
      h = src.height;
  if (req.points.isEmpty) return _encode(src);
  if (![
    'heal',
    'smooth',
    'mosaic',
    'blur',
    'liquify',
    'paint',
    'wrinkle',
  ].contains(req.tool)) {
    throw ArgumentError.value(req.tool, 'tool', '지원하지 않는 브러시입니다.');
  }
  final r = math.max(1.0, _unit(req.radius) * math.min(w, h)),
      strength = _unit(req.strength);
  if (strength == 0) return _encode(src);
  if (req.tool == 'liquify') {
    if (req.points.length < 2) return _encode(src);
    for (var i = 1; i < req.points.length; i++) {
      final a = req.points[i - 1], b = req.points[i];
      if (!a.x.isFinite || !a.y.isFinite || !b.x.isFinite || !b.y.isFinite) {
        continue;
      }
      final dx = ((a.x - b.x) * w).clamp(-r * .35, r * .35) * strength;
      final dy = ((a.y - b.y) * h).clamp(-r * .35, r * .35) * strength;
      _localWarpInPlace(
        out,
        _Warp(b.x * w, b.y * h, r * 2, r * 2, dx: dx, dy: dy),
      );
    }
    return _encode(out);
  }
  final mask = Float32List(w * h);
  final path = <FacePoint>[];
  for (var i = 0; i < req.points.length; i++) {
    final b = req.points[i];
    if (!b.x.isFinite || !b.y.isFinite) continue;
    if (i == 0) {
      path.add(b);
      continue;
    }
    final a = req.points[i - 1],
        distance = math.sqrt(
          math.pow((a.x - b.x) * w, 2) + math.pow((a.y - b.y) * h, 2),
        );
    final steps = math.max(1, (distance / (r * .35)).ceil());
    for (var j = 1; j <= steps; j++) {
      final t = j / steps;
      path.add(FacePoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t));
    }
  }
  for (final point in path) {
    final cx = point.x * w, cy = point.y * h;
    for (
      var y = math.max(0, (cy - r).floor());
      y <= math.min(h - 1, (cy + r).ceil());
      y++
    ) {
      for (
        var x = math.max(0, (cx - r).floor());
        x <= math.min(w - 1, (cx + r).ceil());
        x++
      ) {
        final d = math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / r;
        if (d < 1) {
          mask[y * w + x] = math.max(mask[y * w + x], 1 - _smooth(.55, 1, d));
        }
      }
    }
  }
  final blurred = ['smooth', 'blur'].contains(req.tool)
      ? im.gaussianBlur(
          im.Image.from(src),
          radius: math.max(2, (r * .22).round()),
        )
      : null;
  final wrinkleTarget = req.tool == 'wrinkle'
      ? repairFineWrinkles(
          im.Image.from(src),
          strength: 1,
          radiusFraction: (_unit(req.radius) * .22).clamp(.004, .025),
        )
      : null;
  final block = math.max(4, (r * .5).round());
  // Healing estimates clean boundary colours with inverse-distance weighting.
  // It is local blemish repair, not a generative large-object remover.
  final boundary = <(int, int, double, double, double)>[];
  if (req.tool == 'heal') {
    final stride = math.max(1, (math.sqrt(w * h) / 250).round());
    for (var y = 0; y < h; y += stride) {
      for (var x = 0; x < w; x += stride) {
        if (mask[y * w + x] > .1) continue;
        final near =
            (x > 0 && mask[y * w + x - 1] > .1) ||
            (x < w - 1 && mask[y * w + x + 1] > .1) ||
            (y > 0 && mask[(y - 1) * w + x] > .1) ||
            (y < h - 1 && mask[(y + 1) * w + x] > .1);
        if (near) {
          final p = src.getPixel(x, y);
          boundary.add((x, y, p.r.toDouble(), p.g.toDouble(), p.b.toDouble()));
        }
      }
    }
    // Sparse sampling can miss narrow contours; sample each stroke's perimeter.
    if (boundary.length < 12) {
      for (final center in path) {
        for (var k = 0; k < 24; k++) {
          final angle = k * math.pi / 12,
              x = (center.x * w + math.cos(angle) * r * 1.1).round().clamp(
                0,
                w - 1,
              ),
              y = (center.y * h + math.sin(angle) * r * 1.1).round().clamp(
                0,
                h - 1,
              );
          final p = src.getPixel(x, y);
          boundary.add((x, y, p.r.toDouble(), p.g.toDouble(), p.b.toDouble()));
        }
      }
    }
    if (boundary.length > 512) {
      final sampleEvery = (boundary.length / 512).ceil();
      final sampled = [
        for (var i = 0; i < boundary.length; i += sampleEvery) boundary[i],
      ];
      boundary
        ..clear()
        ..addAll(sampled);
    }
  }
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      var alpha = mask[y * w + x] * strength;
      if (alpha <= 0) continue;
      final p = src.getPixel(x, y);
      var rr = p.r.toDouble(), gg = p.g.toDouble(), bb = p.b.toDouble();
      switch (req.tool) {
        case 'wrinkle':
          final q = wrinkleTarget!.getPixel(x, y);
          rr = q.r.toDouble();
          gg = q.g.toDouble();
          bb = q.b.toDouble();
        case 'smooth':
        case 'blur':
          final q = blurred!.getPixel(x, y);
          if (req.tool == 'smooth') {
            alpha *=
                .8 *
                (1 -
                    _smooth(
                      10,
                      35,
                      (_luma(p.r, p.g, p.b) - _luma(q.r, q.g, q.b)).abs(),
                    ));
          }
          rr = q.r.toDouble();
          gg = q.g.toDouble();
          bb = q.b.toDouble();
        case 'mosaic':
          final bx = (x ~/ block) * block, by = (y ~/ block) * block;
          var rsum = 0.0, gsum = 0.0, bsum = 0.0, count = 0;
          // Fixed sparse block average is consistent over a whole brush stroke.
          for (
            var yy = by;
            yy < math.min(h, by + block);
            yy += math.max(1, block ~/ 4)
          ) {
            for (
              var xx = bx;
              xx < math.min(w, bx + block);
              xx += math.max(1, block ~/ 4)
            ) {
              final q = src.getPixel(xx, yy);
              rsum += q.r;
              gsum += q.g;
              bsum += q.b;
              count++;
            }
          }
          rr = rsum / count;
          gg = gsum / count;
          bb = bsum / count;
        case 'heal':
          var total = 0.0, rsum = 0.0, gsum = 0.0, bsum = 0.0;
          for (final b in boundary) {
            final d = (x - b.$1) * (x - b.$1) + (y - b.$2) * (y - b.$2) + 1.0;
            final weight = 1 / (d * d);
            total += weight;
            rsum += b.$3 * weight;
            gsum += b.$4 * weight;
            bsum += b.$5 * weight;
          }
          if (total > 0) {
            rr = rsum / total;
            gg = gsum / total;
            bb = bsum / total;
          }
        case 'paint':
          rr = ((req.color >> 16) & 255).toDouble();
          gg = ((req.color >> 8) & 255).toDouble();
          bb = (req.color & 255).toDouble();
      }
      out.setPixelRgba(
        x,
        y,
        _clamp(p.r + (rr - p.r) * alpha),
        _clamp(p.g + (gg - p.g) * alpha),
        _clamp(p.b + (bb - p.b) * alpha),
        p.a,
      );
    }
  }
  return _encode(out);
}

/// Sequential push strokes snapshot only their local support. Copying a whole
/// 12MP image for each pointer event would otherwise create gigabytes of churn.
void _localWarpInPlace(im.Image out, _Warp p) {
  final left = (p.x - p.rx).floor().clamp(0, out.width - 1);
  final right = (p.x + p.rx).ceil().clamp(0, out.width - 1);
  final top = (p.y - p.ry).floor().clamp(0, out.height - 1);
  final bottom = (p.y + p.ry).ceil().clamp(0, out.height - 1);
  final pad = math.max(p.dx.abs(), p.dy.abs()).ceil() + 2;
  final sx = math.max(0, left - pad), sy = math.max(0, top - pad);
  final patch = im.copyCrop(
    out,
    x: sx,
    y: sy,
    width: math.min(out.width - 1, right + pad) - sx + 1,
    height: math.min(out.height - 1, bottom + pad) - sy + 1,
  );
  for (var y = top; y <= bottom; y++) {
    for (var x = left; x <= right; x++) {
      final xx = x - p.x,
          yy = y - p.y,
          d = xx * xx / (p.rx * p.rx) + yy * yy / (p.ry * p.ry);
      if (d >= 1) continue;
      final weight = (1 - d) * (1 - d);
      _sample(patch, out, x, y, x + p.dx * weight - sx, y + p.dy * weight - sy);
    }
  }
}
