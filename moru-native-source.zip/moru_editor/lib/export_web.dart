import 'dart:js_interop';
import 'dart:typed_data';
import 'package:web/web.dart' as web;

void downloadPhoto(Uint8List bytes, String filename) {
  final png = bytes.length > 4 && bytes[0] == 0x89 && bytes[1] == 0x50;
  final actualName = png ? filename.replaceAll(RegExp(r'\.[^.]+$'), '.png') : filename;
  final blob = web.Blob([bytes.toJS].toJS, web.BlobPropertyBag(type: png ? 'image/png' : 'image/jpeg'));
  final url = web.URL.createObjectURL(blob);
  final link = web.HTMLAnchorElement()..href = url..download = actualName;
  web.document.body!.append(link);
  link.click();
  link.remove();
  Future<void>.delayed(const Duration(seconds: 30), () => web.URL.revokeObjectURL(url));
}
